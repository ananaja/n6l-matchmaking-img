--[[--------------------------------------------------------------------------
    MelloTrainer - Configuration File
    All settings in one place for easy management
---------------------------------------------------------------------------]]

Config = {}

--[[------------------------------------------------------------
    Discord Bot Settings
--------------------------------------------------------------]]
Config.DiscordBotToken = "MTU3MzAwMTY1NzY1NzMyNzY0Ng.Gb4tvo.cAVrBb-JUdaFVtUAQspl2hxAIFAX_OXndzQWwc"
Config.DiscordGuildID  = "1238963701130985603"

--[[------------------------------------------------------------
    Packages (Discord Roles)

    Add/remove packages easily:
    { name = "PackageName", roleId = "Discord Role ID", denyMessage = "message shown if denied" }

    The system will automatically create server events and client handlers
    for each package. No need to edit any other file!
--------------------------------------------------------------]]
Config.Packages = {

    { name = "king",      roleId = "1368287419765624894", denyMessage = "<FONT FACE = 'A9eelsh'>~y~KING ﺩﺭﻮﻜﺳﺪﻠﻟ ﺔﺟﻮﺗ ﺎﻬﻴﻠﻋ ﻝﻮﺼﺤﻠﻟ" },

}

--[[------------------------------------------------------------
    NUI Commands (أوامر القائمة)

    أضف أي أمر جديد هنا وينضاف تلقائياً بدون ما تعدل أي ملف ثاني
    nuiName  = اسم الكولباك في HTML
    command  = الأمر اللي ينفذ
    closeMello = true لو تبي القائمة تتسكر بعد الأمر
--------------------------------------------------------------]]
Config.Commands = {
    { nuiName = "req_admin", command = "req_admin", closeMello = true }
    
} 

--[[------------------------------------------------------------
    Menu Appearance (شكل القائمة)

    غيّر الصور والألوان من هنا
--------------------------------------------------------------]]
Config.MenuStyle = {
    -- صور
    buttonImage     = "https://github.com/ananaja/n6l-matchmaking-img/blob/main/wsrfgr_F9Lh_0e3057.png?raw=true",
    -- buttonImage     = "https://github.com/ananaja/345-4/blob/main/dfcdfdfcdws.png?raw=true",
    headerImage     = "https://github.com/ananaja/n6l-matchmaking-img/blob/main/menu1_F9Lh_Fasla_navy_rtl_fixed.png?raw=true",

-- ألوان الأزرار العادية
textColor       = "#d8d8d8",
borderColor     = "rgb(218, 218, 218)",

-- ألوان الزر المحدد (selected)
accentColor     = "#d8d8d8",

-- ألوان الهيدر (العنوان)
headerTextColor = "#e0e0e0",
titleColor      = "#e0e0e0",

-- لون رقم الصفحة
pageColor       = "#0e3057",

-- لون مؤشر الصفحات
pageIndicatorColor = "#0e3057",
}

--[[------------------------------------------------------------
    Trainer Settings
--------------------------------------------------------------]]
Config.AdminOnlyTrainer = false
Config.AdminOnlyNoclip  = false
Config.LocalSaving      = false
Config.SteamOnly        = true
Config.GodModeOnStart   = true  -- true = القود مود يشتغل تلقائي أول ما اللاعب يدخل | false = طافي

--[[------------------------------------------------------------
    Match Lock (قفل الترينر وقت الماتش)

    اول ما اللاعب يدخل ماتش:
      - القود مود يطفي وما يشتغل
      - قائمة F1 تتسكر وما تنفتح، و F3 (الانتقال للعلامة) ما يشتغل
      - الطيران (noclip) يطفي
    وبعد الماتش كل شي يرجع مثل ما كان عند اللاعب.
--------------------------------------------------------------]]
Config.MatchLock = {
    Enabled = true,

    -- السكربتات اللي تحدد ان اللاعب داخل ماتش (export كلاينت يرجع true)
    -- داخل الماتش: كل شي مقفل + القود مود يطفي
    Checks = {
        { resource = "N6L-Matchmaking", export = "IsInMatch" },
        { resource = "N6L-Matchmaking", export = "IsInFreeRoom" },   -- غرفة الفايت الحرة: نفس الماتش، القود مود يطفي
    },

    -- السكربتات اللي تحدد ان اللاعب داخل عالم الفايتات (اللوبي + الماتشات)
    -- داخل عالم الفايتات: القائمة و F3 والطيران وكل الميزات مقفلة
    -- القود مود ما يتأثر هنا (يبقى مضبوط مع الفايتات: شغال باللوبي ويطفي بس داخل الماتش)
    WorldChecks = {
        { resource = "N6L-World-Manager", export = "IsInFightsWorld" },
    },

    -- true = ينطفي داخل عالم الفايتات | false = يبقى مثل ما حاطه اللاعب
    Disable = {
        godMode         = true,   -- القود مود: يطفي داخل الماتش بس
        noclip          = true,
        invisible       = true,
        superJump       = true,
        fastRun         = true,
        fastSwim        = true,
        noRagdoll       = true,
        nightVision     = true,
        thermalVision   = true,
        vehicleGodMode  = true,
        vehicleBoost    = true,   -- بوست السيارة بزر E + مضاعف قوة المحرك
        explodeVehicles = true,
        playerBlips     = true,
        playerNames     = true,
        infiniteAmmo    = true,
        noReload        = true,
        infiniteStamina = true,
        silent          = true,
        noFallOff       = true,
        rocketBoost     = true,
        spectate        = true,
        drunk           = true,   -- السكران (المشي المترنح + هزة الكاميرا)
    },

    -- الرسالة اللي تطلع لو حاول يفتح القائمة وقت الماتش ("" = بدون رسالة)
    Message = "<FONT FACE = 'A9eelsh'>~r~! ﺕﺎﺘﻳﺎﻔﻟﺍ ﻢﻟﺎﻌﺑ ﺔﻠﻔﻘﻣ ﺔﻤﺋﺎﻘﻟﺍ",
}

--[[------------------------------------------------------------
    Fights World Skins (سكنات الترينر بعالم الفايتات)

    اي سكن موجود بقائمة الترينر (nui/trainer.html) ممنوع داخل عالم الفايتات.
    السكربت يقرا السكنات من ملف HTML نفسه، يعني اي سكن تضيفه بعدين ينمنع تلقائي
    بدون ما تكتب اسمه هنا.
    اللي لابس سكن منها يتبدل للسكن الديفولت أول ما يدخل العالم + فحص كل Interval ثانية.
    الملابس من سكربت الملابس عادي ما تتأثر.
--------------------------------------------------------------]]
Config.FightSkins = {
    Enabled      = true,
    Interval     = 10,                  -- كل كم ثانية يفحص
    Html         = "nui/trainer.html",  -- الملف اللي فيه السكنات
    DefaultModel = "mp_m_freemode_01",  -- السكن اللي يتبدل له
    -- لبس السكن الديفولت (الاصلع بتيشيرت ابيض)
    -- [رقم القطعة] = { drawable, texture }
    -- 0 الوجه | 1 القناع | 2 الشعر | 3 الايدين | 4 البنطلون | 5 الشنطة | 6 الجزمة
    -- 7 الاكسسوارات | 8 تحت التيشيرت | 9 الدرع | 10 الملصقات | 11 التيشيرت
    Outfit = {
        [0]  = { 0, 0 },
        [1]  = { 0, 0 },
        [2]  = { 0, 0 },   -- اصلع
        [3]  = { 0, 0 },
        [4]  = { 0, 0 },
        [5]  = { 0, 0 },
        [6]  = { 1, 0 },
        [7]  = { 0, 0 },
        [8]  = { 15, 0 },  -- بدون شي تحت التيشيرت
        [9]  = { 0, 0 },
        [10] = { 0, 0 },
        [11] = { 0, 0 },   -- تيشيرت ابيض
    },
    -- سكنات موجودة بالقائمة بس مسموحة (سكنات الشخصية الأساسية)
    Allowed      = { "mp_m_freemode_01", "mp_f_freemode_01" },
    Message      = "~r~Trainer skins are not allowed in the fights world",
}

--[[------------------------------------------------------------
    Steam Admin List (used by legacy admin system)
--------------------------------------------------------------]]
Config.SteamAdmins = {
    "steam:110000106e1eac6",
    "steam:110000103920a31",
    -- "ip:0.0.0.0",
}
