







--[[--------------------------------------------------------------------------
    MelloTrainer - Server Side (Merged)
    All server-side logic in one file
---------------------------------------------------------------------------]]

-- ============================================================
--  SECTION 1: Version Check
-- ============================================================
_VERSION = '0.5.5'

PerformHttpRequest( "https://thestonedturtle.github.io/mellotrainer/version", function( err, text, headers )
    Citizen.Wait( 1000 )
    RconPrint( "\nCurrent MelloTrainer Version: " .. _VERSION)
    if text then
        RconPrint( "\nLatest MelloTrainer Version: " .. text)
        if ( text ~= _VERSION ) then
            RconPrint( "\n\n\t|||||||||||||||||||||||||||||||||\n\t||  MelloTrainer is Outdated   ||\n\t|| Download the latest version ||\n\t||    From the FiveM Forums    ||\n\t|||||||||||||||||||||||||||||||||\n\n" )
        else
            RconPrint( "\nMelloTrainer is up to date!\n" )
        end
    else
        RconPrint( "\n[Warning] Could not check for updates (Update server might be offline).\n" )
    end
end, "GET", "", { what = 'this' } )

-- ============================================================
--  SECTION 2: Config Settings (reads from config.lua)
-- ============================================================
local configSettings = {
    adminOnlyTrainer = Config.AdminOnlyTrainer,
    admins = Config.SteamAdmins,
    localSaving = Config.LocalSaving,
    steamOnly = Config.SteamOnly,
    adminOnlyNoclip = Config.AdminOnlyNoclip
}

RegisterServerEvent("mellotrainer:getConfigSetting")
AddEventHandler("mellotrainer:getConfigSetting", function(stringname)
    local value = configSettings[stringname]
    TriggerClientEvent("mellotrainer:receiveConfigSetting", source, stringname, value)
end)

-- ============================================================
--  SECTION 3: User Management
-- ============================================================
local Users = {}

RegisterServerEvent('mellotrainer:firstJoinProper')
AddEventHandler('mellotrainer:firstJoinProper', function(id)
    local identifiers = GetPlayerIdentifiers(source)
    for i = 1, #identifiers do
        if(Users[source] == nil)then
            Users[source] = {
                name = GetPlayerName(source),
                source = id
            }
        end
    end

    TriggerClientEvent('mellotrainer:playerJoined', -1, id)
    TriggerClientEvent("mellotrainer:receiveConfigSetting", source, "adminOnlyTrainer", configSettings.adminOnlyTrainer)
    TriggerClientEvent("mellotrainer:receiveConfigSetting", source, "localSaving", configSettings.localSaving)
    TriggerClientEvent("mellotrainer:receiveConfigSetting", source, "adminOnlyNoclip", configSettings.adminOnlyNoclip)

    if(configSettings.localSaving)then
        DATASAVE:AddPlayerToDataSave(source)
    end
end)

-- ============================================================
--  SECTION 4: Discord Permission System
-- ============================================================
local REQUIRED_ROLES = {}
for _, pkg in ipairs(Config.Packages) do
    REQUIRED_ROLES[pkg.name] = pkg.roleId
end

local playerPermissionsCache = {}

local function getPlayerDiscordIdentifier(source)
    local identifiers = GetPlayerIdentifiers(source)
    for _, identifier in ipairs(identifiers) do
        if string.match(identifier, "discord:") then
            return string.sub(identifier, 9)
        end
    end
    return nil
end

local function populatePlayerCacheAndNotify(source)
    local src = source
    local discordID = getPlayerDiscordIdentifier(src)

    if not discordID then
        print(string.format("^3[mellotrainer]^7 WARNING: Player ID %s has no Discord linked (Permissions skipped).", src))
        return
    end

    print(string.format("^3[mellotrainer]^7 Fetching roles for Discord ID: %s", discordID))

    local url = string.format("https://discord.com/api/v10/guilds/%s/members/%s", Config.DiscordGuildID, discordID)
    local headers = { ["Authorization"] = "Bot " .. Config.DiscordBotToken }

    PerformHttpRequest(url, function(statusCode, result, headers)
        local newCache = {}
        for roleKey, _ in pairs(REQUIRED_ROLES) do
            newCache[roleKey] = false
        end

        if statusCode == 200 then
            local memberData = json.decode(result)
            if memberData and memberData.roles then
                for _, roleID in ipairs(memberData.roles) do
                    for roleKey, requiredId in pairs(REQUIRED_ROLES) do
                        if roleID == requiredId then
                            newCache[roleKey] = true
                            break
                        end
                    end
                end
            end
            print(string.format("^2[mellotrainer]^7 Success: Permissions cached for %s.", discordID))
        elseif statusCode == 404 then
            print(string.format("^1[mellotrainer]^7 WARNING: User %s is not in the Discord server. No roles assigned.", discordID))
        elseif statusCode == 429 then
            print("^1[mellotrainer]^7 RATE LIMIT hit! Retrying in 3 seconds...")
            SetTimeout(3000, function() populatePlayerCacheAndNotify(src) end)
            return
        else
            print(string.format("^1[mellotrainer]^7 ERROR: API returned status code %s", statusCode))
        end

        playerPermissionsCache[discordID] = newCache
        TriggerClientEvent('mellotrainer:assignRoles', src, newCache)
    end, 'GET', '', headers)
end

AddEventHandler('playerConnecting', function()
    local src = source
    SetTimeout(4000, function()
        populatePlayerCacheAndNotify(src)
    end)
end)

AddEventHandler('playerDropped', function()
    local src = source
    local discordID = getPlayerDiscordIdentifier(src)
    if discordID and playerPermissionsCache[discordID] then
        playerPermissionsCache[discordID] = nil
        print(string.format("^4[mellotrainer]^7 Cache cleared for disconnected player: %s", discordID))
    end
end)

local function checkPlayerRoleFromCache(source, roleKey, clientEvent)
    local src = source
    local discordID = getPlayerDiscordIdentifier(src)

    if not discordID then
        TriggerClientEvent(clientEvent, src, false)
        return
    end

    if playerPermissionsCache[discordID] and playerPermissionsCache[discordID][roleKey] then
        TriggerClientEvent(clientEvent, src, true)
    else
        if playerPermissionsCache[discordID] == nil then
            populatePlayerCacheAndNotify(src)
        else
            TriggerClientEvent(clientEvent, src, false)
        end
    end
end

local function createPermissionChecker(eventTrigger, roleKey, clientEvent)
    RegisterNetEvent(eventTrigger)
    AddEventHandler(eventTrigger, function()
        checkPlayerRoleFromCache(source, roleKey, clientEvent)
    end)
end

for _, pkg in ipairs(Config.Packages) do
    local lowerName = string.lower(pkg.name)
    createPermissionChecker(
        'mellotrainer:is' .. lowerName,
        pkg.name,
        'mellotrainer:' .. lowerName .. 'status'
    )
end

-- ============================================================
--  SECTION 5: Skin Save System (Server-Side Storage)
-- ============================================================
local savesDirectory = "skins_data/"

function GetPlayerID(src)
    local identifiers = GetPlayerIdentifiers(src)
    local steam, license
    for _, v in pairs(identifiers) do
        if string.find(v, "steam") then
            steam = v
        elseif string.find(v, "license") then
            license = v
        end
    end
    if steam then return steam end
    if license then return license end
    return nil
end

function LoadDataFile(identifier)
    local cleanID = string.gsub(identifier, ":", "_")
    local content = LoadResourceFile(GetCurrentResourceName(), savesDirectory .. cleanID .. ".json")
    if content then
        return json.decode(content)
    else
        return {}
    end
end

function SaveDataFile(identifier, data)
    local cleanID = string.gsub(identifier, ":", "_")
    SaveResourceFile(GetCurrentResourceName(), savesDirectory .. cleanID .. ".json", json.encode(data, {indent = true}), -1)
end

RegisterServerEvent('mellotrainer:saveCharacter')
AddEventHandler('mellotrainer:saveCharacter', function(characterData, index, saveName)
    local src = source
    local identifier = GetPlayerID(src)

    if not identifier then
        print("^1[MelloTrainer] Error: Could not find Steam or License for player " .. src .. "^0")
        TriggerClientEvent('mello:notify', src, "~r~Error: Could not identify you for saving!")
        return
    end

    local currentSaves = LoadDataFile(identifier)

    if index then
        if currentSaves[index] then
            currentSaves[index] = characterData
            currentSaves[index].saveName = saveName
        end
    else
        table.insert(currentSaves, characterData)
    end

    SaveDataFile(identifier, currentSaves)
    TriggerClientEvent('mellotrainer:receiveSavedCharacters', src, currentSaves)
    TriggerClientEvent('mello:notify', src, "~g~Character Saved Successfully!")
    print("^2[MelloTrainer] Saved character for " .. GetPlayerName(src) .. "^0")
end)

RegisterServerEvent('mellotrainer:loadCharacters')
AddEventHandler('mellotrainer:loadCharacters', function()
    local src = source
    local identifier = GetPlayerID(src)
    if not identifier then return end
    local currentSaves = LoadDataFile(identifier)
    TriggerClientEvent('mellotrainer:receiveSavedCharacters', src, currentSaves)
end)

RegisterServerEvent('mellotrainer:deleteCharacter')
AddEventHandler('mellotrainer:deleteCharacter', function(index)
    local src = source
    local identifier = GetPlayerID(src)
    if not identifier then return end
    local currentSaves = LoadDataFile(identifier)
    if currentSaves[index] then
        table.remove(currentSaves, index)
        SaveDataFile(identifier, currentSaves)
        TriggerClientEvent('mellotrainer:receiveSavedCharacters', src, currentSaves)
        TriggerClientEvent('mello:notify', src, "~r~Character Deleted!")
    end
end)

RegisterServerEvent('mellotrainer:renameCharacter')
AddEventHandler('mellotrainer:renameCharacter', function(index, newName)
    local src = source
    local identifier = GetPlayerID(src)
    if not identifier then return end
    local currentSaves = LoadDataFile(identifier)
    if currentSaves[index] then
        currentSaves[index].saveName = newName
        SaveDataFile(identifier, currentSaves)
        TriggerClientEvent('mellotrainer:receiveSavedCharacters', src, currentSaves)
        TriggerClientEvent('mello:notify', src, "~g~Character Renamed!")
    end
end)

-- ============================================================
--  Fights World Skins: every Interval seconds nobody in the
--  fights world may wear a skin from the trainer menu
-- ============================================================
local fightSkins = Config.FightSkins or {}

-- hashes compared as unsigned so client / server values always match
local function fightSkinHash(value)
    if type(value) == "string" then value = GetHashKey(value) end
    return math.tointeger(value % 4294967296)
end

if fightSkins.Enabled then
    -- every "playerskin <model>" in the trainer html, so skins added later are banned too
    local banned, allowed = {}, {}
    for _, name in ipairs(fightSkins.Allowed or {}) do allowed[fightSkinHash(name)] = true end
    local html = LoadResourceFile(GetCurrentResourceName(), fightSkins.Html or "nui/trainer.html") or ""
    for name in html:gmatch('data%-action%s*=%s*"playerskin%s+([^"%s]+)%s*"') do
        local hash = fightSkinHash(name)
        if name ~= "input" and not allowed[hash] then banned[hash] = true end
    end

    Citizen.CreateThread(function()
        while true do
            Citizen.Wait((fightSkins.Interval or 10) * 1000)
            if GetResourceState("N6L-World-Manager") == "started" then
                for _, id in ipairs(GetPlayers()) do
                    local src = tonumber(id)
                    local ok, inFights = pcall(function() return exports["N6L-World-Manager"]:IsInFightsWorld(src) end)
                    local ped = GetPlayerPed(src)
                    if ok and inFights and ped ~= 0 and banned[fightSkinHash(GetEntityModel(ped))] then
                        TriggerClientEvent("mellotrainer:fightSkinReset", src)
                    end
                end
            end
        end
    end)
end





