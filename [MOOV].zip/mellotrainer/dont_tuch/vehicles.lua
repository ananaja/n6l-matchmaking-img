

local vehgodmode,boostcar,showextras, frontleft, frontright,
	  rearleft, rearright, hood, trunk, needforspeed, 
	  bunnyhop
	  

RegisterNUICallback("veh", function(data, cb) --Vehicle Options
	local action = data.action
	local newstate = data.newstate
	local playerPed = GetPlayerPed(-1)
	local playerVeh = GetVehiclePedIsIn(playerPed, true)

	if action == "fixclean" then --Fixing And Cleaning
		if IsPedInAnyVehicle(GetPlayerPed(-1), 0) and (GetPedInVehicleSeat(GetVehiclePedIsIn(GetPlayerPed(-1), 0), -1) == GetPlayerPed(-1)) then
			SetVehicleFixed(playerVeh)
			SetVehicleDirtLevel(playerVeh, 0.0)
			SetVehicleLights(playerVeh, 0)
			SetVehicleBurnout(playerVeh, false)
			Citizen.InvokeNative(0x1FD09E7390A74D54, playerVeh, 0)
			drawNotification("~g~Vehicle repaired & cleaned!")
		else
			drawNotification("~r~You Aren't In The Driverseat Of A Vehicle!")
		end
	elseif action == "fuckup" then --Fuck Up Current Vehicle
		if IsPedInAnyVehicle(GetPlayerPed(-1), 0) and (GetPedInVehicleSeat(GetVehiclePedIsIn(GetPlayerPed(-1), 0), -1) == GetPlayerPed(-1)) then
			StartVehicleAlarm(playerVeh)
			DetachVehicleWindscreen(playerVeh)
			SmashVehicleWindow(playerVeh, 0)
			SmashVehicleWindow(playerVeh, 1)
			SmashVehicleWindow(playerVeh, 2)
			SmashVehicleWindow(playerVeh, 3)
			SetVehicleTyreBurst(playerVeh, 0, true, 1000.0)
			SetVehicleTyreBurst(playerVeh, 1, true, 1000.0)
			SetVehicleTyreBurst(playerVeh, 2, true, 1000.0)
			SetVehicleTyreBurst(playerVeh, 3, true, 1000.0)
			SetVehicleTyreBurst(playerVeh, 4, true, 1000.0)
			SetVehicleTyreBurst(playerVeh, 5, true, 1000.0)
			SetVehicleTyreBurst(playerVeh, 4, true, 1000.0)
			SetVehicleTyreBurst(playerVeh, 7, true, 1000.0)
			SetVehicleDoorBroken(playerVeh, 0, true)
			SetVehicleDoorBroken(playerVeh, 1, true)
			SetVehicleDoorBroken(playerVeh, 2, true)
			SetVehicleDoorBroken(playerVeh, 3, true)
			SetVehicleDoorBroken(playerVeh, 4, true)
			SetVehicleDoorBroken(playerVeh, 5, true)
			SetVehicleDoorBroken(playerVeh, 6, true)
			SetVehicleDoorBroken(playerVeh, 7, true)
			SetVehicleLights(playerVeh, 1)
			Citizen.InvokeNative(0x1FD09E7390A74D54, playerVeh, 1)
			SetVehicleNumberPlateTextIndex(playerVeh, 5)
			SetVehicleNumberPlateText(playerVeh, "ANALSWAG")
			SetVehicleDirtLevel(playerVeh, 10.0)
			SetVehicleModColor_1(playerVeh, 1)
			SetVehicleModColor_2(playerVeh, 1)
			SetVehicleCustomPrimaryColour(playerVeh, 255, 51, 255)
			SetVehicleCustomSecondaryColour(playerVeh, 255, 51, 255)
			SetVehicleBurnout(playerVeh, true)
			drawNotification("~g~Vehicle Fucked Up!")
		else
			drawNotification("~r~You Aren't In The Driverseat Of A Vehicle!")
		end
	elseif action == "delete" then --Delete
		if IsPedInAnyVehicle(GetPlayerPed(-1), 0) and (GetPedInVehicleSeat(GetVehiclePedIsIn(GetPlayerPed(-1), 0), -1) == GetPlayerPed(-1)) then
			SetEntityAsMissionEntity(Object, 1, 1)
			DeleteEntity(Object)
			SetEntityAsMissionEntity(playerVeh, 1, 1)
			DeleteVehicle(playerVeh)
			drawNotification("~g~Vehicle Deleted!")
		else
			drawNotification("~r~You Aren't In The Driverseat Of A Vehicle!")
		end
		
	elseif action == "vehiclegodmode" then --Godmode
		vehgodmode = newstate
		SetVehicleFixed(playerVeh)
		SetVehicleDirtLevel(playerVeh, 0.0)
		SetVehicleEngineHealth(playerVeh, 1000.0)
		if (vehgodmode == false) then
			drawNotification("~g~Vehicle Godmode Enabled!")
		else
			drawNotification("~r~Vehicle Godmode Disabled!")
		end
	elseif action == "hornboost" then  --Boost On Horn
		boostcar = newstate
		if (boostcar == true) then
			drawNotification("~g~Boost Car Enabled!")
		else
			drawNotification("~r~Boost Car Disabled!")
		end
	end

	cb("ok")
end)

RegisterNUICallback("openclosedoors", function(data, cb) --Door Menu
	local playerPed = GetPlayerPed(-1)
	local playerVeh = GetVehiclePedIsIn(playerPed, false)
	local action = data.action
	
	if action == "0" then
		if IsPedInAnyVehicle(playerPed, true) then
			if GetVehicleDoorAngleRatio(playerVeh, 0) > 0.0 then 
				SetVehicleDoorShut(playerVeh, 0, false)
				drawNotification("~r~Front Left Door Closed!")
			else
				SetVehicleDoorOpen(playerVeh, 0, false)
				frontleft = true
			end
		else
			drawNotification("~r~Not in a vehicle!")
		end
	elseif action == "1" then 
		if IsPedInAnyVehicle(playerPed, true) then
			if GetVehicleDoorAngleRatio(playerVeh, 1) > 0.0 then 
				SetVehicleDoorShut(playerVeh, 1, false)
				drawNotification("~r~Front Right Door Closed!")
			else
				SetVehicleDoorOpen(playerVeh, 1, false)
				frontright = true
			end
		else
			drawNotification("~r~Not in a vehicle!")
		end
	elseif action == "2" then 
		if IsPedInAnyVehicle(playerPed, true) then
			if GetVehicleDoorAngleRatio(playerVeh, 2) > 0.0 then 
				SetVehicleDoorShut(playerVeh, 2, false)
				drawNotification("~r~Rear Left Door Closed!")
			else
				SetVehicleDoorOpen(playerVeh, 2, false)
				rearleft = true
			end
		else
			drawNotification("~r~Not in a vehicle!")
		end
	elseif action == "3" then 
		if IsPedInAnyVehicle(playerPed, true) then
			if GetVehicleDoorAngleRatio(playerVeh, 3) > 0.0 then 
				SetVehicleDoorShut(playerVeh, 3, false)
				drawNotification("~r~Rear Right Door Closed!")
			else
				SetVehicleDoorOpen(playerVeh, 3, false)
				rearright = true
			end
		else
			drawNotification("~r~Not in a vehicle!")
		end
	elseif action == "4" then 
		if IsPedInAnyVehicle(playerPed, true) then
			if GetVehicleDoorAngleRatio(playerVeh, 4) > 0.0 then 
				SetVehicleDoorShut(playerVeh, 4, false)
				drawNotification("~r~Hood Closed!")
			else
				SetVehicleDoorOpen(playerVeh, 4, false)
				hood = true
			end
		else
			drawNotification("~r~Not in a vehicle!")
		end
	elseif action == "5" then 
		if IsPedInAnyVehicle(playerPed, true) then
			if GetVehicleDoorAngleRatio(playerVeh, 5) > 0.0 then 
				SetVehicleDoorShut(playerVeh, 5, false)
				drawNotification("~r~Trunk Closed!")
			else
				SetVehicleDoorOpen(playerVeh, 5, false)
				trunk = true
			end
		else
			drawNotification("~r~Not in a vehicle!")
		end
	end
end)

RegisterNUICallback("extra", function(data, cb) --Extra Menu
	local playerPed = GetPlayerPed(-1)
	local playerVeh = GetVehiclePedIsIn(playerPed, false)
	local action = data.action
	local extra = tonumber(action)
	local newstate = data.newstate
	
	if action == "show" then
		showextras = newstate
		drawNotification("~g~Showing Extras States!")
		drawNotification("~y~Disappears In 10 Seconds!")
	else
		if IsPedInAnyVehicle(playerPed, true) then
			if (DoesExtraExist(playerVeh, extra) == 1) then
				if (IsVehicleExtraTurnedOn(playerVeh, extra) == 1) then
					SetVehicleExtra(playerVeh, extra, true)
					drawNotification("~r~Extra " .. action .. " Disabled!")
				else
					SetVehicleExtra(playerVeh, extra, false)
					drawNotification("~g~Extra " .. action .. " Enabled!")
				end
			else
				drawNotification("~r~Extra " .. action .. " Not Existing!")
			end
		else
			drawNotification("~r~Not in a vehicle!")
		end
	end
end)

Citizen.CreateThread(function() --Door Messages
	while true do
		Citizen.Wait(0)

		if (frontleft == true) then --Front Left Door Message
			Citizen.Wait(50)
			if GetVehicleDoorAngleRatio(GetVehiclePedIsIn(GetPlayerPed(-1), false), 0) == 0.0 then
				drawNotification("~r~No Front Left Door!")
			else
				drawNotification("~g~Front Left Door Opened!")
			end
			frontleft = false
		elseif (frontright == true) then --Front Right Door Message
			Citizen.Wait(50)
			if GetVehicleDoorAngleRatio(GetVehiclePedIsIn(GetPlayerPed(-1), false), 1) == 0.0 then
				drawNotification("~r~No Front Right Door!")
			else
				drawNotification("~g~Front Right Door Opened!")
			end
			frontright = false
		elseif (rearleft == true) then --Rear Left Door Message
			Citizen.Wait(50)
			if GetVehicleDoorAngleRatio(GetVehiclePedIsIn(GetPlayerPed(-1), false), 2) == 0.0 then
				drawNotification("~r~No Rear Left Door!")
			else
				drawNotification("~g~Rear Left Door Opened!")
			end
			rearleft = false
		elseif (rearright == true) then --Rear Right Door Message
			Citizen.Wait(50)
			if GetVehicleDoorAngleRatio(GetVehiclePedIsIn(GetPlayerPed(-1), false), 3) == 0.0 then
				drawNotification("~r~No Rear Right Door!")
			else
				drawNotification("~g~Rear Right Door Opened!")
			end
			rearright = false
		elseif (hood == true) then --Hood Message
			Citizen.Wait(50)
			if GetVehicleDoorAngleRatio(GetVehiclePedIsIn(GetPlayerPed(-1), false), 4) == 0.0 then
				drawNotification("~r~No Hood!")
			else
				drawNotification("~g~Hood Opened!")
			end
			hood = false
		elseif (trunk == true) then --Trunk Message
			Citizen.Wait(50)
			if GetVehicleDoorAngleRatio(GetVehiclePedIsIn(GetPlayerPed(-1), false), 5) == 0.0 then
				drawNotification("~r~No Trunk!")
			else
				drawNotification("~g~Trunk Opened!")
			end
			trunk = false
		end
	end
end)

Citizen.CreateThread(function() --Godmode
	while true do
		Citizen.Wait(0)
		local playerVeh = GetVehiclePedIsIn(GetPlayerPed(-1))
		if (vehgodmode == false) or (vehgodmode == true and matchLockVehGod) then
			if IsPedInAnyVehicle(GetPlayerPed(-1), true) then
				SetVehicleCanBeVisiblyDamaged(playerVeh, true)
				SetVehicleTyresCanBurst(playerVeh, true)
				SetEntityInvincible(playerVeh, false)
				SetEntityProofs(playerVeh, false, false, false, false, false, false, false, false)
				SetVehicleWheelsCanBreak(playerVeh, true)
				SetVehicleExplodesOnHighExplosionDamage(playerVeh, true)
				SetEntityOnlyDamagedByPlayer(playerVeh, true)
				SetEntityCanBeDamaged(playerVeh, true)
			end
		elseif (vehgodmode == true) then
			if IsPedInAnyVehicle(GetPlayerPed(-1), true) then
				SetVehicleCanBeVisiblyDamaged(playerVeh, false)
				SetVehicleTyresCanBurst(playerVeh, false)
				SetEntityInvincible(playerVeh, true)
				SetEntityProofs(playerVeh, true, true, true, true, true, true, true, true)
				SetVehicleWheelsCanBreak(playerVeh, false)
				SetVehicleExplodesOnHighExplosionDamage(playerVeh, false)
				SetEntityOnlyDamagedByPlayer(playerVeh, false)
				SetEntityCanBeDamaged(playerVeh, false)
			end
		end
	end
end)


Citizen.CreateThread(function() --Boost On Horn
	while true do
		Citizen.Wait(0)

		local playerVeh = GetVehiclePedIsIn(GetPlayerPed(-1), false)

		if (boostcar == true) and not matchLockVehBoost and not matchLockActive then
			if IsPedInAnyVehicle(GetPlayerPed(-1), true) then
				if IsControlPressed(1, 71) and IsControlPressed(1, 86) then
					SetVehicleBoostActive(playerVeh, 1, 0)
					SetVehicleForwardSpeed(playerVeh, 75.0)
					-- StartScreenEffect("RaceTurbo", 0, 0)  -- تم التعليق لإزالة الفلاش
				elseif IsControlPressed(1, 72) and IsControlPressed(1, 86) then
					SetVehicleBoostActive(playerVeh, 1, 0)
					SetVehicleForwardSpeed(playerVeh, -75.0)
				end
				SetVehicleBoostActive(playerVeh, 0, 0)
			end
		end
	end
end)


Citizen.CreateThread(function() --Hide Extras States
	while true do
		Citizen.Wait(0)
		
		if (showextras == true) then
			Citizen.Wait(10000)
			drawNotification("~r~Extras States Hidden Again")
			showextras = false
		end
	end
end)

Citizen.CreateThread(function() --Show Extras States
	while true do
		Citizen.Wait(0)
		
		local playerVeh = GetVehiclePedIsIn(GetPlayerPed(-1), false)
		local extra = {}

		for i = 1, 14 do
			if DoesExtraExist(playerVeh, i) then
				if (IsVehicleExtraTurnedOn(playerVeh, i) == 1) then
					extra[i] = "ON"
				else
					extra[i] = "OFF"
				end
			else
				extra[i] = "N/A"
			end
		end
		
		if (showextras == true) then
			CustomDraw("~r~" .. extra[1] .. "", 0.900, 0.1550 + 0.0365)
			CustomDraw("~r~" .. extra[2] .. "", 0.900, 0.1915 + 0.0365)
			CustomDraw("~r~" .. extra[3] .. "", 0.900, 0.2280 + 0.0365)
			CustomDraw("~r~" .. extra[4] .. "", 0.900, 0.2645 + 0.0365)
			CustomDraw("~r~" .. extra[5] .. "", 0.900, 0.3010 + 0.0365)
			CustomDraw("~r~" .. extra[6] .. "", 0.900, 0.3375 + 0.0365)
			CustomDraw("~r~" .. extra[7] .. "", 0.900, 0.3740 + 0.0365)
			CustomDraw("~r~" .. extra[8] .. "", 0.900, 0.4105 + 0.0365)
			CustomDraw("~r~" .. extra[9] .. "", 0.900, 0.4470 + 0.0365)
			CustomDraw("~r~" .. extra[10] .. "", 0.900, 0.4835 + 0.0365)
			CustomDraw("~r~" .. extra[11] .. "", 0.900, 0.5200 + 0.0365)
			CustomDraw("~r~" .. extra[12] .. "", 0.900, 0.5565 + 0.0365)
			CustomDraw("~r~" .. extra[13] .. "", 0.900, 0.5930 + 0.0365)
			CustomDraw("~r~" .. extra[14] .. "", 0.900, 0.6295 + 0.0365)
		end
	end
end)

Citizen.CreateThread(function() --Get Current Vehicle Colors (Vehicle Color Menu)
	while true do
		Citizen.Wait(0)

		if IsPedInAnyVehicle(GetPlayerPed(-1), true) then
			vehiclecol = table.pack(GetVehicleColours(GetVehiclePedIsIn(GetPlayerPed(-1), false)))
			extracol = table.pack(GetVehicleExtraColours(GetVehiclePedIsIn(GetPlayerPed(-1), false)))
		end
	end
end)
