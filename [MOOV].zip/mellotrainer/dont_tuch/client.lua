

--[[--------------------------------------------------------------------------
    MelloTrainer - Client Side (Merged)
    (C) Michael Goodwin 2017
    All client-side logic in one file
---------------------------------------------------------------------------]]

-- ============================================================
--  SECTION 3: Main Trainer UI & Controls
-- ============================================================
local fontId = RegisterFontId('A9eelsh')
local settings = {}
RegisterFontFile('A9eelsh')

RegisterNetEvent("mellotrainer:receiveConfigSetting")
AddEventHandler("mellotrainer:receiveConfigSetting",function(name,value)
    settings[name] = value
end)

function teleportToWaypoint()
    local targetPed = GetPlayerPed(-1)
    if(IsPedInAnyVehicle(targetPed))then
        targetPed = GetVehiclePedIsUsing(targetPed)
    end
    if(not IsWaypointActive())then
        drawNotification("<FONT FACE = 'A9eelsh'> ﻻﻭﺍ ﺔﻄﻳﺮﺨﻟﺎﺑ ﻊﻗﻮﻤﻟﺍ ﺩﺪﺣ")
        return
    end
    local waypointBlip = GetFirstBlipInfoId(8)
    local x,y,z = table.unpack(Citizen.InvokeNative(0xFA7C7F0AADF25D09, waypointBlip, Citizen.ResultAsVector()))
    local ground
    local groundFound = false
    local groundCheckHeights = {0.0, 50.0, 100.0, 150.0, 200.0, 250.0, 300.0, 350.0, 400.0,450.0, 500.0, 550.0, 600.0, 650.0, 700.0, 750.0, 800.0}
    for i,height in ipairs(groundCheckHeights) do
        RequestCollisionAtCoord(x, y, height)
        Wait(0)
        SetEntityCoordsNoOffset(targetPed, x,y,height, 0, 0, 1)
        ground,z = GetGroundZFor_3dCoord(x,y,height)
        if(ground) then
            z = z + 3
            groundFound = true
            break;
        end
    end
    if(not groundFound)then
        z = 1000
        GiveDelayedWeaponToPed(PlayerPedId(), 0xFBAB5776, 1, 0)
    end
    SetEntityCoordsNoOffset(targetPed, x,y,z, 0, 0, 1)
end

function syncSettings()
    SetPedInfiniteAmmoClip(GetPlayerPed(), featurePlayerNoReload)
    toggleInfiniteAmmo(featurePlayerInfiniteAmmo)
    DisplayRadar(not featureHideMap)
    DisplayHud(not featureHideHud)
    SetRadarBigmapEnabled(featureBigHud, false)
    SetCanAttackFriendly(GetPlayerPed(-1), true, false)
    NetworkSetFriendlyFireOption(true)
end

local adminStatus = nil
RegisterNetEvent("mellotrainer:adminStatusReceived")
AddEventHandler("mellotrainer:adminStatusReceived", function(status)
    Citizen.Trace("Your Admin Status!: "..tostring(status))
    adminStatus = status
end)

AddEventHandler('onClientMapStart', function()
    TriggerServerEvent("mellotrainer:getAdminStatus")
end)

AddEventHandler("playerSpawned", function()
    if Config.GodModeOnStart and featurePlayerInvincible then
        Citizen.CreateThread(function()
            Citizen.Wait(500)
            local ped = PlayerPedId()
            local pid = PlayerId()
            if DoesEntityExist(ped) then
                SetEntityInvincible(ped, true)
                SetPlayerInvincible(pid, true)
                SetEntityProofs(ped, true, true, true, true, true, true, true, true)
                SetEntityCanBeDamaged(ped, false)
                SetEntityHealth(ped, GetEntityMaxHealth(ped))
                SetPedArmour(ped, 100)
            end
        end)
    end
end)

RegisterNetEvent("mellotrainer:init")
AddEventHandler("mellotrainer:init", function()
    TriggerServerEvent( "mellotrainer:firstJoinProper", PlayerId() )
    syncSettings()
    AddEventHandler("playerSpawned", function(spawn)
        TriggerEvent("mellotrainer:playerSpawned")
    end)
end)

Citizen.CreateThread(function()
    Wait(10000)
    if(adminStatus == nil)then
        TriggerServerEvent("mellotrainer:getAdminStatus")
    end
end)

showtrainer = false
local _menuStyle = {
    applyStyle = true,
    buttonImage        = Config.MenuStyle.buttonImage,
    headerImage        = Config.MenuStyle.headerImage,
    textColor          = Config.MenuStyle.textColor,
    borderColor        = Config.MenuStyle.borderColor,
    accentColor        = Config.MenuStyle.accentColor,
    headerTextColor    = Config.MenuStyle.headerTextColor,
    titleColor         = Config.MenuStyle.titleColor,
    pageColor          = Config.MenuStyle.pageColor,
    pageIndicatorColor = Config.MenuStyle.pageIndicatorColor,
}

Citizen.CreateThread( function()
    while true do
        Citizen.Wait( 0 )
        if matchLockActive and ( IsControlJustReleased( 0, 288 ) or IsControlJustReleased( 0, 170 ) ) and GetLastInputMethod( 0 ) and not IsPauseMenuActive() and not blockinput then
            MatchLockNotify()
        end
        if not matchLockActive and ( IsControlJustReleased( 0, 288 ) ) and GetLastInputMethod( 0 ) and not IsPauseMenuActive() and not blockinput and ((settings["adminOnlyTrainer"] == true and adminStatus == true) or settings["adminOnlyTrainer"] == false) then
            showtrainer = not showtrainer
            SetNuiFocus( true )
            SetNuiFocus( false )
            if showtrainer then
                TriggerEvent("showpicker", false)
                SendNUIMessage(_menuStyle)
                SendNUIMessage({ showtrainer = true })
            else
                SendNUIMessage({ hidetrainer = true })
            end
        end
        if not matchLockActive and ( IsControlJustReleased( 0, 170 ) ) and GetLastInputMethod( 0 ) and not blockinput and ((settings["adminOnlyTrainer"] == true and adminStatus == true) or settings["adminOnlyTrainer"] == false) then
            teleportToWaypoint()
        end
        if showtrainer and not blockinput then
            if ( IsControlJustPressed( 1, 199 ) or IsControlJustPressed( 1, 200 ) ) then
                showtrainer = false
                SendNUIMessage({ hidetrainer = true })
            end
            if ( IsControlJustReleased( 1, 201 ) ) then
                SendNUIMessage({ trainerenter = true })
            elseif ( IsControlJustReleased( 1, 202 ) ) then
                SendNUIMessage({ trainerback = true })
            end
            if ( IsControlJustReleased( 1, 172 ) ) then
                SendNUIMessage({ trainerup = true })
            elseif ( IsControlJustReleased( 1, 173 ) ) then
                SendNUIMessage({ trainerdown = true })
            end
            if ( IsControlJustReleased( 1, 174 ) ) then
                SendNUIMessage({ trainerleft = true })
            elseif ( IsControlJustReleased( 1, 175 ) ) then
                SendNUIMessage({ trainerright = true })
            end
        end
    end
end)

RegisterNUICallback("debug", function(data, cb)
    Citizen.Trace(tostring(data))
end)

RegisterNUICallback("statetoggles", function(data, cb)
    local array = data.data
    local menuID = data.menuid
    Wait(300)
    local results = {}
    for k,v in pairs(array) do
        results[k] = GetToggleState(k)
    end
    local jsonResult = json.encode(results,{indent = true})
    SendNUIMessage({ statetoggles = true, statesdata = jsonResult, menuid = menuID })
    if cb then cb("ok") end
end)

RegisterNUICallback("playsound", function(data, cb)
    PlaySoundFrontend(-1, data.name, "HUD_FRONTEND_DEFAULT_SOUNDSET",  true)
    if cb then cb("ok") end
end)

RegisterNUICallback("trainerclose", function(data, cb)
    showtrainer = false
    if cb then cb("ok") end
end)

function resetTrainerMenus(message)
    SendNUIMessage({ resetmenus = message })
end

Citizen.CreateThread(function()
    local inVeh = false
    while true do
        Wait(100)
        local playerPed = GetPlayerPed(-1)
        local playerVeh = GetVehiclePedIsUsing(playerPed)
        if(IsPedInAnyVehicle(playerPed))then
            if(playerPed == GetPedInVehicleSeat(playerVeh, -1))then
                if(not(inVeh))then
                    TriggerEvent('mellotrainer:playerEnteredVehicle', playerVeh)
                end
                inVeh = true
            end
        else
            inVeh = false
        end
    end
end)

-- ============================================================
--  SECTION 4: Player Options
-- ============================================================

RegisterNUICallback("player", function(data, cb)
    local playerPed = GetPlayerPed(-1)
    local action = data.action
    local newstate = data.newstate
    local text = "~r~OFF"
    if(newstate) then text = "~g~ON" end

    if action == "heal" then
        SetEntityHealth(playerPed, 200)
        ClearPedBloodDamage(playerPed)
        ClearPedWetness(playerPed)
        if(featureKeepWet)then SetPedWetnessHeight(playerPed, 2.0) end
        drawNotification("~g~Cleaned & Healed.")
    elseif action == "armor" then
        SetPedArmour(playerPed, 100)
        drawNotification("~g~Armor Added.")
    elseif action == "suicide" then
        SetEntityHealth(playerPed, 0)
        drawNotification("~r~You Committed Suicide.")
    elseif action == "god" then
        featurePlayerInvincible = newstate
        drawNotification("God Mode: "..tostring(text))
    elseif action == "stamina" then
        featurePlayerInfiniteStamina = newstate
        drawNotification("Unlimited Stamina: "..tostring(text))
    elseif action == "drunk" then
        featurePlayerDrunk = newstate
        drawNotification("Drunk Mode: "..tostring(text))
        featurePlayerDrunkUpdated = true;
    elseif action == "invisible" then
        featurePlayerInvisible = newstate
        drawNotification("Invisibility: "..tostring(text))
        featurePlayerInvisibleUpdated = true;
    elseif action == "silent" then
        featurePlayerNoNoise = newstate
        drawNotification("Silent Mode: "..tostring(text))
        featurePlayerNoNoiseUpdated = true;
    elseif action == "everyone" then
        featurePlayerIgnoredByAll = newstate
        drawNotification("Everyone Ignores You: "..tostring(text))
        featurePlayerIgnoredByAllUpdated = true;
    elseif action == "police" then
        featurePlayerIgnoredByPolice = newstate
        drawNotification("Police Ignore You: "..tostring(text))
        featurePlayerIgnoredByPoliceUpdated = true;
    elseif action == "wanted" then
        featurePlayerNeverWanted = newstate
        drawNotification("Never Wanted: "..tostring(text))
        featurePlayerNeverWantedUpdated = true;
    elseif action == "keepwet" then
        featureKeepWet = newstate
        featureKeepWetUpdated = true;
        drawNotification("Keep Wet: "..tostring(text))
    elseif action == "fastswim" then
        featurePlayerFastSwim = newstate
        featurePlayerFastSwimUpdated = true;
        drawNotification("Fast Swim: "..tostring(text))
    elseif action == "fastrun" then
        featurePlayerFastRun = newstate
        featurePlayerFastRunUpdated = true;
        drawNotification("Fast Run: "..tostring(text))
    elseif action == "superjump" then
        featurePlayerSuperJump = newstate
        drawNotification("Super Jump: "..tostring(text))
    elseif action == "noragdoll" then
        featureNoRagDoll = newstate
        featureNoRagDollUpdated = true
        drawNotification("No Ragdoll: "..tostring(text))
    elseif action == "nightvision" then
        featureNightVision = newstate
        featureNightVisionUpdated = true;
        drawNotification("Night Vision: "..tostring(text))
    elseif action == "thermalvision" then
        featureThermalVision = newstate
        featureThermalVisionUpdated = true;
        drawNotification("Thermal Vision: "..tostring(text))
    elseif action == "radiooff" then
        featureRadioAlwaysOff = newstate
        featureRadioAlwaysOffUpdated = true;
        drawNotification("Radio Always Off: "..tostring(text))
    elseif action == "keepclean" then
        featureKeepClean = newstate
        drawNotification("Keep Clean: "..tostring(text))
    elseif action == "restoreappearance"then
        featureRestoreAppearance = newstate
        drawNotification("Restore Appearance: "..tostring(text))
    end
    if(cb)then cb("ok") end
end)

local function disablePlayerGodMode(playerPed, playerID)
    SetEntityProofs(playerPed, false, false, false, false, false, false, false, false)
    SetEntityInvincible(playerPed, false)
    SetPlayerInvincible(playerID, false)
    SetEntityCanBeDamaged(playerPed, true)
    SetPedCanRagdoll(playerPed, true)
    SetPedCanRagdollFromPlayerImpact(playerPed, true)
    SetPedCanBeKnockedOffVehicle(playerPed, 0)
    SetPedDiesWhenInjured(playerPed, true)
    SetPedDiesInstantlyInWater(playerPed, true)
    SetPedDiesInSinkingVehicle(playerPed, true)
    SetPedSuffersCriticalHits(playerPed, true)
end

Citizen.CreateThread(function()
    while true do
        Wait(1)
        local playerPed = PlayerPedId()
        local playerID = PlayerId()
        if playerPed ~= 0 and DoesEntityExist(playerPed) then
            if(featureKeepWet and featureKeepWetUpdated) then
                SetPedWetnessHeight(playerPed, 2.0)
                featureKeepWetUpdated = false;
            end
            if(featurePlayerNoNoiseUpdated)then
                if(featurePlayerNoNoise)then SetPlayerNoiseMultiplier(playerID, 0.0)
                else SetPlayerNoiseMultiplier(playerID, 1.0) end
                featurePlayerNoNoiseUpdated = false
            end
            if(featurePlayerFastSwimUpdated)then
                if(featurePlayerFastSwim)then SetSwimMultiplierForPlayer(playerID, 1.49)
                else SetSwimMultiplierForPlayer(playerID, 1.0) end
                featurePlayerFastSwimUpdated = false
            end
            if(featurePlayerFastRunUpdated)then
                if(featurePlayerFastRun)then SetRunSprintMultiplierForPlayer(playerID, 1.49)
                else SetRunSprintMultiplierForPlayer(playerID, 1.0) end
                featurePlayerFastRunUpdated = false
            end
            if (featurePlayerSuperJump)then SetSuperJumpThisFrame(playerID) end
            if ( featureNoRagDoll ) then SetPedCanRagdoll( playerPed, false )
            else SetPedCanRagdoll( playerPed, true ) end
            if(featureNightVisionUpdated)then
                SetNightvision(featureNightVision)
                featureNightVisionUpdated = false
            end
            if (featureThermalVisionUpdated)then
                SetSeethrough(featureThermalVision)
                featureThermalVisionUpdated = false
            end
            if (featureRadioAlwaysOffUpdated)then
                if(IsPedInAnyVehicle(playerPed, false))then
                    SetVehicleRadioEnabled(GetVehiclePedIsUsing(playerPed), not featureRadioAlwaysOff)
                end
                SetUserRadioControlEnabled(not featureRadioAlwaysOff)
            end
            if matchLockGod then
                if matchLockGodReset then
                    matchLockGodReset = false
                    disablePlayerGodMode(playerPed, playerID)
                end
            elseif featurePlayerInvincible then
                SetEntityProofs(playerPed, true, true, true, true, true, true, true, true)
                SetEntityInvincible(playerPed, true)
                SetPlayerInvincible(playerID, true)
                SetEntityCanBeDamaged(playerPed, false)
                SetEntityOnlyDamagedByPlayer(playerPed, false)
                SetPedCanRagdoll(playerPed, false)
                SetPedCanRagdollFromPlayerImpact(playerPed, false)
                SetPedCanBeKnockedOffVehicle(playerPed, 1)
                SetPedDiesWhenInjured(playerPed, false)
                SetPedDiesInstantlyInWater(playerPed, false)
                SetPedDiesInSinkingVehicle(playerPed, false)
                SetPedSuffersCriticalHits(playerPed, false)
                if IsPedDeadOrDying(playerPed, true) then
                    -- network resurrect: ResurrectPed only revives the local copy, the other players
                    -- keep a dead / missing ped for him (they stop seeing each other until a reconnect)
                    local coords = GetEntityCoords(playerPed)
                    NetworkResurrectLocalPlayer(coords.x, coords.y, coords.z, GetEntityHeading(playerPed), true, false)
                    playerPed = PlayerPedId()
                    SetEntityHealth(playerPed, GetEntityMaxHealth(playerPed))
                    ClearPedTasksImmediately(playerPed)
                end
                if GetEntityHealth(playerPed) < GetEntityMaxHealth(playerPed) then
                    SetEntityHealth(playerPed, GetEntityMaxHealth(playerPed))
                end
                SetPedArmour(playerPed, 100)
                ClearPedBloodDamage(playerPed)
                ResetPedVisibleDamage(playerPed)
            else
                disablePlayerGodMode(playerPed, playerID)
            end
            if featurePlayerInfiniteStamina then RestorePlayerStamina(playerID, 1.0) end
            if featureKeepClean then ClearPedBloodDamage(playerPed) end
            if ( featurePlayerDrunkUpdated ) then
                SetPedIsDrunk( playerPed, drunk )
                if ( featurePlayerDrunk ) then
                    _LoadClipSet( "move_m@drunk@verydrunk" )
                    SetPedMovementClipset( playerPed, "move_m@drunk@verydrunk", 1.0 )
                    ShakeGameplayCam( "DRUNK_SHAKE", 1.0 )
                else
                    ResetPedMovementClipset( playerPed, 1.0 )
                    StopGameplayCamShaking( true )
                    RemoveClipSet( "move_m@drunk@verydrunk" )
                end
                featurePlayerDrunkUpdated = false;
            end
            if(featurePlayerInvisibleUpdated)then
                if featurePlayerInvisible then SetEntityVisible(playerPed, false, 0)
                else SetEntityVisible(playerPed, true, 0) end
                featurePlayerInvisibleUpdated = false;
            end
            SetEveryoneIgnorePlayer(playerID, featurePlayerIgnoredByAll)
            if(featurePlayerIgnoredByAll) then SuppressShockingEventsNextFrame() end
            SetPoliceIgnorePlayer(playerID, featurePlayerIgnoredByPolice)
            if(featurePlayerIgnoredByPolice) then SetDispatchCopsForPlayer(playerID, false)
            else SetDispatchCopsForPlayer(playerID, true) end
            if(featurePlayerNeverWanted) then
                if(GetPlayerWantedLevel(playerID) > 0) then ClearPlayerWantedLevel(playerID) end
                SetMaxWantedLevel(0)
            else
                SetMaxWantedLevel(5)
            end
        end
    end
end)

-- ============================================================
--  SECTION 6: Skin Management
-- ============================================================

local useNewSystem = true

local components = {
    { name = 'الرأس', t = 0}, { name = 'القناع', t = 1}, { name = 'الشعر', t = 2},
    { name = 'القفازات', t = 3}, { name = 'السروال', t = 4}, { name = 'الشنطة', t = 5},
    { name = 'الحذاء', t = 6}, { name = 'العين', t = 7}, { name = 'البدلة الداخلية', t = 8},
    { name = 'الدروع', t = 9}, { name = 'الملصقات', t = 10}, { name = 'البدلة الخارجية', t = 11}
}

local propComponents = {
    { name = "القبعة", t = 0}, { name = "النظارات", t = 1}, { name = "الوجه", t = 2}
}

local modifyEmpty = "~r~Nothing to modify!"

Citizen.CreateThread(function()
    Citizen.Wait(5000)
    TriggerServerEvent('mellotrainer:loadCharacters')
end)

function SetSkin( skin )
    local ped = GetPlayerPed( -1 )
    if ( DoesEntityExist( ped ) and not IsEntityDead( ped ) ) then
        if ( IsModelValid( skin ) ) then
            RequestModel( skin )
            local attempts = 0
            while not HasModelLoaded( skin ) and attempts < 50 do
                Citizen.Wait( 100 )
                attempts = attempts + 1
            end
            if HasModelLoaded( skin ) then
                SetPlayerModel( PlayerId(), skin )
                Citizen.Wait( 200 )
                SetPedDefaultComponentVariation( GetPlayerPed( -1 ) )
                SetModelAsNoLongerNeeded( skin )
                resetTrainerMenus("playerskinmodify playerpropmodify")
            end
        end
    end
end

local skins = {}
local skinsCount = 0

RegisterNetEvent('mellotrainer:receiveSavedCharacters')
AddEventHandler('mellotrainer:receiveSavedCharacters', function(characters)
    local newSkins = {}
    for i, char in ipairs(characters) do
        newSkins[i] = {
            saveName = char.saveName or ("Character " .. i),
            model = char.model,
            components = char.components,
            props = char.props,
            faceFeatures = char.faceFeatures,
            savedTime = char.savedTime
        }
    end
    skins = newSkins
    skinsCount = #characters
end)

function CreateSkinOptions( index )
    local spawnSkin = { ["menuName"] = "تطبيق", ["data"] = { ["action"] = "spawnsavedskin " .. index } }
    local overwriteSave = { ["menuName"] = "استبدال", ["data"] = { ["action"] = "skinsave " .. index } }
    local renameSkin = { ["menuName"] = "الاسم", ["data"] = { ["action"] = "skinsave " .. index .. " r" } }
    local deleteSkin = { ["menuName"] = "حذف", ["data"] = { ["action"] = "deletesavedskin " .. index } }
    return { spawnSkin, overwriteSave, renameSkin, deleteSkin }
end

RegisterNUICallback( "loadsavedskins", function( data, cb )
    TriggerServerEvent('mellotrainer:loadCharacters')
    Citizen.Wait(100)
    local validOptions = {}
    for k, v in pairs( skins ) do
        local skinOptions = CreateSkinOptions( k )
        table.insert( validOptions, 1, { ["menuName"] = v["saveName"], ["data"] = { ["sub"] = k }, ["submenu"] = skinOptions })
    end
    table.insert( validOptions, { ["menuName"] = "حفظ الشخصية", ["data"] = { ["action"] = "skinsave" } })
    local customJSON = "{}"
    if ( getTableLength( validOptions ) > 0 ) then customJSON = json.encode( validOptions, { indent = true } ) end
    SendNUIMessage( { createmenu = true, menuName = "loadsavedskins", menudata = customJSON } )
    if ( cb ) then cb( "ok" ) end
end )

RegisterNUICallback( "skinsave", function( data, cb )
    Citizen.CreateThread( function()
        local ped = GetPlayerPed( -1 )
        local skinTableData = {}
        local saveName = nil
        local overwriting, renaming, index

        if ( data.action == nil ) then overwriting = false; renaming = false
        else
            if ( data.data[3] ~= nil ) then renaming = true else overwriting = true end
            index = tonumber( data.action )
        end

        if ( DoesEntityExist( ped ) and not IsEntityDead( ped ) ) then
            if (not overwriting and not renaming) or renaming then
                saveName = requestInput( "", 24 )
                if not saveName or saveName == "" then return end
            end

            if ( saveName or overwriting ) then
                local model = GetEntityModel( ped )

                if ( renaming ) then skinTableData["saveName"] = saveName
                elseif ( not overwriting ) then skinTableData["saveName"] = saveName
                else skinTableData["saveName"] = skins[index]["saveName"] end

                skinTableData["model"] = tostring( model )
                local comps = {}
                for i = 0, 11 do
                    local drawable = GetPedDrawableVariation( ped, i )
                    local texture = GetPedTextureVariation( ped, i )
                    comps[i] = { drawable, texture }
                end
                skinTableData["components"] = comps

                local props = {}
                for i = 0, 9 do
                    local drawable = GetPedPropIndex( ped, i )
                    local texture = GetPedPropTextureIndex( ped, i )
                    props[i] = { drawable, texture }
                end
                skinTableData["props"] = props

                if ( not renaming and not overwriting ) then
                    skinsCount = skinsCount + 1
                    skins[skinsCount] = skinTableData
                    TriggerServerEvent('mellotrainer:saveCharacter', skinTableData, nil, saveName)
                    SendNUIMessage({ reshowmenu = true })
                else
                    skins[index] = skinTableData
                    if renaming then TriggerServerEvent('mellotrainer:renameCharacter', index, saveName)
                    else TriggerServerEvent('mellotrainer:saveCharacter', skinTableData, index, skinTableData["saveName"]) end
                    SendNUIMessage({ trainerback = true })
                    SendNUIMessage({ reshowmenu = true })
                end
                resetTrainerMenus( "loadsavedskins" )
            end
        end
    end )
end )

RegisterNUICallback( "spawnsavedskin", function( data, cb )
    local index = tonumber( data.action )
    local saveData = skins[index]
    if saveData then
        Citizen.CreateThread(function()
            local model = tonumber( saveData["model"] )
            local ped = GetPlayerPed( -1 )
            if ( DoesEntityExist( ped ) and not IsEntityDead( ped ) and IsModelValid( model ) ) then
                RequestModel( model )
                local timeout = 0
                while not HasModelLoaded( model ) and timeout < 50 do
                    Citizen.Wait( 100 )
                    timeout = timeout + 1
                end
                if HasModelLoaded( model ) then
                    SetPlayerModel( PlayerId(), model )
                    Citizen.Wait( 500 )
                    SetPedDefaultComponentVariation( GetPlayerPed( -1 ) )
                    Citizen.Wait( 200 )
                    ApplySavedSettingsToPed( saveData )
                    SetModelAsNoLongerNeeded( model )
                    resetTrainerMenus("playerskinmodify playerpropmodify")
                else
                    drawNotification("~r~Failed to load character model")
                end
            else
                drawNotification("~r~Invalid character data")
            end
        end)
    else
        drawNotification("~r~Character not found")
    end
end )

RegisterNUICallback( "deletesavedskin", function( data, cb )
    local index = tonumber( data.action )
    if ( skinsCount > 0 ) then
        skins[index] = nil
        TriggerServerEvent('mellotrainer:deleteCharacter', index)
        SendNUIMessage({ trainerback = true })
        SendNUIMessage({ trainerback = true })
        resetTrainerMenus( "loadsavedskins" )
    end
end )

function ApplySavedSettingsToPed( data )
    local comps = data["components"]
    local props = data["props"]
    local ped = GetPlayerPed( -1 )
    if not DoesEntityExist(ped) then return end
    if comps then
        for k, v in pairs( comps ) do
            local index = tonumber( k )
            if index and v and v[1] and v[2] then
                SetPedComponentVariation( ped, index, v[1], v[2], 0 )
            end
        end
    end
    ClearAllPedProps( ped )
    if props then
        for k, v in pairs( props ) do
            local index = tonumber( k )
            if index and v and v[1] and v[2] and v[1] ~= -1 then
                SetPedPropIndex( ped, index, v[1], v[2], true )
            end
        end
    end
end

RegisterNUICallback("playerskin", function(data, cb)
    local model
    if data.action == "input" then model = GetHashKey(requestInput("", 60))
    else model = GetHashKey(data.action) end
    if(not(IsModelValid(model)))then return end
    RequestModel(model)
    while not HasModelLoaded(model) do Wait(100) end
    SetPlayerModel(PlayerId(), model)
    SetPedDefaultComponentVariation(GetPlayerPed(-1))
    resetTrainerMenus("playerskinmodify playerpropmodify")
    if(cb)then cb("ok")end
end)

RegisterNUICallback("playerskinmodify", function(data, cb)
    local validOptions = {}
    local optCount = 0
    for i=1,#components,1 do
        local validComponents = checkValidComponents(components[i].t)
        if #validComponents > 0 then
            table.insert(validOptions, 1, { ["menuName"] = components[i].name.." ("..#validComponents..")", ["data"] = { ["sub"] = components[i].t }, ["submenu"] = validComponents })
            optCount = optCount + 1
        end
    end
    if (optCount > 0) then
        local SkinJSON = json.encode(validOptions, {indent = true})
        SendNUIMessage({ createmenu = true, menuName = "playerskinmodify", menudata = SkinJSON })
    end
end)

RegisterNUICallback("playerpropmodify", function(data, cb)
    local validOptions = {}
    local optCount = 0
    for i=1,#propComponents,1 do
        local validComponents = checkValidPropComponents(propComponents[i].t)
        if #validComponents > 0 then
            table.insert(validOptions, 1, { ["menuName"] = propComponents[i].name.." ("..#validComponents..")", ["data"] = { ["sub"] = propComponents[i].t }, ["submenu"] = validComponents })
            optCount = optCount + 1
        end
    end
    if (optCount > 0) then
        local PropJSON = json.encode(validOptions, {indent = true})
        SendNUIMessage({ createmenu = true, menuName = "playerpropmodify", menudata = PropJSON })
    end
end)

RegisterNUICallback("defaultskin", function(data, cb)
    local playerPed = GetPlayerPed(-1)
    if(data.action == "skin") then SetPedDefaultComponentVariation(playerPed) end
    if(data.action == "props") then ClearAllPedProps(playerPed) end
    if(cb)then cb("ok")end
end)

RegisterNUICallback("clearpropid", function(data, cb)
    ClearPedProp(GetPlayerPed(-1), tonumber(data.action))
    if(cb)then cb("ok")end
end)

RegisterNUICallback("randomskin", function(data, cb)
    local playerPed = GetPlayerPed(-1)
    if(data.action == "skin") then SetPedRandomComponentVariation(playerPed) end
    if(data.action == "props") then SetPedRandomProps(playerPed) end
    if(cb)then cb("ok")end
end)

local defaultSkinAction = "changeskin skin"
local defaultPropAction = "changeskin props"
RegisterNUICallback("changeskin", function(data, cb)
    local playerPed = GetPlayerPed(-1)
    local componentID = tonumber(data.data[3])
    local drawableID = tonumber(data.data[4]) - 1
    local textureID = tonumber(data.data[5])
    if(textureID == nil)then textureID = 0 end
    if(data.action == "skin") then SetPedComponentVariation(playerPed, componentID, drawableID, textureID)
    elseif(data.action == "props") then SetPedPropIndex(playerPed, componentID, drawableID, textureID, true) end
    if(cb)then cb("ok")end
end)

function checkValidComponents(componentID)
    local playerPed = GetPlayerPed(-1)
    local valid = {}
    local pedCount = GetNumberOfPedDrawableVariations(playerPed, componentID)
    for i = 1, pedCount, 1 do
        local textureCount = GetNumberOfPedTextureVariations(playerPed, componentID, i - 1)
        local textures = {}
        for textureIndex=0,textureCount-1,1 do
            table.insert(textures, { ["menuName"] = "عنصر #"..tostring(textureIndex), ["data"] = { ["hover"] = defaultSkinAction.." "..tostring(componentID).." "..tostring(i).." "..tostring(textureIndex) } })
        end
        if(textureCount > 0)then
            valid[i] = { ["menuName"] = "نوع #"..tostring(i), ["data"] = { ["hover"] = defaultSkinAction.." "..tostring(componentID).." "..tostring(i).." 0", ["sub"] = i }, ["submenu"] = textures }
        end
    end
    return valid
end

function checkValidPropComponents(propID)
    local playerPed = GetPlayerPed(-1)
    local valid = {}
    local propCount = GetNumberOfPedPropDrawableVariations(playerPed, propID)
    for i = 1, propCount, 1 do
        local textureCount = GetNumberOfPedPropTextureVariations(playerPed, propID, i - 1)
        local textures = {}
        for textureIndex=0,textureCount-1,1 do
            table.insert(textures, { ["menuName"] = "عنصر #"..tostring(textureIndex), ["data"] = { ["hover"] = defaultPropAction.." "..tostring(propID).." "..tostring(i).." "..tostring(textureIndex) } })
        end
        if(textureCount > 0)then
            table.insert(valid, { ["menuName"] = "نوع #"..tostring(i), ["data"] = { ["hover"] = defaultPropAction.." "..tostring(propID).." "..tostring(i).." 0", ["sub"] = i }, ["submenu"] = textures })
        end
    end
    if(propCount ~= nil)then
        table.insert(valid, 1, { ["menuName"] = "Clear Prop", ["data"] = { ["hover"] = "clearpropid "..tostring(propID) } })
    end
    return valid
end

local playerSkin = {}
local pmodel = nil
function savePlayerAppearanceVariables(pmod)
    pmodel = pmod
    local ped = PlayerPedId()
    for i=0,12,1 do
        table.insert(playerSkin, { drawable = GetPedDrawableVariation(ped, i), dtexture = GetPedTextureVariation(ped, i), prop = GetPedPropIndex(ped, i), ptexture = GetPedPropTextureIndex(ped, i), palette = GetPedPaletteVariation(ped, i), index = i })
    end
end

function restorePlayerAppearance()
    _LoadModel(pmodel)
    SetPlayerModel(PlayerId(),pmodel)
    local ped = GetPlayerPed(-1)
    for _,obj in pairs(playerSkin) do
        SetPedComponentVariation(ped, obj.index, obj.drawable, obj.dtexture, obj.palette)
        SetPedPropIndex(ped, obj.index, obj.prop, obj.ptexture)
    end
    SetModelAsNoLongerNeeded(pmodel)
end

AddEventHandler("mellotrainer:playerSpawned",function()
    if(featureRestoreAppearance)then restorePlayerAppearance() end
end)

-- ============================================================
--  SECTION 7: New Character System (NEWCHAR)
-- ============================================================

local NEWCHAR = {}
NEWCHAR.savedCharacters = {}
NEWCHAR.currentSlot = 1

NEWCHAR.componentTypes = {
    {name = "Face", id = 0}, {name = "Mask", id = 1}, {name = "Hair", id = 2},
    {name = "Torso", id = 3}, {name = "Legs", id = 4}, {name = "Bags", id = 5},
    {name = "Shoes", id = 6}, {name = "Accessories", id = 7}, {name = "Undershirt", id = 8},
    {name = "Body Armor", id = 9}, {name = "Decals", id = 10}, {name = "Tops", id = 11}
}

NEWCHAR.propTypes = {
    {name = "Hats", id = 0}, {name = "Glasses", id = 1}, {name = "Earrings", id = 2},
    {name = "Watches", id = 6}, {name = "Bracelets", id = 7}
}

function NEWCHAR:GetCurrentCharacterData()
    local ped = PlayerPedId()
    local characterData = { model = GetEntityModel(ped), components = {}, props = {}, faceFeatures = {}, savedTime = "CLIENT_SAVE_" .. GetGameTimer() }
    for _, component in pairs(self.componentTypes) do
        characterData.components[component.id] = { drawable = GetPedDrawableVariation(ped, component.id), texture = GetPedTextureVariation(ped, component.id), palette = GetPedPaletteVariation(ped, component.id) }
    end
    for _, prop in pairs(self.propTypes) do
        local propIndex = GetPedPropIndex(ped, prop.id)
        if propIndex ~= -1 then characterData.props[prop.id] = { drawable = propIndex, texture = GetPedPropTextureIndex(ped, prop.id) }
        else characterData.props[prop.id] = {drawable = -1, texture = -1} end
    end
    for i = 0, 19 do characterData.faceFeatures[i] = GetPedFaceFeature(ped, i) end
    return characterData
end

function NEWCHAR:ApplyCharacterData(characterData)
    if not characterData then return false end
    local playerPed = PlayerPedId()
    if characterData.model and GetEntityModel(playerPed) ~= characterData.model then
        RequestModel(characterData.model)
        while not HasModelLoaded(characterData.model) do Citizen.Wait(0) end
        SetPlayerModel(PlayerId(), characterData.model)
        SetModelAsNoLongerNeeded(characterData.model)
        playerPed = PlayerPedId()
    end
    if characterData.components then
        for componentId, data in pairs(characterData.components) do
            if data.drawable then SetPedComponentVariation(playerPed, componentId, data.drawable, data.texture or 0, data.palette or 0) end
        end
    end
    if characterData.props then
        ClearAllPedProps(playerPed)
        for propId, data in pairs(characterData.props) do
            if data.drawable and data.drawable ~= -1 then SetPedPropIndex(playerPed, propId, data.drawable, data.texture or 0, true) end
        end
    end
    if characterData.faceFeatures then
        for featureId, value in pairs(characterData.faceFeatures) do SetPedFaceFeature(playerPed, featureId, value) end
    end
    return true
end

function NEWCHAR:SaveCurrentCharacter(slotIndex, customName)
    local characterData = self:GetCurrentCharacterData()
    if characterData then TriggerServerEvent('mellotrainer:saveCharacter', characterData, slotIndex, customName); return true
    else return false end
end

function NEWCHAR:LoadCharacter(slotIndex)
    if self.savedCharacters[slotIndex] then
        local success = self:ApplyCharacterData(self.savedCharacters[slotIndex])
        if success then self.currentSlot = slotIndex end
        return success
    else return false end
end

function NEWCHAR:DeleteCharacter(slotIndex)
    if slotIndex and slotIndex > 0 then TriggerServerEvent('mellotrainer:deleteCharacter', slotIndex); return true
    else return false end
end

function NEWCHAR:RenameCharacter(slotIndex, newName)
    if slotIndex and slotIndex > 0 and newName and newName ~= "" then TriggerServerEvent('mellotrainer:renameCharacter', slotIndex, newName); return true
    else return false end
end

function NEWCHAR:RequestCharacters() TriggerServerEvent('mellotrainer:loadCharacters') end

RegisterNetEvent('mellotrainer:receiveSavedCharacters')
AddEventHandler('mellotrainer:receiveSavedCharacters', function(characters) NEWCHAR.savedCharacters = characters or {} end)

Citizen.CreateThread(function() Citizen.Wait(5000); NEWCHAR:RequestCharacters() end)

_G.saveCurrentSkin = function() NEWCHAR:SaveCurrentCharacter(NEWCHAR.currentSlot) end
_G.loadSavedSkin = function(slotIndex) NEWCHAR:LoadCharacter(slotIndex or 1) end
_G.deleteSavedSkin = function(slotIndex) NEWCHAR:DeleteCharacter(slotIndex or 1) end

if wk and wk.menu and wk.menu.addEvent then
    wk.menu:addEvent('saveCurrentSkin', function() NEWCHAR:SaveCurrentCharacter(NEWCHAR.currentSlot) end)
    wk.menu:addEvent('loadSavedSkin', function(slotIndex) NEWCHAR:LoadCharacter(slotIndex or 1) end)
    wk.menu:addEvent('deleteSavedSkin', function(slotIndex) NEWCHAR:DeleteCharacter(slotIndex or 1) end)
end

_G.NEWCHAR = NEWCHAR

-- ============================================================
--  SECTION 8: Online Players
-- ============================================================

local drawRouteTarget = nil

function getOnlinePlayersAndNames()
    local players = {}
    local me = PlayerId()
    local activePlayers = GetActivePlayers()
    for _, i in ipairs(activePlayers) do
        if i ~= me and NetworkIsPlayerConnected(i) then
            table.insert(players, { ['ped'] = GetPlayerPed(i), ['menuName'] = GetPlayerName(i), ['data'] = { ['sub'] = "playeroptions", ['share'] = GetPlayerServerId(i) }, ['id'] = i })
        end
    end
    return players
end

function spectatePlayer(target)
    local playerPed = GetPlayerPed(-1)
    if(featureSpectate)then
        if (not IsScreenFadedOut() and not IsScreenFadingOut()) then
            DoScreenFadeOut(1000)
            while (not IsScreenFadedOut()) do Wait(0) end
            local targetpos = GetEntityCoords(target['ped'], false)
            RequestCollisionAtCoord(targetpos['x'],targetpos['y'],targetpos['z'])
            NetworkSetInSpectatorMode(true, target['ped'])
            if(IsScreenFadedOut()) then DoScreenFadeIn(1000) end
        end
        drawNotification("Spectating ~b~<C>"..target['menuName'].."</C>.")
    else
        if(not IsScreenFadedOut() and not IsScreenFadingOut()) then
            DoScreenFadeOut(1000)
            while (not IsScreenFadedOut()) do Wait(0) end
            local targetpos = GetEntityCoords(playerPed, false)
            RequestCollisionAtCoord(targetpos['x'],targetpos['y'],targetpos['z'])
            NetworkSetInSpectatorMode(false, target['ped'])
            if(IsScreenFadedOut()) then DoScreenFadeIn(1000) end
        end
        drawNotification("Stopped Spectating ~b~<C>"..target['menuName'].."</C>.")
    end
end

function drawRoute(target)
    if (featureDrawRoute) then
        if (DoesEntityExist(target['ped'])) then
            local drawroute = GetEntityCoords(target['ped'], false)
            SetNewWaypoint(drawroute['x'], drawroute['y'])
            drawNotification("Drawing Live Route To:~n~~b~<C>"..target['menuName'].."</C>.")
        end
    else
        SetWaypointOff()
        drawNotification("Route Removed.")
    end
end

function updateDrawRoute()
    if(not IsWaypointActive())then featureDrawRoute = false; return end
    local target = drawRouteTarget
    if(featureDrawRoute)then
        if(NetworkIsPlayerConnected(target['id']))then
            local drawroute = GetEntityCoords(target['ped'], false)
            SetNewWaypoint(drawroute['x'], drawroute['y'])
        else
            SetWaypointOff(); featureDrawRoute = false; drawRouteTarget = nil
            drawNotification("Player "..target['menuName'].." has ~r~<C>disconnected</C>.")
        end
    end
end

function teleportToPlayer(target)
    local playerPed = GetPlayerPed(-1)
    if(DoesEntityExist(target['ped']))then
        NetworkSetInSpectatorMode(false, target['ped']); featureSpectate = false
    end
    local targetPed = playerPed
    if(IsPedInAnyVehicle(playerPed, 0))then
        local v = GetVehiclePedIsUsing(playerPed)
        if(GetPedInVehicleSeat(v, -1) == playerPed) then targetPed = v end
    else ClearPedTasksImmediately(playerPed) end
    local x,y,z = table.unpack(GetEntityCoords(target['ped']))
    z = z + 3.5
    RequestCollisionAtCoord(x,y,z)
    SetEntityCoordsNoOffset(targetPed, x,y,z, 0, 0, 1)
    drawNotification("Teleported to ~b~<C>"..target['menuName'].."</C>.")
end

function teleportIntoPlayerVehicle(target)
    local playerPed = GetPlayerPed(-1)
    local x,y,z = table.unpack(GetEntityCoords(target['ped']))
    RequestCollisionAtCoord(x,y,z)
    if(not IsPedInAnyVehicle(target['ped'], false))then drawNotification("~b~<C>"..target['menuName'].."</C> ~s~is not in any vehicle"); return end
    local targetVeh = GetVehiclePedIsIn(target['ped'], false)
    if(targetVeh == GetVehiclePedIsIn(playerPed))then drawNotification("You are already in ".."~b~<C>"..target['menuName'].."'s</C> ~s~vehicle."); return end
    if(GetVehicleDoorsLockedForPlayer(targetVeh, playerPed))then drawNotification("~b~<C>"..target['menuName'].."'s</C> ~s~vehicle is locked."); return end
    local seatNum = 0 + GetVehicleNumberOfPassengers(targetVeh)
    local passNum = GetVehicleMaxNumberOfPassengers(targetVeh)
    while (seatNum < passNum) do
        if(IsVehicleSeatFree(targetVeh, seatNum))then
            ClearPedTasksImmediately(PlayerPedId())
            SetPedIntoVehicle(playerPed, targetVeh, seatNum)
            NetworkSetInSpectatorMode(false, target['ped'])
            break
        else seatNum = seatNum + 1 end
    end
    if (seatNum >= passNum) then drawNotification("~b~<C>"..target['menuName'].."'s</C> ~s~vehicle is full."); return end
    drawNotification("Teleported into ~b~<C>"..target['menuName'].."'s</C> ~s~vehicle.")
end

function toggleRelationshipBlip(colorID, typeText, target)
    local blip = GetBlipFromEntity(target['ped']);
    SetBlipColour(blip, colorID)
    SetBlipNameToPlayerName(blip, target['menuName'])
    drawNotification("Marked ~b~<C>"..target['menuName'].."</C>~s~ as "..typeText)
end

RegisterNUICallback("otherplayer", function(data, cb)
    local playerPed = GetPlayerPed(-1)
    local allPlayers = getOnlinePlayersAndNames()
    local action = data.action
    local newstate = data.newstate
    local targetServerID
    if action == "relationship" then targetServerID = tonumber(data.data[4])
    else targetServerID = tonumber(data.data[3]) end
    local target = nil
    for _,value in pairs(allPlayers) do
        if(tostring(value.data.share) == tostring(targetServerID))then target = value end
    end
    if(target == nil)then drawNotification("Player has ~r~<C>disconnected</C>."); return end
    local text = "~r~OFF"
    if(newstate) then text = "~g~ON" end
    if action == "relationship" then
        local relationshipType = data.data[3]
        if(relationshipType == "friendly")then toggleRelationshipBlip(3, "Friendly",target)
        elseif(relationshipType == "normal")then toggleRelationshipBlip(0, "Normal",target)
        elseif(relationshipType == "hostile")then toggleRelationshipBlip(1, "Hostile",target) end
    elseif action == "teleportto" then teleportToPlayer(target)
    elseif action == "teleportinside" then teleportIntoPlayerVehicle(target)
    elseif action == "drawroute" then
        featureDrawRoute = newstate; drawRouteTarget = target; drawRoute(target)
    elseif action == "spectate" then
        featureSpectate = newstate; spectatePlayer(target)
    end
    cb("ok")
end)

RegisterNUICallback("getonlineplayers", function(data,cb)
    local players = getOnlinePlayersAndNames()
    if(getTableLength(players) < 1)then
        drawNotification("<FONT FACE = 'A9eelsh' >~r~! . . ﺮﻓﺮﻴﺴﻟﺎﺑ ﻦﻴﺒﻋﻻ ﺪﺟﻮﻳﻻ "); return
    end
    SendNUIMessage({ createmenu = true, autorefreshmenu = true, menuName = "getonlineplayers", menudata = json.encode(players, {indent = true}) })
end)

Citizen.CreateThread(function()
    while true do
        Wait(2000)
        if(featureDrawRoute)then updateDrawRoute() end
    end
end)

-- ============================================================
--  SECTION 9: Vehicles (MERGED from cl_vehicles.lua + vehicles.lua)
-- ============================================================

local function _SetEntityAsNoLongerNeeded(entity)
    Citizen.InvokeNative(0xB736A491E64A32CF,Citizen.PointerValueIntInitialized(entity))
end

local lastVehicle

local function SpawnVehicle(model, x, y, z, heading, ped)
    if not lastVehicle and GetVehiclePedIsIn(ped, false) then
        lastVehicle = GetVehiclePedIsIn(ped, false)
    end
    if IsModelValid(model) then
        _LoadModel( model )
        local veh = CreateVehicle( model, x, y, z + 1, heading, true, true )
        if featureSpawnInsideCar then SetPedIntoVehicle(ped, veh, -1) end
        if featureDeleteLastVehicle then
            _SetEntityAsNoLongerNeeded(veh)
            if (lastVehicle) then
                if(GetVehicleNumberOfPassengers(lastVehicle) ~= 0 or IsVehicleSeatFree(lastVehicle, -1) == false) then
                else
                    SetEntityAsMissionEntity(lastVehicle, true, true)
                    DeleteVehicle(lastVehicle)
                end
            end
        end
        lastVehicle = veh
        UpdateVehicleFeatureVariables( veh )
        SetModelAsNoLongerNeeded( veh )
        return veh
    else
        drawNotification("<FONT FACE = 'A9eelsh'>"..'~r~! ﻞﻤﻌﺗﻻ ﺔﺒﻛﺮﻤﻟﺍ')
    end
end

RegisterNUICallback("vehspawnoptions", function(data,cb)
    local text = "~r~OFF"
    if(data.newstate) then text = "~g~ON" end
    if data.action == "despawn" then featureDeleteLastVehicle = data.newstate; drawNotification("Delete Previous Vehicle: "..tostring(text))
    elseif data.action == "insidecar" then featureSpawnInsideCar = data.newstate; drawNotification("Spawn Into Vehicle: "..tostring(text))
    elseif data.action == "infront" then featureSpawnCarInFront = data.newstate; drawNotification( "Spawn vehicle in front: " .. tostring( text ) ) end
    if(cb)then cb("ok") end
end)

RegisterNUICallback("vehspawn", function(data, cb)
    local playerPed = GetPlayerPed(-1)
    local x, y, z
    x, y, z = table.unpack( GetEntityCoords( playerPed, true ) )
    local heading = GetEntityHeading(playerPed)
    if data.action == "input" then
        local result = requestInput("", 60)
        if result then
            local vehicle = SpawnVehicle(GetHashKey(string.upper(result)), x, y, z, heading, playerPed)
            UpdateVehicleFeatureVariables( vehicle )
        end
        return
    end
    local vehicle = SpawnVehicle(GetHashKey(data.action), x, y, z, heading, playerPed)
    UpdateVehicleFeatureVariables( vehicle )
    if ( cb ) then cb( "ok" ) end
end)

local vehicles = {}
local vehicleCount = 0

function CreateVehicleOptions( index )
    return {
        { ["menuName"] = "Spawn Car", ["data"] = { ["action"] = "spawnsavedveh " .. index } },
        { ["menuName"] = "Overwrite With Current", ["data"] = { ["action"] = "vehiclesave " .. index } },
        { ["menuName"] = "Rename Save", ["data"] = { ["action"] = "vehiclesave " .. index .. " r" } },
        { ["menuName"] = "Delete", ["data"] = { ["action"] = "deletesavedveh " .. index } },
    }
end

RegisterNUICallback( "loadsavedvehs", function( data, cb )
    local validOptions = {}
    for k, v in pairs( vehicles ) do
        table.insert( validOptions, 1, { ["menuName"] = v["saveName"], ["data"] = { ["sub"] = k }, ["submenu"] = CreateVehicleOptions( k ) })
    end
    table.insert( validOptions, { ["menuName"] = "Create New Vehicle Save", ["data"] = { ["action"] = "vehiclesave" } })
    local customJSON = "{}"
    if ( getTableLength( validOptions ) > 0 ) then customJSON = json.encode( validOptions, { indent = true } ) end
    SendNUIMessage( { createmenu = true, menuName = "loadsavedvehs", menudata = customJSON } )
    if ( cb ) then cb( "ok" ) end
end )

RegisterNUICallback( "vehiclesave", function( data, cb )
    Citizen.CreateThread( function()
        local ped = GetPlayerPed( -1 )
        local vehicleTableData = {}
        local saveName = nil
        local overwriting, renaming, index

        if ( data.action == nil ) then overwriting = false; renaming = false
        else
            if ( data.data[3] ~= nil ) then renaming = true else overwriting = true end
            index = tonumber( data.action )
        end

        if ( DoesEntityExist( ped ) and not IsEntityDead( ped ) ) then
            local veh = GetVehiclePedIsIn( ped, false )
            if ( GetPedInVehicleSeat( veh, -1 ) == ped ) then
                while ( (saveName == nil and not overwriting) or (saveName == nil and renaming) ) do
                    saveName = requestInput( "Enter save name", 24 )
                    Citizen.Wait( 1 )
                end
                if ( saveName or overwriting or renaming ) then
                    local model = GetEntityModel( veh )
                    local primaryColour, secondaryColour = GetVehicleColours( veh )
                    local pearlColour, wheelColour = GetVehicleExtraColours( veh )
                    local mod1a, mod1b, mod1c = GetVehicleModColor_1( veh )
                    local mod2a, mod2b = GetVehicleModColor_2( veh )
                    local custR1, custG1, custB1, custR2, custG2, custB2
                    if ( GetIsVehiclePrimaryColourCustom( veh ) ) then custR1, custG1, custB1 = GetVehicleCustomPrimaryColour( veh ) end
                    if ( GetIsVehicleSecondaryColourCustom( veh ) ) then custR2, custG2, custB2 = GetVehicleCustomSecondaryColour( veh ) end
                    if ( renaming or not overwriting ) then vehicleTableData["saveName"] = saveName
                    else vehicleTableData["saveName"] = vehicles[index]["saveName"] end
                    vehicleTableData["model"] = tostring( model )
                    vehicleTableData["primaryColour"] = primaryColour
                    vehicleTableData["secondaryColour"] = secondaryColour
                    vehicleTableData["pearlColour"] = pearlColour
                    vehicleTableData["wheelColour"] = wheelColour
                    vehicleTableData["mod1Colour"] = { mod1a, mod1b, mod1c }
                    vehicleTableData["mod2Colour"] = { mod2a, mod2b }
                    vehicleTableData["custPrimaryColour"] = { custR1, custG1, custB1 }
                    vehicleTableData["custSecondaryColour"] = { custR2, custG2, custB2 }
                    vehicleTableData["livery"] = GetVehicleLivery( veh )
                    vehicleTableData["plateText"] = GetVehicleNumberPlateText( veh )
                    vehicleTableData["plateType"] = GetVehicleNumberPlateTextIndex( veh )
                    vehicleTableData["wheelType"] = GetVehicleWheelType( veh )
                    vehicleTableData["windowTint"] = GetVehicleWindowTint( veh )
                    vehicleTableData["burstableTyres"] = GetVehicleTyresCanBurst( veh )
                    vehicleTableData["customTyres"] = GetVehicleModVariation( veh, 23 )
                    local neonR, neonG, neonB = GetVehicleNeonLightsColour( veh )
                    local smokeR, smokeG, smokeB = GetVehicleTyreSmokeColor( veh )
                    local neonToggles = {}
                    for i = 0, 3 do if ( IsVehicleNeonLightEnabled( veh, i ) ) then table.insert( neonToggles, i ) end end
                    vehicleTableData["neonColour"] = { neonR, neonG, neonB }
                    vehicleTableData["smokeColour"] = { smokeR, smokeG, smokeB }
                    vehicleTableData["neonToggles"] = neonToggles
                    local extras = {}
                    if ( DoesVehicleHaveExtras( veh ) ) then
                        for i = 1, 30 do
                            if ( DoesExtraExist( veh, i ) ) then
                                if ( IsVehicleExtraTurnedOn( veh, i ) ) then table.insert( extras, i ) end
                            end
                        end
                    end
                    vehicleTableData["extras"] = extras
                    local mods = {}
                    for i = 0, 49 do
                        local isToggle = ( i >= 17 ) and ( i <= 22 )
                        if ( isToggle ) then mods[i] = IsToggleModOn( veh, i ) else mods[i] = GetVehicleMod( veh, i ) end
                    end
                    vehicleTableData["mods"] = mods

                    if ( not renaming and not overwriting ) then
                        vehicleCount = vehicleCount + 1
                        vehicles[vehicleCount] = vehicleTableData
                        SendNUIMessage({ reshowmenu = true })
                    else
                        vehicles[index] = vehicleTableData
                        SendNUIMessage({ trainerback = true })
                        SendNUIMessage({ reshowmenu = true })
                    end
                    resetTrainerMenus( "loadsavedvehs" )
                end
            end
        end
    end )
end )

RegisterNUICallback( "spawnsavedveh", function( data, cb )
    local saveData = vehicles[ tonumber( data.action ) ]
    local model = tonumber( saveData["model"] )
    local ped = GetPlayerPed( -1 )
    if ( DoesEntityExist( ped ) and not IsEntityDead( ped ) ) then
        local x, y, z
        if ( featureSpawnInsideCar ) then x, y, z = table.unpack( GetEntityCoords( ped, true ) )
        else x, y, z = table.unpack( GetOffsetFromEntityInWorldCoords( ped, 0.0, 7.5, 0.0 ) ) end
        local vehicle = SpawnVehicle( model, x, y, z, GetEntityHeading( ped ), ped )
        ApplySavedSettingsToVehicle( vehicle, saveData )
    end
end )

RegisterNUICallback( "deletesavedveh", function( data, cb )
    local index = tonumber( data.action )
    if ( vehicleCount > 0 ) then
        vehicles[index] = nil
        SendNUIMessage({ trainerback = true })
        SendNUIMessage({ trainerback = true })
        resetTrainerMenus( "loadsavedvehs" )
    end
end )

function ApplySavedSettingsToVehicle( veh, data )
    SetVehicleModKit( veh, 0 )
    SetVehicleTyresCanBurst( veh, data["burstableTyres"] )
    SetVehicleNumberPlateTextIndex( veh, data["plateType"] )
    SetVehicleNumberPlateText( veh, data["plateText"] )
    SetVehicleWindowTint( veh, data["windowTint"] )
    SetVehicleWheelType( veh, data["wheelType"] )
    for i = 1, 30 do if ( DoesExtraExist( veh, i ) ) then SetVehicleExtra( veh, i, true ) end end
    for k, v in pairs( data["extras"] ) do SetVehicleExtra( veh, tonumber( v ), false ) end
    for k, v in pairs( data["mods"] ) do
        local k = tonumber( k )
        local isToggle = ( k >= 17 ) and ( k <= 22 )
        if ( isToggle ) then ToggleVehicleMod( veh, k, v ) else SetVehicleMod( veh, k, v, 0 ) end
    end
    local currentMod = GetVehicleMod( veh, 23 )
    SetVehicleMod( veh, 23, currentMod, data["customTyres"] )
    SetVehicleMod( veh, 24, currentMod, data["customTyres"] )
    if ( data["livery"] ~= -1 ) then SetVehicleLivery( veh, data["livery"] ) end
    SetVehicleExtraColours( veh, data["pearlColour"], data["wheelColour"] )
    SetVehicleModColor_1( veh, data["mod1Colour"][1], data["mod1Colour"][2], data["mod1Colour"][3] )
    SetVehicleModColor_2( veh, data["mod2Colour"][1], data["mod2Colour"][2] )
    SetVehicleColours( veh, data["primaryColour"], data["secondaryColour"] )
    local cp = data["custPrimaryColour"]
    if ( cp[1] ~= nil and cp[2] ~= nil and cp[3] ~= nil ) then SetVehicleCustomPrimaryColour( veh, cp[1], cp[2], cp[3] ) end
    local cs = data["custSecondaryColour"]
    if ( cs[1] ~= nil and cs[2] ~= nil and cs[3] ~= nil ) then SetVehicleCustomSecondaryColour( veh, cs[1], cs[2], cs[3] ) end
    SetVehicleNeonLightsColour( veh, data["neonColour"][1], data["neonColour"][2], data["neonColour"][3] )
    for i = 0, 3 do SetVehicleNeonLightEnabled( veh, i, false ) end
    for k, v in pairs( data["neonToggles"] ) do SetVehicleNeonLightEnabled( veh, tonumber( v ), true ) end
    SetVehicleDirtLevel( veh, 0.0 )
    UpdateVehicleFeatureVariables( veh )
end

function updateVehicleMechDamage(veh)
    SetVehicleEngineCanDegrade(veh, not featureVehMechDamage)
    SetVehicleCanBreak(veh, not featureVehMechDamage)
    SetVehicleWheelsCanBreak(veh, not featureVehMechDamage)
    SetDisableVehiclePetrolTankDamage(veh, featureVehMechDamage)
end

function updateVehicleCosmDamage(veh)
    SetVehicleCanBeVisiblyDamaged(veh, not featureVehCosDamage)
    SetVehicleStrong(veh, featureVehCosDamage)
    for i=0,6 do SetVehicleDoorBreakable(veh, i, not featureVehCosDamage) end
end

function UpdateVehicleFeatureVariables( veh )
    featureBulletproofWheels = not GetVehicleTyresCanBurst( veh )
    featureXeonLights = IsToggleModOn( veh, 22 )
    featureCustomTires = GetVehicleModVariation( veh, 23 )
    featureTurboMode = IsToggleModOn( veh, 18 )
    featureNeonLeft = IsVehicleNeonLightEnabled( veh, 0 )
    featureNeonRight = IsVehicleNeonLightEnabled( veh, 1 )
    featureNeonFront = IsVehicleNeonLightEnabled( veh, 2 )
    featureNeonRear = IsVehicleNeonLightEnabled( veh, 3 )
    updateVehicleCosmDamage(veh)
    updateVehicleMechDamage(veh)
    SetEntityInvincible(veh, featureVehInvincible)
    windows = {false, false, false, false}
    featureTorqueMultiplier = 1
    featurePowerMultiplier = 1
    featureLowerForce = 0
    resetTrainerMenus( "vehmods" )
end

RegisterNUICallback("vehcolor", function(data, cb)
    local playerPed = GetPlayerPed(-1)
    local playerVeh = GetVehiclePedIsIn(playerPed, false)
    local color = stringsplit(data.action, ",")
    if not playerVeh then return end
    SetVehicleCustomPrimaryColour(playerVeh, tonumber(color[1]), tonumber(color[2]), tonumber(color[3]))
    SetVehicleCustomSecondaryColour(playerVeh, tonumber(color[1]), tonumber(color[2]), tonumber(color[3]))
    if(cb)then cb("ok") end
end)

RegisterNUICallback("requirevehicle", function(data, cb)
    local playerPed = GetPlayerPed(-1)
    local playerVeh = GetVehiclePedIsIn(playerPed, false)
    if playerVeh <= 0 then
    elseif(not(playerPed == (GetPedInVehicleSeat(playerVeh,-1))))then
    else
        local vehClass = GetVehicleClass(playerVeh)
        if (vehClass == 14 or vehClass == 21) then
            drawNotification("<FONT FACE = 'A9eelsh'>"..'~r~!ﻞﻳﺪﻌﺘﻟﺍ ﻢﻋﺪﺗ ﻻ')
        else
            local data = createVariableData()
            SetVehicleModKit(playerVeh, 0)
            SendNUIMessage({vehicleaccess = true, updateVariables = true, data = data})
        end
    end
end)

-- MERGED veh callback (cl_vehicles.lua + vehicles.lua actions)
local windows = {false, false, false,false}
RegisterNUICallback("veh", function(data, cb)
    local playerPed = GetPlayerPed(-1)
    local playerVeh = GetVehiclePedIsIn(playerPed, false)
    local playerVehLast = GetVehiclePedIsIn(playerPed, true)
    local action = data.action
    local newstate = data.newstate
    local text,text2
    if(newstate) then text = "~g~ON"; text2 = "~r~OFF"
    else text = "~r~OFF"; text2 = "~g~ON" end

    -- From vehicles.lua
    if action == "fixclean" then
        if IsPedInAnyVehicle(playerPed, 0) and (GetPedInVehicleSeat(playerVehLast, -1) == playerPed) then
            SetVehicleFixed(playerVehLast); SetVehicleDirtLevel(playerVehLast, 0.0)
            SetVehicleLights(playerVehLast, 0); SetVehicleBurnout(playerVehLast, false)
            Citizen.InvokeNative(0x1FD09E7390A74D54, playerVehLast, 0)
            drawNotification("~g~Vehicle repaired & cleaned!")
        else drawNotification("~r~You Aren't In The Driverseat Of A Vehicle!") end
    elseif action == "fuckup" then
        if IsPedInAnyVehicle(playerPed, 0) and (GetPedInVehicleSeat(playerVehLast, -1) == playerPed) then
            StartVehicleAlarm(playerVehLast); DetachVehicleWindscreen(playerVehLast)
            for i=0,3 do SmashVehicleWindow(playerVehLast, i) end
            for i=0,7 do SetVehicleTyreBurst(playerVehLast, i, true, 1000.0) end
            for i=0,7 do SetVehicleDoorBroken(playerVehLast, i, true) end
            SetVehicleLights(playerVehLast, 1)
            Citizen.InvokeNative(0x1FD09E7390A74D54, playerVehLast, 1)
            SetVehicleNumberPlateTextIndex(playerVehLast, 5)
            SetVehicleNumberPlateText(playerVehLast, "ANALSWAG")
            SetVehicleDirtLevel(playerVehLast, 10.0)
            SetVehicleModColor_1(playerVehLast, 1); SetVehicleModColor_2(playerVehLast, 1)
            SetVehicleCustomPrimaryColour(playerVehLast, 255, 51, 255)
            SetVehicleCustomSecondaryColour(playerVehLast, 255, 51, 255)
            SetVehicleBurnout(playerVehLast, true)
            drawNotification("~g~Vehicle Fucked Up!")
        else drawNotification("~r~You Aren't In The Driverseat Of A Vehicle!") end
    elseif action == "delete" then
        if IsPedInAnyVehicle(playerPed, 0) and (GetPedInVehicleSeat(playerVehLast, -1) == playerPed) then
            SetEntityAsMissionEntity(playerVehLast, 1, 1); DeleteVehicle(playerVehLast)
            drawNotification("~g~Vehicle Deleted!")
        else drawNotification("~r~You Aren't In The Driverseat Of A Vehicle!") end
    elseif action == "vehiclegodmode" then
        vehgodmode = newstate
        SetVehicleFixed(playerVehLast); SetVehicleDirtLevel(playerVehLast, 0.0)
        SetVehicleEngineHealth(playerVehLast, 1000.0)
        if (vehgodmode == false) then drawNotification("~g~Vehicle Godmode Enabled!")
        else drawNotification("~r~Vehicle Godmode Disabled!") end
    elseif action == "hornboost" then
        boostcar = newstate
        if (boostcar == true) then drawNotification("~g~Boost Car Enabled!")
        else drawNotification("~r~Boost Car Disabled!") end

    -- From cl_vehicles.lua
    elseif action == "toggleinstantly" then
        featureCloseInstantly = newstate; drawNotification("Open Doors Instantly: "..text)
    elseif action == "speedometer" then
        featureSpeedometer = newstate; drawNotification("Speedometer: "..text)
    elseif action == "set" then
        if playerVeh > 0 then SetVehicleOnGroundProperly(playerVeh) end
    elseif action == "fixset" then
        if playerVeh > 0 then SetVehicleFixed(playerVeh); SetVehicleDirtLevel(playerVeh, 0.0); SetVehicleOnGroundProperly(playerVeh) end
    elseif action == "fix" then
        if playerVeh > 0 then SetVehicleFixed(playerVeh) end
    elseif action == "dirty" then
        if playerVeh > 0 then SetVehicleDirtLevel(playerVeh, 15.0) end
    elseif action == "clean" then
        if playerVeh > 0 then SetVehicleDirtLevel(playerVeh, 0.0) end
    elseif action == "toggledoor" then
        if playerVeh > 0 then
            local doorInt = tonumber(data.data[3])
            if GetVehicleDoorAngleRatio(playerVeh, doorInt) == 0 then SetVehicleDoorOpen(playerVeh, doorInt, false, featureCloseInstantly)
            else SetVehicleDoorShut(playerVeh, doorInt, featureCloseInstantly) end
        end
    elseif action == "closeall" then
        if playerVeh > 0 then SetVehicleDoorsShut(playerVeh, featureCloseInstantly) end
    elseif action == "openall" then
        if playerVeh > 0 then for i=0, 6, 1 do SetVehicleDoorOpen(playerVeh, i, false, featureCloseInstantly) end end
    elseif action == "togglealldoors" then
        if playerVeh > 0 then
            local allClosed = true
            for i=0, 6, 1 do if GetVehicleDoorAngleRatio(playerVeh, i) > 0 then allClosed = false; break end end
            if allClosed then for i=0, 6, 1 do SetVehicleDoorOpen(playerVeh, i, false, featureCloseInstantly) end
            else SetVehicleDoorsShut(playerVeh, featureCloseInstantly) end
        end
    elseif action == "rollwindows" then
        if playerVeh > 0 then
            local truecount = 0
            for i=1,4,1 do if windows[i] then truecount = truecount + 1 end end
            if truecount > 2 then
                for i=1,4,1 do RollUpWindow(playerVeh, i-1); windows[i] = false end
            else
                RollDownWindows(playerVeh); for i=1,4,1 do windows[i] = true end
            end
        end
    elseif action == "rollwindow" then
        if playerVeh > 0 then
            local windowInt = tonumber(data.data[3])
            if(windows[windowInt + 1]) then RollUpWindow(playerVeh, windowInt)
            else RollDownWindow(playerVeh, windowInt) end
            windows[windowInt + 1] = not windows[windowInt + 1]
        end
    elseif action == "fixwindow" then
        if playerVeh > 0 then FixVehicleWindow(playerVeh, tonumber(data.data[3])) end
    elseif action == "fixwindows" then
        if playerVeh > 0 then for i=0,3,1 do FixVehicleWindow(playerVeh, i) end end
    elseif action == "twowheel" then
        featureVehicleTwoWheel = newstate
        TriggerEvent('twowheel:toggle', newstate)
    end
    if(cb)then cb("ok") end
end)

RegisterNUICallback("vehmod", function(data, cb)
    local playerPed = GetPlayerPed(-1)
    local playerVeh = GetVehiclePedIsIn(playerPed, false)
    local action = data.action
    local text = "~r~OFF"
    if(data.newstate) then text = "~g~ON" end
    if playerVeh <= 0 then SendNUIMessage({toggleerror = true}); return end
    SetVehicleModKit(playerVeh, 0)

    if action == "bulletwheels" then
        featureBulletproofWheels = data.newstate; SetVehicleTyresCanBurst(playerVeh, not featureBulletproofWheels)
        drawNotification("Bulletproof Tires: "..text)
    elseif action == "xenonlights" then
        featureXeonLights = data.newstate; ToggleVehicleMod(playerVeh, 22, featureXeonLights)
        drawNotification("Xenon headlights: "..text)
    elseif action == "customtires" then
        featureCustomTires = data.newstate
        SetVehicleMod(playerVeh, 23, GetVehicleMod(playerVeh, 23), featureCustomTires)
        if ( (featureCustomTires and not GetVehicleModVariation(playerVeh, 23)) or (not featureCustomTires and GetVehicleModVariation(playerVeh, 23)) ) then SendNUIMessage({toggleerror = true}) end
        drawNotification("Custom Tires: "..text)
    elseif action == "turbomode" then
        featureTurboMode = data.newstate; ToggleVehicleMod(playerVeh, 18, data.newstate)
        drawNotification("Turbo Mode: "..text)
    elseif action == "windowtint" then SetVehicleWindowTint(playerVeh, tonumber(data.data[3]))
    elseif action == "plate" then SetVehicleNumberPlateTextIndex(playerVeh, tonumber(data.data[3]))
    elseif action == "platetext" then
        local result = requestInput(GetVehicleNumberPlateText(playerVeh), 8)
        if result then SetVehicleNumberPlateText(playerVeh, result) end
    elseif action == "smokecolor" then
        ToggleVehicleMod(playerVeh, 20, true)
        SetVehicleTyreSmokeColor(playerVeh, tonumber(data.data[3]), tonumber(data.data[4]), tonumber(data.data[5]))
    elseif action == "neonlights" then
        local location = data.data[3]
        local id
        if(location == "left")then featureNeonLeft = data.newstate; id = 0
        elseif(location == "right")then featureNeonRight = data.newstate; id = 1
        elseif(location == "front")then featureNeonFront = data.newstate; id = 2
        elseif(location == "rear")then featureNeonRear = data.newstate; id = 3 end
        SetVehicleNeonLightEnabled(playerVeh, id, data.newstate)
    elseif action == "lightcolor" then
        SetVehicleNeonLightsColour(playerVeh, tonumber(data.data[3]), tonumber(data.data[4]), tonumber(data.data[5]))
    elseif action == "paint" then
        SetVehicleColours(playerVeh, tonumber(data.data[3]), select(2, GetVehicleColours(playerVeh)))
    elseif action == "paint2" then
        local cur1 = GetVehicleColours(playerVeh)
        SetVehicleColours(playerVeh, cur1, tonumber(data.data[3]))
    elseif action == "paint3" then
        local c = tonumber(data.data[3]); SetVehicleColours(playerVeh, c, c)
    elseif action == "paintpearl" then
        local _,cur2 = GetVehicleExtraColours(playerVeh)
        SetVehicleExtraColours(playerVeh, tonumber(data.data[3]), cur2)
    elseif action == "paintwheels" then
        local cur1 = GetVehicleExtraColours(playerVeh)
        SetVehicleExtraColours(playerVeh, cur1, tonumber(data.data[3]))
    elseif action == "changewheeltype" then
        SetVehicleWheelType(playerVeh, tonumber(data.data[3]))
        SetVehicleMod(playerVeh, 23, 0, customTires)
        drawNotification("~g~Tire Category Changed")
        SendNUIMessage({updateVariables = true, data = createVariableData()})
    end
end)

local defaultVehAction = "vehmodify"
RegisterNUICallback("vehmodify", function(data, cb)
    local playerPed = GetPlayerPed(-1)
    local playerVeh = GetVehiclePedIsIn(playerPed, false)
    if playerVeh <= 0 then SendNUIMessage({toggleerror = true}); return end
    SetVehicleModKit(playerVeh, 0)
    if(data.data[2] == "extra")then
        SetVehicleExtra(playerVeh, tonumber(data.data[3]), not data.newstate)
    end
    local modID = tonumber(data.data[2])
    if (data.data[3] == "clear") then
        RemoveVehicleMod(playerVeh, modID)
        if(modID == 48)then SetVehicleLivery(playerVeh, 0) end
        return
    end
    local modIndex = tonumber(data.data[3])
    if(modID == 48)then SetVehicleLivery(playerVeh, modIndex) end
    if(modID == nil or modIndex == nil)then return end
    SetVehicleMod(playerVeh, modID, modIndex, customTires)
end)

local vehicleMods = {
    ["الجناح الخلفي"] = 0, ["الصدام الأمامي"] = 1, ["الصدام الخلفي"] = 2,
    ["العتبات الجانبية"] = 3, ["العادم"] = 4, ["الإطار"] = 5,
    ["الشبك"] = 6, ["غطاء المحرك"] = 7, ["الرفرف"] = 8,
    ["الرفرف الأيمن"] = 9, ["السقف"] = 10, ["لوحات الزينة"] = 25,
    ["الديكور الداخلي"] = 27, ["الزينة"] = 28, ["لوحة العدادات"] = 29,
    ["عدادات السرعة"] = 30, ["سماعات الأبواب"] = 31, ["المقاعد"] = 32,
    ["المقود"] = 33, ["عصا الجير"] = 34, ["اللوحات "] = 35,
    ["السماعات"] = 36, ["الشنطة"] = 37, ["الهيدروليك"] = 38,
    ["المحرك"] = 39, ["فلتر الهواء"] = 40, ["الدعامات"] = 41,
    ["غطاء العجلات"] = 42, ["الهوائيات"] = 43, ["ديكور إضافي"] = 44,
    ["خزان الوقود"] = 45, ["النوافذ"] = 46, ["إستكرات"] = 48,
    ["إضافات"] = "extra"
}

RegisterNUICallback("vehmods", function(data, cb)
    local validOptions = {}
    local optCount = 0
    for keyName,value in pairs(vehicleMods) do
        local validComponents
        if (value == "extra") then validComponents = checkValidVehicleExtras()
        else validComponents = checkValidVehicleMods(value) end
        if #validComponents > 0 then
            table.insert(validOptions,{ ["menuName"] = keyName.." ("..#validComponents..")", ["data"] = { ["sub"] = value }, ["submenu"] = validComponents })
            optCount = optCount + 1
        end
    end
    local customJSON = "{}"
    if (optCount > 0) then customJSON = json.encode(validOptions,{indent = true}) end
    SendNUIMessage({ createmenu = true, menuName = "vehmods", menudata = customJSON })
    if(cb)then cb("ok") end
end)

function createVariableData()
    local playerPed = GetPlayerPed(-1)
    local playerVeh = GetVehiclePedIsIn(playerPed, false)
    local wheelModID = 23
    if (playerVeh == 13) then wheelModID = 24 end
    return json.encode({wheeltype=tostring(GetVehicleWheelType(playerVeh)),wheelindex=tostring(GetVehicleMod(playerVeh, wheelModID))}, {indent = true})
end

function checkValidVehicleExtras()
    local playerPed = GetPlayerPed(-1)
    local playerVeh = GetVehiclePedIsIn(playerPed, false)
    local valid = {}
    for i=0,50,1 do
        if(DoesExtraExist(playerVeh, i))then
            local text = "OFF"
            if(IsVehicleExtraTurnedOn(playerVeh, i))then text = "ON" end
            table.insert(valid, { menuName=" "..tostring(i), data = { ["action"] = defaultVehAction.." extra "..tostring(i), ["state"] = text } })
        end
    end
    return valid
end

function DoesVehicleHaveExtras( veh )
    for i = 1, 30 do if ( DoesExtraExist( veh, i ) ) then return true end end
    return false
end

function checkValidVehicleMods(modID)
    local playerPed = GetPlayerPed(-1)
    local playerVeh = GetVehiclePedIsIn(playerPed, false)
    local valid = {}
    local modCount = GetNumVehicleMods(playerVeh,modID)
    if (modID == 48 and modCount == 0) then
        local modCount = GetVehicleLiveryCount(playerVeh)
        for i=1, modCount, 1 do
            local realIndex = i - 1
            local modName = GetLiveryName(playerVeh, realIndex)
            local realModName = GetLabelText(modName)
            valid[i] = { menuName=realModName, data = { ["action"] = defaultVehAction.." "..tostring(modID).." "..tostring(realIndex) } }
        end
    end
    for i = 1, modCount, 1 do
        local realIndex = i - 1
        local modName = GetModTextLabel(playerVeh, modID, realIndex)
        valid[i] = { menuName=GetLabelText(modName), data = { ["action"] = defaultVehAction.." "..tostring(modID).." "..tostring(realIndex) } }
    end
    if(modCount > 0)then
        table.insert(valid, 1, { menuName="Stock", data = { ["action"] = defaultVehAction.." "..tostring(modID).." clear" } })
    end
    return valid
end

local lowerForces = { [0] = 0.00, [1] = -0.018, [2] = -0.03, [3] = -0.05, [4] = -0.08, [5] = -0.11, [6] = -0.15 }

RegisterNUICallback("vehopts", function(data, cb)
    local playerPed = GetPlayerPed(-1)
    local playerVeh = GetVehiclePedIsIn(playerPed, false)
    local action = data.action
    local state = data.newstate
    local text = "~r~OFF"
    if(state) then text = "~g~ON" end

    if(action == "nodrag")then featureNoDragOut = state; featureNoDragOutUpdated = true; drawNotification("No Drag: "..text)
    elseif(action == "nofall")then featureNoFallOff = state; featureNoFallOffUpdated = true; drawNotification("No Fall: "..text)
    elseif(action == "nohelmet")then featureNoHelmet = state; drawNotification("No Helmet: "..text) end

    if(not IsPedInAnyVehicle(playerPed, false))then return end
    playerVeh = GetVehiclePedIsUsing(PlayerPedId())
    if(not(playerPed == (GetPedInVehicleSeat(playerVeh,-1))))then return end

    if(action == "driftmode")then
        if(not(IsThisModelACar(GetEntityModel(playerVeh))))then drawNotification("Vehicle must be a car"); return end
        featureDriftMode = state; SetVehicleReduceGrip(playerVeh, featureDriftMode); drawNotification("Drift Mode: "..text)
    elseif(action == "powerboost")then featurePowerMultiplier = tonumber(data.data[3])
    elseif(action == "torqueboost")then featureTorqueMultiplier = tonumber(data.data[3])
    elseif(action == "lowering")then
        if(not(IsThisModelACar(GetEntityModel(playerVeh))))then drawNotification("Vehicle must be a car"); return end
        featureLowerForce = tonumber(data.data[3])
    elseif(action == "cosdamage")then featureVehCosDamage = state; updateVehicleCosmDamage(playerVeh); drawNotification("No Cosmetic Damage: "..text)
    elseif(action == "mechdamage")then featureVehMechDamage = state; updateVehicleMechDamage(playerVeh)
    elseif(action == "invincible")then featureVehInvincible = state; SetEntityInvincible(playerVeh, featureVehInvincible)
    end
    if(cb)then cb("ok") end
end)

Citizen.CreateThread( function()
    while true do
        local ped = GetPlayerPed( -1 )
        if ( DoesEntityExist( ped ) and not IsEntityDead( ped ) ) then
            local veh = GetVehiclePedIsIn( ped, false )
            if ( GetPedInVehicleSeat( veh, -1 ) == ped ) then
                -- no power / torque boost inside the fights world
                local boostOff = matchLockActive and matchLockVehBoost
                SetVehicleEngineTorqueMultiplier( veh, (boostOff and 1 or featureTorqueMultiplier) + 0.001 )
                SetVehicleEnginePowerMultiplier( veh, (boostOff and 1 or featurePowerMultiplier) + 0.001 )
                if ( featureLowerForce ~= 0 ) then ApplyForceToEntity( veh, true, 0.0, 0.0, lowerForces[featureLowerForce], 0.0, 0.0, 0.0, true, true, true, true, false, true ) end
                if(featureVehCosDamage and IsVehicleDamaged(veh))then
                    SetVehicleFixed(veh); SetVehicleDirtLevel(veh, 0); updateVehicleCosmDamage(veh)
                end
                Citizen.Wait( 10 )
            else Citizen.Wait( 100 ) end
        else Citizen.Wait( 200 ) end
    end
end )

Citizen.CreateThread(function()
    while true do
        Wait(10)
        local playerPed = GetPlayerPed(-1)
        if(featureNoDragOutUpdated)then SetPedCanBeDraggedOut(playerPed, featureNoDragOut); featureNoDragOutUpdated = true end
        if(featureNoFallOffUpdated)then SetPedCanBeKnockedOffVehicle(playerPed, featureNoFallOff); featureNoFallOffUpdated = true end
        if(featureNoHelmet)then SetPedHelmet(playerPed, featureNoHelmet); RemovePedHelmet(playerPed, true) end
    end
end)

-- ============================================================
--  SECTION 10: Weapons
-- ============================================================

local playerPed_weapons = GetPlayerPed(-1)

local COMPONENTS = {
    ["WEAPON_GRENADELAUNCHER"] = { "COMPONENT_AT_SCOPE_SMALL", "COMPONENT_AT_AR_FLSH", "COMPONENT_AT_AR_AFGRIP" },
    ["WEAPON_HEAVYSNIPER"] = { "COMPONENT_AT_SCOPE_LARGE" },
    ["WEAPON_MARKSMANRIFLE"] = { "COMPONENT_MARKSMANRIFLE_CLIP_02", "COMPONENT_AT_AR_FLSH", "COMPONENT_AT_AR_SUPP", "COMPONENT_AT_AR_AFGRIP", "COMPONENT_MARKSMANRIFLE_VARMOD_LUXE" },
    ["WEAPON_SNIPERRIFLE"] = { "COMPONENT_AT_SCOPE_MAX", "COMPONENT_AT_AR_SUPP_02", "COMPONENT_SNIPERRIFLE_VARMOD_LUXE" },
    ["WEAPON_ASSAULTSHOTGUN"] = { "COMPONENT_ASSAULTSHOTGUN_CLIP_02", "COMPONENT_AT_AR_SUPP", "COMPONENT_AT_AR_AFGRIP", "COMPONENT_AT_AR_FLSH" },
    ["WEAPON_PUMPSHOTGUN"] = { "COMPONENT_AT_SR_SUPP", "COMPONENT_AT_AR_FLSH", "COMPONENT_PUMPSHOTGUN_VARMOD_LOWRIDER" },
    ["WEAPON_ASSAULTRIFLE"] = { "COMPONENT_ASSAULTRIFLE_CLIP_02", "COMPONENT_ASSAULTRIFLE_CLIP_03", "COMPONENT_AT_SCOPE_MACRO", "COMPONENT_AT_AR_SUPP_02", "COMPONENT_AT_AR_AFGRIP", "COMPONENT_AT_AR_FLSH", "COMPONENT_ASSAULTRIFLE_VARMOD_LUXE" },
    ["WEAPON_CARBINERIFLE"] = { "COMPONENT_CARBINERIFLE_CLIP_02", "COMPONENT_CARBINERIFLE_CLIP_03", "COMPONENT_AT_SCOPE_MEDIUM", "COMPONENT_AT_AR_SUPP", "COMPONENT_AT_AR_AFGRIP", "COMPONENT_AT_AR_FLSH", "COMPONENT_AT_RAILCOVER_01", "COMPONENT_CARBINERIFLE_VARMOD_LUXE" },
    ["WEAPON_MICROSMG"] = { "COMPONENT_MICROSMG_CLIP_02", "COMPONENT_AT_SCOPE_MACRO", "COMPONENT_AT_AR_SUPP_02", "COMPONENT_AT_PI_FLSH", "COMPONENT_MICROSMG_VARMOD_LUXE" },
    ["WEAPON_SMG"] = { "COMPONENT_SMG_CLIP_02", "COMPONENT_SMG_CLIP_03", "COMPONENT_AT_SCOPE_MACRO_02", "COMPONENT_AT_PI_SUPP", "COMPONENT_AT_AR_FLSH", "COMPONENT_SMG_VARMOD_LUXE" },
    ["WEAPON_PISTOL"] = { "COMPONENT_PISTOL_CLIP_02", "COMPONENT_AT_PI_SUPP_02", "COMPONENT_AT_PI_FLSH", "COMPONENT_PISTOL_VARMOD_LUXE" },
    ["WEAPON_PISTOL50"] = { "COMPONENT_PISTOL50_CLIP_02", "COMPONENT_AT_AR_SUPP_02", "COMPONENT_AT_PI_FLSH", "COMPONENT_PISTOL50_VARMOD_LUXE" },
    ["WEAPON_COMBATPISTOL"] = { "COMPONENT_COMBATPISTOL_CLIP_02", "COMPONENT_AT_PI_SUPP", "COMPONENT_AT_PI_FLSH", "COMPONENT_COMBATPISTOL_VARMOD_LOWRIDER" },
    ["WEAPON_APPISTOL"] = { "COMPONENT_APPISTOL_CLIP_02", "COMPONENT_AT_PI_SUPP", "COMPONENT_AT_PI_FLSH", "COMPONENT_APPISTOL_VARMOD_LUXE" },
    ["WEAPON_HEAVYPISTOL"] = { "COMPONENT_HEAVYPISTOL_CLIP_02", "COMPONENT_AT_PI_FLSH", "COMPONENT_AT_PI_SUPP", "COMPONENT_HEAVYPISTOL_VARMOD_LUXE" },
    ["WEAPON_KNUCKLE"] = { "COMPONENT_KNUCKLE_VARMOD_BASE", "COMPONENT_KNUCKLE_VARMOD_PIMP", "COMPONENT_KNUCKLE_VARMOD_BALLAS", "COMPONENT_KNUCKLE_VARMOD_DOLLAR", "COMPONENT_KNUCKLE_VARMOD_DIAMOND", "COMPONENT_KNUCKLE_VARMOD_HATE", "COMPONENT_KNUCKLE_VARMOD_LOVE", "COMPONENT_KNUCKLE_VARMOD_PLAYER", "COMPONENT_KNUCKLE_VARMOD_KING", "COMPONENT_KNUCKLE_VARMOD_VAGOS" },
    ["WEAPON_SWITCHBLADE"] = { "COMPONENT_SWITCHBLADE_VARMOD_VAR1", "COMPONENT_SWITCHBLADE_VARMOD_VAR2" }
}

local allWeapons = {"WEAPON_KNIFE","WEAPON_KNUCKLE","WEAPON_NIGHTSTICK","WEAPON_HAMMER","WEAPON_BAT","WEAPON_GOLFCLUB","WEAPON_CROWBAR","WEAPON_BOTTLE","WEAPON_DAGGER","WEAPON_HATCHET","WEAPON_MACHETE","WEAPON_FLASHLIGHT","WEAPON_SWITCHBLADE","WEAPON_PISTOL","WEAPON_PISTOL_MK2","WEAPON_COMBATPISTOL","WEAPON_APPISTOL","WEAPON_PISTOL50","WEAPON_SNSPISTOL","WEAPON_HEAVYPISTOL","WEAPON_VINTAGEPISTOL","WEAPON_STUNGUN","WEAPON_FLAREGUN","WEAPON_MARKSMANPISTOL","WEAPON_REVOLVER","WEAPON_MICROSMG","WEAPON_SMG","WEAPON_SMG_MK2","WEAPON_ASSAULTSMG","WEAPON_MG","WEAPON_COMBATMG","WEAPON_COMBATMG_MK2","WEAPON_COMBATPDW","WEAPON_GUSENBERG","WEAPON_MACHINEPISTOL","WEAPON_ASSAULTRIFLE","WEAPON_ASSAULTRIFLE_MK2","WEAPON_CARBINERIFLE","WEAPON_CARBINERIFLE_MK2","WEAPON_ADVANCEDRIFLE","WEAPON_SPECIALCARBINE","WEAPON_BULLPUPRIFLE","WEAPON_COMPACTRIFLE","WEAPON_PUMPSHOTGUN","WEAPON_SAWNOFFSHOTGUN","WEAPON_BULLPUPSHOTGUN","WEAPON_ASSAULTSHOTGUN","WEAPON_MUSKET","WEAPON_HEAVYSHOTGUN","WEAPON_DBSHOTGUN","WEAPON_SNIPERRIFLE","WEAPON_HEAVYSNIPER","WEAPON_HEAVYSNIPER_MK2","WEAPON_MARKSMANRIFLE","WEAPON_GRENADELAUNCHER","WEAPON_GRENADELAUNCHER_SMOKE","WEAPON_RPG","WEAPON_STINGER","WEAPON_MINIGUN","WEAPON_FIREWORK","WEAPON_RAILGUN","WEAPON_HOMINGLAUNCHER","WEAPON_GRENADE","WEAPON_STICKYBOMB","WEAPON_PROXMINE","WEAPON_BZGAS","WEAPON_SMOKEGRENADE","WEAPON_MOLOTOV","WEAPON_FIREEXTINGUISHER","WEAPON_PETROLCAN","WEAPON_SNOWBALL","WEAPON_FLARE","WEAPON_BALL"}

function toggleInfiniteAmmo(toggle)
    local ped = GetPlayerPed(-1)
    for i,v in ipairs(allWeapons) do SetPedInfiniteAmmo(ped, toggle, GetHashKey(v)) end
end

function maxAmmoWeapon(weaponName)
    local ped = GetPlayerPed(-1)
    local weapon = GetHashKey(weaponName)
    if(HasPedGotWeapon(ped, weapon, 0))then AddAmmoToPed(ped, weapon, 9999); drawNotification("Max Ammo") end
end

function addWeaponClip(weaponName)
    local ped = GetPlayerPed(-1)
    local weapon = GetHashKey(weaponName)
    if(HasPedGotWeapon(ped, weapon, 0))then
        SetAmmoInClip(ped, weapon, GetMaxAmmoInClip(ped, weapon, true))
        drawNotification("Ammo Clip Added")
    end
end

function toggleWeaponEquipped(weaponName)
    local ped = GetPlayerPed(-1)
    local weapon = GetHashKey(weaponName)
    if(HasPedGotWeapon(ped, weapon, 0))then RemoveWeaponFromPed(ped, weapon)
    else
        local addClip = GetMaxAmmoInClip(ped, weapon, 1)
        local ammoType = GetPedAmmoType(ped, weapon)
        local ammoAmmount = GetPedAmmoByType(ped, ammoType)
        if(ammoAmmount == 0) then GiveWeaponToPed(ped, weapon, addClip, true, true); return
        elseif(ammoAmmount < addClip) then SetPedAmmoByType(ped, ammoType, addClip) end
        GiveWeaponToPed(ped, weapon, 0, true, true)
        if(featurePlayerInfiniteAmmo)then SetPedInfiniteAmmo(ped, true, weapon) end
    end
end

function forceHasWeapon(weaponName)
    if(HasPedGotWeapon(GetPlayerPed(-1), GetHashKey(weaponName)) == false)then toggleWeaponEquipped(weaponName) end
end

function toggleWeaponComponent(weaponName,componentName)
    local ped = GetPlayerPed(-1)
    local weapon = GetHashKey(weaponName)
    local component = GetHashKey(componentName)
    if(HasPedGotWeaponComponent(ped,weapon,component))then RemoveWeaponComponentFromPed(ped, weapon, component)
    else GiveWeaponComponentToPed(ped, weapon, component) end
    maxAmmoWeapon( weaponName )
end

RegisterNUICallback("weapon", function(data)
    local ped = GetPlayerPed(-1)
    local action = data.action
    local weaponString = data.data[3]
    if(action == "spawn") then toggleWeaponEquipped(weaponString); return
    elseif(action == "holdweapon")then
        if(HasPedGotWeapon(ped, GetHashKey(weaponString)))then SetCurrentPedWeapon(ped, GetHashKey(weaponString), 1) end; return
    end
    if(action == "mod")then toggleWeaponComponent(data.data[4], data.data[3])
    elseif(action == "ammo")then
        if(data.data[3] == "add")then addWeaponClip(data.data[4]) elseif(data.data[3] == "max")then maxAmmoWeapon(data.data[4]) end
    elseif(action == "tint")then SetPedWeaponTintIndex(ped, GetHashKey(data.data[4]), tonumber(data.data[3]))
    elseif(action == "input")then
        local request = requestInput("",60)
        if(IsWeaponValid(GetHashKey(request)))then toggleWeaponEquipped(request) else drawNotification("Invalid Spawn Name") end
    end
end)

function addAllWeapons()
    for i,v in ipairs(allWeapons) do forceHasWeapon(v) end
    if featurePlayerInfiniteAmmo then toggleInfiniteAmmo(true) end
end

function removeAllWeapons()
    local ped = GetPlayerPed(-1)
    for i,v in ipairs(allWeapons) do RemoveWeaponFromPed(ped, GetHashKey(v)) end
end

RegisterNUICallback("weaponoptions", function(data)
    local ped = GetPlayerPed(-1)
    local action = data.action
    if(action == "infinitechutes")then featurePlayerInfiniteParachutes = data.newstate
    elseif(action == "noreload")then featurePlayerNoReload = data.newstate; SetPedInfiniteAmmoClip(ped, featurePlayerNoReload)
    elseif(action == "infiniteammo")then featurePlayerInfiniteAmmo = data.newstate; toggleInfiniteAmmo(featurePlayerInfiniteAmmo)
    elseif(action == "addall")then addAllWeapons()
    elseif(action == "removeall")then removeAllWeapons() end
end)

Citizen.CreateThread(function()
    while true do
        if featurePlayerInfiniteAmmo then
            local ped = GetPlayerPed(-1)
            SetPedInfiniteAmmo(ped, true)
            for i,v in ipairs(allWeapons) do
                local weapon = GetHashKey(v)
                if HasPedGotWeapon(ped, weapon, false) then SetPedInfiniteAmmo(ped, true, weapon) end
            end
            Citizen.Wait(100)
        else Citizen.Wait(1000) end
    end
end)

Citizen.CreateThread(function()
    while true do
        Wait(250)
        if(featurePlayerInfiniteParachutes)then
            local ped = GetPlayerPed(-1)
            local pState = GetPedParachuteState(ped)
            if (pState == -1 or pState == 3)then
                GiveDelayedWeaponToPed(ped, 0xFBAB5776, 1, 0)
                SetPedParachuteTintIndex(ped, 6)
            end
        end
    end
end)

-- ============================================================
--  SECTION 11: Discord Permissions (Dynamic from Config)
-- ============================================================

for _, pkg in ipairs(Config.Packages) do
    local lowerName = string.lower(pkg.name)
    local statusEvent = 'mellotrainer:' .. lowerName .. 'status'
    local triggerEvent = 'mellotrainer:is' .. lowerName
    local denyMsg = pkg.denyMessage

    RegisterNetEvent(statusEvent)
    AddEventHandler(statusEvent, function(status)
        if status then
            SendNUIMessage({adminaccess = true})
        else
            drawNotification(denyMsg)
        end
    end)

    RegisterNUICallback(triggerEvent, function(data, cb)
        TriggerServerEvent(triggerEvent)
        if cb then cb("ok") end
    end)
end

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(500)
        if NetworkIsSessionStarted() then
            TriggerEvent("mellotrainer:init")
            return
        end
    end
end)

-- ============================================================
--  SECTION 12: Teleportation
-- ============================================================

RegisterNetEvent("TeleportMe")
RegisterNetEvent("Effect")
local nv, wp, player, op, optome, metoadmin
local tele_entity = 0
local tele_text = "placeholder"
local zHeigt = 0.0
local tele_pos = 0.0
local tele_height = 1000.0
local tele_scale = 0.0
local Admin = 666

RegisterNUICallback("teleport", function(data, cb)
    local action = data.action
    local playerPed = GetPlayerPed(-1)
    local playerVeh = GetVehiclePedIsIn(playerPed, 0)
    if action == "nearestcar" then nv = true
    elseif action == "waypoint" then
        if DoesBlipExist(GetFirstBlipInfoId(8)) then
            local blip = GetFirstBlipInfoId(8, GetBlipInfoIdIterator(8))
            local coords = Citizen.InvokeNative(0xFA7C7F0AADF25D09, blip, Citizen.ResultAsVector())
            if IsPedInAnyVehicle(playerPed, 0) and (GetPedInVehicleSeat(playerVeh, -1) == playerPed) then
                tele_entity = playerVeh; tele_text = "With Vehicle"
            else tele_entity = playerPed; tele_text = "On Foot" end
            zHeigt = 0.0; tele_height = 1000.0
            SetEntityCoords(tele_entity, coords.x, coords.y, tele_height)
            FreezeEntityPosition(tele_entity, true)
            drawNotification("~y~ﺔﺠﻟﺎﻌﻤﻟﺍ ﻢﺘﺗ...")
            wp = true
        else drawNotification("~r~No Waypoint Set!") end
    elseif action == "forward" then
        if IsPedInAnyVehicle(playerPed, 0) and (GetPedInVehicleSeat(playerVeh, -1) == playerPed) then
            local pos = GetEntityCoords(playerVeh, true)
            SetEntityCoords(playerVeh, pos.x + (3 * GetEntityForwardX(playerVeh)), pos.y + (3 * GetEntityForwardY(playerVeh)), pos.z - 0.75)
        else
            local pos = GetEntityCoords(playerPed, true)
            SetEntityCoords(playerPed, pos.x + (3 * GetEntityForwardX(playerPed)), pos.y + (3 * GetEntityForwardY(playerPed)), pos.z - 0.75)
        end
        drawNotification("~g~Teleported Forward")
    end
    cb("ok")
end)

RegisterNUICallback("onlineplayertele", function(data, cb)
    player = tonumber(data.action)
    if GetPlayerPed(player) ~= 0 then
        if GetPlayerPed(player) ~= GetPlayerPed(-1) then
            if IsPedInAnyVehicle(GetPlayerPed(-1), false) and (GetPedInVehicleSeat(GetVehiclePedIsIn(GetPlayerPed(-1), 0), -1) == GetPlayerPed(-1)) then
                SetEntityCoords(GetVehiclePedIsIn(GetPlayerPed(-1), 0), 0.0, 0.0, 0.0)
                FreezeEntityPosition(GetVehiclePedIsIn(GetPlayerPed(-1), true), true)
            else
                SetEntityCoords(GetPlayerPed(-1), 0.0, 0.0, 0.0)
                FreezeEntityPosition(GetPlayerPed(-1), true)
            end
            op = true
        else drawNotification("~r~Can't Teleport To Yourself!") end
    else drawNotification("~r~Player " .. player + 1 .. " Doesn't Exist!") end
    cb("ok")
end)

RegisterNUICallback("onlineplayerteletome", function(data, cb)
    player = tonumber(data.action)
    if admin == true then
        if GetPlayerPed(player) ~= 0 then
            if GetPlayerPed(player) ~= GetPlayerPed(-1) then optome = true
            else drawNotification("~r~Can't Teleport Yourself!") end
        else drawNotification("~r~Player " .. player + 1 .. " Doesn't Exist!") end
    else drawNotification("~r~Only Works For Admins!") end
    cb("ok")
end)

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)
        if (optome == true) then
            TriggerServerEvent("TeleOtherPlayer", GetPlayerIndex(), player)
            drawNotification("~g~Teleported Player To You!"); optome = false
        end
    end
end)

AddEventHandler("TeleportMe", function(Player, OtherPlayer)
    local playerCoords = GetEntityCoords(GetPlayerPed(Player), true)
    if GetPlayerPed(-1) == GetPlayerPed(OtherPlayer) then Admin = Player; metoadmin = true end
end)

AddEventHandler("Effect", function(Entitiy)
    if IsEntityAPed(Entitiy) then tele_scale = 4.0 else tele_scale = 15.0 end
    if not HasNamedPtfxAssetLoaded("scr_rcbarry1") then RequestNamedPtfxAsset("scr_rcbarry1") end
    while not HasNamedPtfxAssetLoaded("scr_rcbarry1") do Citizen.Wait(0) end
    SetPtfxAssetNextCall("scr_rcbarry1")
end)

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)
        if (op == true) then
            local playerCoords = GetEntityCoords(GetPlayerPed(player), true)
            local localplayerCoords = GetEntityCoords(GetPlayerPed(-1), true)
            local localvehCoords = GetEntityCoords(GetVehiclePedIsIn(GetPlayerPed(-1), 1), true)
            if (localvehCoords.z == 0.0) or (localplayerCoords.z == 0.0) then
                while playerCoords.z == 0.0 do playerCoords = GetEntityCoords(GetPlayerPed(player), true) end
                if IsPedInAnyVehicle(GetPlayerPed(-1), false) and (GetPedInVehicleSeat(GetVehiclePedIsIn(GetPlayerPed(-1), false), -1) == GetPlayerPed(-1)) then
                    FreezeEntityPosition(GetVehiclePedIsIn(GetPlayerPed(-1), false)); SetEntityCoords(GetVehiclePedIsIn(GetPlayerPed(-1), false), playerCoords)
                else
                    if IsPedInAnyVehicle(GetPlayerPed(player), true) and IsAnyVehicleSeatEmpty(GetVehiclePedIsIn(GetPlayerPed(player), false)) then
                        local playerVeh = GetVehiclePedIsIn(GetPlayerPed(player), false)
                        local seat = GetVehicleModelMaxNumberOfPassengers(GetEntityModel(playerVeh)) - 2
                        local seatindex = -1
                        while seatindex <= seat and ((IsVehicleSeatFree(playerVeh, seatindex)) == false) do Citizen.Wait(0); seatindex = seatindex + 1 end
                        FreezeEntityPosition(GetPlayerPed(-1), false); SetPedIntoVehicle(GetPlayerPed(-1), playerVeh, seatindex)
                    else
                        FreezeEntityPosition(GetPlayerPed(-1), false); SetEntityCoords(GetPlayerPed(-1), playerCoords)
                    end
                end
            end
            op = false
        end
    end
end)

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)
        if (metoadmin == true) then
            if IsPedInAnyVehicle(GetPlayerPed(Admin), true) and IsAnyVehicleSeatEmpty(GetVehiclePedIsIn(GetPlayerPed(Admin), false)) then
                local playerVeh = GetVehiclePedIsIn(GetPlayerPed(Admin), false)
                local seat = GetVehicleModelMaxNumberOfPassengers(GetEntityModel(playerVeh)) - 2
                local seatindex = -1
                while seatindex <= seat and ((IsVehicleSeatFree(playerVeh, seatindex)) == false) do Citizen.Wait(0); seatindex = seatindex + 1 end
                SetPedIntoVehicle(GetPlayerPed(-1), playerVeh, seatindex)
            else SetEntityCoords(GetPlayerPed(-1), GetEntityCoords(GetPlayerPed(player), true)) end
            drawNotification("~y~You Got Teleporten To An Admin!"); metoadmin = false
        end
    end
end)

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)
        if (nv == true) then
            local playerPed = GetPlayerPed(-1)
            local playerPedPos = GetEntityCoords(playerPed, true)
            drawNotification("~y~ﺔﺠﻟﺎﻌﻤﻟﺍ ﻢﺘﺗ..."); Citizen.Wait(1000)
            local NearestVehicle = GetClosestVehicle(playerPedPos, 1000.0, 0, 4)
            local NearestPlane = GetClosestVehicle(playerPedPos, 1000.0, 0, 16384)
            local target = nil
            if NearestVehicle ~= 0 then target = NearestVehicle
            elseif NearestPlane ~= 0 then target = NearestPlane end
            if target then
                if not IsVehicleSeatFree(target, -1) then
                    local driverPed = GetPedInVehicleSeat(target, -1)
                    ClearPedTasksImmediately(driverPed); SetEntityAsMissionEntity(driverPed, 1, 1); DeleteEntity(driverPed)
                end
                SetPedIntoVehicle(playerPed, target, -1)
                SetVehicleAlarm(target, false); SetVehicleDoorsLocked(target, 1); SetVehicleNeedsToBeHotwired(target, false)
                drawNotification("~g~Teleported Into Nearest Vehicle!")
            else drawNotification("~r~No Vehicle Found") end
            nv = false
        end
    end
end)

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)
        if (wp == true) then
            if zHeigt == 0.0 then
                tele_pos = GetEntityCoords(tele_entity, true)
                tele_height = tele_height - 50.0
                TriggerServerEvent("EffectForAll", tele_entity)
                SetEntityCoords(tele_entity, tele_pos.x, tele_pos.y, tele_height)
                zHeigt = getGroundZ(tele_pos.x, tele_pos.y, tele_pos.z)
            else
                TriggerServerEvent("EffectForAll", tele_entity)
                SetEntityCoords(tele_entity, tele_pos.x, tele_pos.y, zHeigt)
                FreezeEntityPosition(tele_entity, false)
                drawNotification("~g~Teleported To Waypoint " .. tele_text .."!")
                wp = false
            end
        end
    end
end)

function getGroundZ(x, y, z)
    local result, groundZ = GetGroundZFor_3dCoord(x+0.0, y+0.0, z+0.0, Citizen.ReturnResultAnyway())
    return groundZ
end

-- ============================================================
--  SECTION 13: Vehicle Tuning
-- ============================================================

local neoncolor, vehiclecol, extracol
local tireproof = false
local turbotoggle = false
local xenontoggle = false
local neonleft = false
local neonright = false
local neonfront = false
local neonrear = false
local plateText = "PLACEHOLDER"
local tuning_R, tuning_G, tuning_B = 0, 0, 0

Citizen.CreateThread(function()
    while true do
        if turbotoggle ~= nil and IsPedInAnyVehicle(GetPlayerPed(-1), true) then
            Citizen.Wait(250)
            ToggleVehicleMod(GetVehiclePedIsIn(GetPlayerPed(-1), false), 18, turbotoggle)
        else Citizen.Wait(1000) end
    end
end)

RegisterNUICallback("brakes", function(data, cb)
    local playerVeh = GetVehiclePedIsIn(GetPlayerPed(-1), false)
    local modIndex = tonumber(data.action)
    if IsPedInAnyVehicle(GetPlayerPed(-1), 0) and (GetPedInVehicleSeat(playerVeh, -1) == GetPlayerPed(-1)) then
        SetVehicleModKit(playerVeh, 0)
        if (modIndex <= (GetNumVehicleMods(playerVeh, 12) - 1)) then SetVehicleMod(playerVeh, 12, modIndex)
        else drawNotification("~r~Not Available For This Vehicle!") end
    end
end)

RegisterNUICallback("engine", function(data, cb)
    local playerVeh = GetVehiclePedIsIn(GetPlayerPed(-1), false)
    local modIndex = tonumber(data.action)
    if IsPedInAnyVehicle(GetPlayerPed(-1), 0) and (GetPedInVehicleSeat(playerVeh, -1) == GetPlayerPed(-1)) then
        SetVehicleModKit(playerVeh, 0)
        if (modIndex <= (GetNumVehicleMods(playerVeh, 11) - 1)) then SetVehicleMod(playerVeh, 11, modIndex)
        else drawNotification("~r~Not Available For This Vehicle!") end
    end
end)

RegisterNUICallback("grille", function(data, cb)
    local playerVeh = GetVehiclePedIsIn(GetPlayerPed(-1), false)
    local modIndex = tonumber(data.action)
    if IsPedInAnyVehicle(GetPlayerPed(-1), 0) and (GetPedInVehicleSeat(playerVeh, -1) == GetPlayerPed(-1)) then
        SetVehicleModKit(playerVeh, 0)
        if (modIndex <= (GetNumVehicleMods(playerVeh, 6) - 1)) then SetVehicleMod(playerVeh, 6, modIndex)
        else drawNotification("~r~Not Available For This Vehicle!") end
    end
end)

RegisterNUICallback("hood", function(data, cb)
    local playerVeh = GetVehiclePedIsIn(GetPlayerPed(-1), false)
    if IsPedInAnyVehicle(GetPlayerPed(-1), 0) and (GetPedInVehicleSeat(playerVeh, -1) == GetPlayerPed(-1)) then
        SetVehicleModKit(playerVeh, 0)
    end
end)

RegisterNUICallback("horn", function(data, cb)
    local playerVeh = GetVehiclePedIsIn(GetPlayerPed(-1), false)
    local hornIndex = tonumber(data.action)
    if IsPedInAnyVehicle(GetPlayerPed(-1), 0) and (GetPedInVehicleSeat(playerVeh, -1) == GetPlayerPed(-1)) then
        SetVehicleModKit(playerVeh, 0)
        if (hornIndex <= (GetNumVehicleMods(playerVeh, 14) - 0)) then SetVehicleMod(playerVeh, 14, hornIndex)
        else drawNotification("~r~Not Available For This Vehicle!") end
    end
end)

RegisterNUICallback("light", function(data, cb)
    if data.action == "xenon" then
        xenontoggle = data.newstate
        if xenontoggle then drawNotification("~g~Xenon Lights Enabled!") else drawNotification("~r~Xenon Lights Disabled!") end
    end
end)

RegisterNUICallback("neons", function(data, cb)
    local playerVeh = GetVehiclePedIsIn(GetPlayerPed(-1), false)
    local action = data.action
    if IsPedInAnyVehicle(GetPlayerPed(-1), true) then
        if action == "left" then neonleft = data.newstate
        elseif action == "right" then neonright = data.newstate
        elseif action == "front" then neonfront = data.newstate
        elseif action == "rear" then neonrear = data.newstate
        elseif action == "custom" then
            DisplayOnscreenKeyboard(1, "FMMC_KEY_TIP8", "", tuning_R..","..tuning_G..","..tuning_B, "", "", "", 25)
            blockinput = true
            while UpdateOnscreenKeyboard() ~= 1 and UpdateOnscreenKeyboard() ~= 2 do Citizen.Wait(0) end
            if UpdateOnscreenKeyboard() ~= 2 then
                local color = stringsplit(GetOnscreenKeyboardResult(), ",")
                tuning_R = tonumber(color[1]); tuning_G = tonumber(color[2]); tuning_B = tonumber(color[3])
                Citizen.Wait(500); blockinput = false
                SetVehicleNeonLightsColour(playerVeh, tuning_R, tuning_G, tuning_B)
            else Citizen.Wait(500); blockinput = false end
        elseif action == "white" then SetVehicleNeonLightsColour(playerVeh, 255, 255, 255)
        elseif action == "blue" then SetVehicleNeonLightsColour(playerVeh, 0, 0, 255)
        elseif action == "electricblue" then SetVehicleNeonLightsColour(playerVeh, 0, 150, 255)
        elseif action == "mintgreen" then SetVehicleNeonLightsColour(playerVeh, 50, 255, 155)
        elseif action == "limegreen" then SetVehicleNeonLightsColour(playerVeh, 0, 255, 0)
        elseif action == "yellow" then SetVehicleNeonLightsColour(playerVeh, 255, 255, 0)
        elseif action == "orange" then SetVehicleNeonLightsColour(playerVeh, 208, 104, 0)
        elseif action == "red" then SetVehicleNeonLightsColour(playerVeh, 255, 0, 0)
        elseif action == "ponypink" then SetVehicleNeonLightsColour(playerVeh, 255, 102, 255)
        elseif action == "hotpink" then SetVehicleNeonLightsColour(playerVeh, 255, 0, 255)
        elseif action == "purple" then SetVehicleNeonLightsColour(playerVeh, 71, 0, 71) end
    else drawNotification("~r~Not in a vehicle!") end
    cb("ok")
end)

RegisterNUICallback("plate", function(data, cb)
    local playerVeh = GetVehiclePedIsIn(GetPlayerPed(-1), false)
    if data.action == "text" then
        plateText = GetVehicleNumberPlateText(playerVeh)
        DisplayOnscreenKeyboard(1, "FMMC_KEY_TIP8", "", plateText, "", "", "", 25)
        blockinput = true
        while UpdateOnscreenKeyboard() ~= 1 and UpdateOnscreenKeyboard() ~= 2 do Citizen.Wait(0) end
        if UpdateOnscreenKeyboard() ~= 2 then plateText = GetOnscreenKeyboardResult(); Citizen.Wait(500); blockinput = false
        else Citizen.Wait(500); blockinput = false end
        SetVehicleNumberPlateText(playerVeh, plateText)
    else
        if IsPedInAnyVehicle(GetPlayerPed(-1), 0) and (GetPedInVehicleSeat(playerVeh, -1) == GetPlayerPed(-1)) then
            SetVehicleModKit(playerVeh, 0); SetVehicleNumberPlateTextIndex(playerVeh, tonumber(data.action))
        end
    end
end)

RegisterNUICallback("suspension", function(data, cb)
    local playerVeh = GetVehiclePedIsIn(GetPlayerPed(-1), false)
    local modIndex = tonumber(data.action)
    if IsPedInAnyVehicle(GetPlayerPed(-1), 0) and (GetPedInVehicleSeat(playerVeh, -1) == GetPlayerPed(-1)) then
        SetVehicleModKit(playerVeh, 0)
        if (modIndex <= (GetNumVehicleMods(playerVeh, 15) - 1)) then SetVehicleMod(playerVeh, 15, modIndex)
        else drawNotification("~r~Not Available For This Vehicle!") end
    end
end)

RegisterNUICallback("tire", function(data, cb)
    local playerVeh = GetVehiclePedIsIn(GetPlayerPed(-1), false)
    if data.action == "proof" then tireproof = data.newstate
    elseif data.action == "no" then ToggleVehicleMod(playerVeh, 20, true); SetVehicleTyreSmokeColor(playerVeh, 0, 0, 0)
    elseif data.action == "custom" then
        DisplayOnscreenKeyboard(1, "FMMC_KEY_TIP8", "", tuning_R..","..tuning_G..","..tuning_B, "", "", "", 25)
        blockinput = true
        while UpdateOnscreenKeyboard() ~= 1 and UpdateOnscreenKeyboard() ~= 2 do Citizen.Wait(0) end
        if UpdateOnscreenKeyboard() ~= 2 then
            local color = stringsplit(GetOnscreenKeyboardResult(), ",")
            tuning_R = tonumber(color[1]); tuning_G = tonumber(color[2]); tuning_B = tonumber(color[3])
            Citizen.Wait(500); blockinput = false
            ToggleVehicleMod(playerVeh, 20, true); SetVehicleTyreSmokeColor(playerVeh, tuning_R, tuning_G, tuning_B)
        else Citizen.Wait(500); blockinput = false end
    else
        local colors = { white={254,254,254}, black={1,1,1}, blue={0,0,255}, yellow={200,200,0}, purple={153,0,153}, orange={255,153,0}, green={0,255,0}, red={255,0,0}, pink={255,102,153}, brown={128,43,0} }
        if colors[data.action] then
            ToggleVehicleMod(playerVeh, 20, true)
            SetVehicleTyreSmokeColor(playerVeh, colors[data.action][1], colors[data.action][2], colors[data.action][3])
        end
    end
end)

RegisterNUICallback("transmission", function(data, cb)
    local playerVeh = GetVehiclePedIsIn(GetPlayerPed(-1), false)
    local modIndex = tonumber(data.action)
    if IsPedInAnyVehicle(GetPlayerPed(-1), 0) and (GetPedInVehicleSeat(playerVeh, -1) == GetPlayerPed(-1)) then
        SetVehicleModKit(playerVeh, 0)
        if (modIndex <= (GetNumVehicleMods(playerVeh, 13) - 1)) then SetVehicleMod(playerVeh, 13, modIndex)
        else drawNotification("~r~Not Available For This Vehicle!") end
    end
end)

RegisterNUICallback("turbo", function(data, cb)
    if data.action == "onoff" then
        turbotoggle = data.newstate
        if turbotoggle then drawNotification("~g~Turbo Enabled!") else drawNotification("~r~Turbo Disabled!") end
    end
end)

RegisterNUICallback("wheels", function(data, cb)
    local playerVeh = GetVehiclePedIsIn(GetPlayerPed(-1), false)
    local modIndex = stringsplit(data.action, ",")
    if IsPedInAnyVehicle(GetPlayerPed(-1), 0) and (GetPedInVehicleSeat(playerVeh, -1) == GetPlayerPed(-1)) then
        SetVehicleModKit(playerVeh, 0)
        if (tonumber(modIndex[2]) <= (GetNumVehicleMods(playerVeh, 23) - 1)) then
            SetVehicleWheelType(playerVeh, tonumber(modIndex[1])); SetVehicleMod(playerVeh, 23, tonumber(modIndex[2]), true)
        else drawNotification("~r~Not Available For This Vehicle!") end
    end
end)

RegisterNUICallback("window", function(data, cb)
    local playerVeh = GetVehiclePedIsIn(GetPlayerPed(-1), false)
    if IsPedInAnyVehicle(GetPlayerPed(-1), 0) and (GetPedInVehicleSeat(playerVeh, -1) == GetPlayerPed(-1)) then
        SetVehicleModKit(playerVeh, 0); SetVehicleWindowTint(playerVeh, tonumber(data.action))
    end
end)

RegisterNUICallback("primatte", function(data, cb)
    local playerVeh = GetVehiclePedIsIn(GetPlayerPed(-1), false)
    if IsPedInAnyVehicle(GetPlayerPed(-1), true) then
        SetVehicleModColor_1(playerVeh, 3); ClearVehicleCustomPrimaryColour(playerVeh)
        if data.action == "custom" then
            DisplayOnscreenKeyboard(1, "FMMC_KEY_TIP8", "", tuning_R..","..tuning_G..","..tuning_B, "", "", "", 25)
            blockinput = true
            while UpdateOnscreenKeyboard() ~= 1 and UpdateOnscreenKeyboard() ~= 2 do Citizen.Wait(0) end
            if UpdateOnscreenKeyboard() ~= 2 then
                local color = stringsplit(GetOnscreenKeyboardResult(), ",")
                tuning_R = tonumber(color[1]); tuning_G = tonumber(color[2]); tuning_B = tonumber(color[3])
                Citizen.Wait(500); blockinput = false
                SetVehicleCustomPrimaryColour(playerVeh, tuning_R, tuning_G, tuning_B)
                SetVehicleExtraColours(playerVeh, extracol[1], extracol[2])
            else Citizen.Wait(500); blockinput = false end
        else
            SetVehicleColours(playerVeh, tonumber(data.action), vehiclecol[2])
            SetVehicleExtraColours(playerVeh, extracol[1], extracol[2])
        end
    end
    cb("ok")
end)

RegisterNUICallback("primetalchrome", function(data, cb)
    local playerVeh = GetVehiclePedIsIn(GetPlayerPed(-1), false)
    local colorindex = tonumber(data.action)
    local modColor = (colorindex == 120 or data.action == "custom") and 5 or 4
    if IsPedInAnyVehicle(GetPlayerPed(-1), true) then
        SetVehicleModColor_1(playerVeh, modColor)
        if data.action == "custom" then
            DisplayOnscreenKeyboard(1, "FMMC_KEY_TIP8", "", tuning_R..","..tuning_G..","..tuning_B, "", "", "", 25)
            blockinput = true
            while UpdateOnscreenKeyboard() ~= 1 and UpdateOnscreenKeyboard() ~= 2 do Citizen.Wait(0) end
            if UpdateOnscreenKeyboard() ~= 2 then
                local color = stringsplit(GetOnscreenKeyboardResult(), ",")
                tuning_R = tonumber(color[1]); tuning_G = tonumber(color[2]); tuning_B = tonumber(color[3])
                Citizen.Wait(500); blockinput = false
                SetVehicleCustomPrimaryColour(playerVeh, tuning_R, tuning_G, tuning_B)
                SetVehicleExtraColours(playerVeh, extracol[1], extracol[2])
            else Citizen.Wait(500); blockinput = false end
        else
            ClearVehicleCustomPrimaryColour(playerVeh)
            SetVehicleColours(playerVeh, colorindex, vehiclecol[2])
            SetVehicleExtraColours(playerVeh, extracol[1], extracol[2])
        end
    end
    cb("ok")
end)

RegisterNUICallback("primetallic", function(data, cb)
    local playerVeh = GetVehiclePedIsIn(GetPlayerPed(-1), false)
    if IsPedInAnyVehicle(GetPlayerPed(-1), true) then
        SetVehicleModColor_1(playerVeh, 1); ClearVehicleCustomPrimaryColour(playerVeh)
        if data.action == "custom" then
            DisplayOnscreenKeyboard(1, "FMMC_KEY_TIP8", "", tuning_R..","..tuning_G..","..tuning_B, "", "", "", 25)
            blockinput = true
            while UpdateOnscreenKeyboard() ~= 1 and UpdateOnscreenKeyboard() ~= 2 do Citizen.Wait(0) end
            if UpdateOnscreenKeyboard() ~= 2 then
                local color = stringsplit(GetOnscreenKeyboardResult(), ",")
                tuning_R = tonumber(color[1]); tuning_G = tonumber(color[2]); tuning_B = tonumber(color[3])
                Citizen.Wait(500); blockinput = false
                SetVehicleCustomPrimaryColour(playerVeh, tuning_R, tuning_G, tuning_B)
                SetVehicleExtraColours(playerVeh, extracol[1], extracol[2])
            else Citizen.Wait(500); blockinput = false end
        else
            SetVehicleColours(playerVeh, tonumber(data.action), vehiclecol[2])
            SetVehicleExtraColours(playerVeh, extracol[1], extracol[2])
        end
    end
    cb("ok")
end)

RegisterNUICallback("secmatte", function(data, cb)
    local playerVeh = GetVehiclePedIsIn(GetPlayerPed(-1), false)
    if IsPedInAnyVehicle(GetPlayerPed(-1), true) then
        SetVehicleModColor_2(playerVeh, 3); ClearVehicleCustomSecondaryColour(playerVeh)
        if data.action == "custom" then
            DisplayOnscreenKeyboard(1, "FMMC_KEY_TIP8", "", tuning_R..","..tuning_G..","..tuning_B, "", "", "", 25)
            blockinput = true
            while UpdateOnscreenKeyboard() ~= 1 and UpdateOnscreenKeyboard() ~= 2 do Citizen.Wait(0) end
            if UpdateOnscreenKeyboard() ~= 2 then
                local color = stringsplit(GetOnscreenKeyboardResult(), ",")
                tuning_R = tonumber(color[1]); tuning_G = tonumber(color[2]); tuning_B = tonumber(color[3])
                Citizen.Wait(500); blockinput = false
                SetVehicleCustomSecondaryColour(playerVeh, tuning_R, tuning_G, tuning_B)
                SetVehicleExtraColours(playerVeh, extracol[1], extracol[2])
            else Citizen.Wait(500); blockinput = false end
        else
            SetVehicleColours(playerVeh, vehiclecol[1], tonumber(data.action))
            SetVehicleExtraColours(playerVeh, extracol[1], extracol[2])
        end
    end
    cb("ok")
end)

RegisterNUICallback("secmetalchrome", function(data, cb)
    local playerVeh = GetVehiclePedIsIn(GetPlayerPed(-1), false)
    local colorindex = tonumber(data.action)
    local modColor = (colorindex == 120 or data.action == "custom") and 5 or 4
    if IsPedInAnyVehicle(GetPlayerPed(-1), true) then
        SetVehicleModColor_2(playerVeh, modColor)
        if data.action == "custom" then
            DisplayOnscreenKeyboard(1, "FMMC_KEY_TIP8", "", tuning_R..","..tuning_G..","..tuning_B, "", "", "", 25)
            blockinput = true
            while UpdateOnscreenKeyboard() ~= 1 and UpdateOnscreenKeyboard() ~= 2 do Citizen.Wait(0) end
            if UpdateOnscreenKeyboard() ~= 2 then
                local color = stringsplit(GetOnscreenKeyboardResult(), ",")
                tuning_R = tonumber(color[1]); tuning_G = tonumber(color[2]); tuning_B = tonumber(color[3])
                Citizen.Wait(500); blockinput = false
                SetVehicleCustomSecondaryColour(playerVeh, tuning_R, tuning_G, tuning_B)
                SetVehicleExtraColours(playerVeh, extracol[1], extracol[2])
            else Citizen.Wait(500); blockinput = false end
        else
            ClearVehicleCustomSecondaryColour(playerVeh)
            SetVehicleColours(playerVeh, vehiclecol[1], colorindex)
            SetVehicleExtraColours(playerVeh, extracol[1], extracol[2])
        end
    end
    cb("ok")
end)

RegisterNUICallback("secmetallic", function(data, cb)
    local playerVeh = GetVehiclePedIsIn(GetPlayerPed(-1), false)
    if IsPedInAnyVehicle(GetPlayerPed(-1), true) then
        SetVehicleModColor_2(playerVeh, 1); ClearVehicleCustomSecondaryColour(playerVeh)
        if data.action == "custom" then
            DisplayOnscreenKeyboard(1, "FMMC_KEY_TIP8", "", tuning_R..","..tuning_G..","..tuning_B, "", "", "", 25)
            blockinput = true
            while UpdateOnscreenKeyboard() ~= 1 and UpdateOnscreenKeyboard() ~= 2 do Citizen.Wait(0) end
            if UpdateOnscreenKeyboard() ~= 2 then
                local color = stringsplit(GetOnscreenKeyboardResult(), ",")
                tuning_R = tonumber(color[1]); tuning_G = tonumber(color[2]); tuning_B = tonumber(color[3])
                Citizen.Wait(500); blockinput = false
                SetVehicleCustomSecondaryColour(playerVeh, tuning_R, tuning_G, tuning_B)
                SetVehicleExtraColours(playerVeh, extracol[1], extracol[2])
            else Citizen.Wait(500); blockinput = false end
        else
            SetVehicleColours(playerVeh, vehiclecol[1], tonumber(data.action))
            SetVehicleExtraColours(playerVeh, extracol[1], extracol[2])
        end
    end
    cb("ok")
end)

RegisterNUICallback("pearl", function(data, cb)
    local playerVeh = GetVehiclePedIsIn(GetPlayerPed(-1), false)
    if IsPedInAnyVehicle(GetPlayerPed(-1), true) then SetVehicleExtraColours(playerVeh, tonumber(data.action), extracol[2]) end
    cb("ok")
end)

RegisterNUICallback("rims", function(data, cb)
    local playerVeh = GetVehiclePedIsIn(GetPlayerPed(-1), false)
    if IsPedInAnyVehicle(GetPlayerPed(-1), true) then SetVehicleExtraColours(playerVeh, extracol[1], tonumber(data.action)) end
    cb("ok")
end)

Citizen.CreateThread(function()
    while true do
        if tireproof ~= nil and IsPedInAnyVehicle(GetPlayerPed(-1), true) then
            Citizen.Wait(250); SetVehicleTyresCanBurst(GetVehiclePedIsIn(GetPlayerPed(-1), false), not tireproof)
        else Citizen.Wait(1000) end
    end
end)

Citizen.CreateThread(function()
    while true do
        if xenontoggle ~= nil and IsPedInAnyVehicle(GetPlayerPed(-1), true) then
            Citizen.Wait(250); ToggleVehicleMod(GetVehiclePedIsIn(GetPlayerPed(-1), false), 22, xenontoggle)
        else Citizen.Wait(1000) end
    end
end)

Citizen.CreateThread(function()
    while true do
        if neonleft ~= nil or neonright ~= nil or neonfront ~= nil or neonrear ~= nil then
            Citizen.Wait(200)
            local v = GetVehiclePedIsIn(GetPlayerPed(-1))
            if neonleft ~= nil then SetVehicleNeonLightEnabled(v, 0, neonleft) end
            if neonright ~= nil then SetVehicleNeonLightEnabled(v, 1, neonright) end
            if neonfront ~= nil then SetVehicleNeonLightEnabled(v, 2, neonfront) end
            if neonrear ~= nil then SetVehicleNeonLightEnabled(v, 3, neonrear) end
        else Citizen.Wait(1000) end
    end
end)

Citizen.CreateThread(function()
    while true do
        if IsPedInAnyVehicle(GetPlayerPed(-1), true) then
            Citizen.Wait(500)
            vehiclecol = table.pack(GetVehicleColours(GetVehiclePedIsIn(GetPlayerPed(-1), false)))
            extracol = table.pack(GetVehicleExtraColours(GetVehiclePedIsIn(GetPlayerPed(-1), false)))
            neoncolor = table.pack(GetVehicleNeonLightsColour(GetVehiclePedIsIn(GetPlayerPed(-1), false)))
        else Citizen.Wait(2000) end
    end
end)

-- ============================================================
--  SECTION 15: Location Teleport
-- ============================================================

local loc_x, loc_y, loc_z = 0.0, 0.0, 0.0

RegisterNUICallback("location", function(data, cb)
    local coords = stringsplit(data.action, ",")
    local x, y, z = tonumber(coords[1]), tonumber(coords[2]), tonumber(coords[3])
    RequestCollisionAtCoord(x, y, z)
    if IsPedInAnyVehicle(GetPlayerPed(-1), 0) and (GetPedInVehicleSeat(GetVehiclePedIsIn(GetPlayerPed(-1), 0), -1) == GetPlayerPed(-1)) then
        SetEntityCoords(GetVehiclePedIsIn(GetPlayerPed(-1), 0), x, y, z)
    else SetEntityCoords(GetPlayerPed(-1), x, y, z) end
    cb("ok")
end)

RegisterNUICallback("customlocation", function(data, cb)
    if data.action == "set" then
        DisplayOnscreenKeyboard(1, "FMMC_KEY_TIP8", "", loc_x..","..loc_y..","..loc_z, "", "", "", 25)
        blockinput = true
        while UpdateOnscreenKeyboard() ~= 1 and UpdateOnscreenKeyboard() ~= 2 do Citizen.Wait(0) end
        if UpdateOnscreenKeyboard() ~= 2 then
            local coords = stringsplit(GetOnscreenKeyboardResult(), ",")
            loc_x = tonumber(coords[1]); loc_y = tonumber(coords[2]); loc_z = tonumber(coords[3])
            Citizen.Wait(500); blockinput = false
        else Citizen.Wait(500); blockinput = false end
    elseif data.action == "teleport" then
        RequestCollisionAtCoord(loc_x, loc_y, loc_z)
        if IsPedInAnyVehicle(GetPlayerPed(-1), 0) and (GetPedInVehicleSeat(GetVehiclePedIsIn(GetPlayerPed(-1), 0), -1) == GetPlayerPed(-1)) then
            SetEntityCoords(GetVehiclePedIsIn(GetPlayerPed(-1), 0), loc_x, loc_y, loc_z)
        else SetEntityCoords(GetPlayerPed(-1), loc_x, loc_y, loc_z) end
        drawNotification("<FONT FACE = 'A9eelsh'>"..'~g~!ﻥﺎﻜﻤﻠﻟ ﺖﻠﻘﺘﻧﺍ')
    end
    cb("ok")
end)

-- ============================================================
--  SECTION 16: Custom Color Picker
-- ============================================================

local restoreOnClose = true
local primaryColor = true
local prevPrimary, prevSecondary, prevPearlescent, prevWheel = 0, 0, 0, 0
local prevR, prevG, prevB = 255, 0, 0

function CloseMello()
    SendNUIMessage({ hidetrainer = true }); showtrainer = false
end

function OpenMello()
    if matchLockActive then MatchLockNotify(); return end
    SendNUIMessage(_menuStyle)
    SendNUIMessage({ showtrainer = true, showSpecificPage = "mainmenu" }); showtrainer = true
    DisableControlAction(1, 202, true)
end
RegisterNetEvent("melloTrainer:open", OpenMello)

function ReopenColors()
    if matchLockActive then return end
    SendNUIMessage(_menuStyle)
    SendNUIMessage({ showtrainer = true, showSpecificPage = "vehpricolor" }); showtrainer = true
end

function SetColor(r, g, b)
    prevR = r; prevG = g; prevB = b
    local veh = GetVehiclePedIsIn(GetPlayerPed(-1), false)
    if veh == 0 then return end
    if restoreOnClose and not GetIsVehiclePrimaryColourCustom(veh) and not GetIsVehicleSecondaryColourCustom(veh) then
        prevPrimary, prevSecondary = GetVehicleColours(veh)
        prevPearlescent, prevWheel = GetVehicleExtraColours(veh)
    end
    if primaryColor then SetVehicleCustomPrimaryColour(veh, r, g, b)
    else SetVehicleCustomSecondaryColour(veh, r, g, b) end
end

function ApplyColor(r, g, b) restoreOnClose = false; SetColor(r, g, b) end

function RestoreColor(r, g, b)
    ReopenColors()
    if not restoreOnClose then return end
    local veh = GetVehiclePedIsIn(GetPlayerPed(-1), false)
    if veh == 0 then return end
    ClearVehicleCustomPrimaryColour(veh); ClearVehicleCustomSecondaryColour(veh)
    SetVehicleColours(veh, prevPrimary, prevSecondary)
    SetVehicleExtraColours(veh, prevPearlescent, prevWheel)
end

function OpenColorPicker(primary)
    if GetVehiclePedIsIn(GetPlayerPed(-1), false) == 0 then return end
    primaryColor = primary; CloseMello()
    TriggerEvent("colorPicker:pick", prevR, prevG, prevB, true, SetColor, ApplyColor, RestoreColor)
end

RegisterNUICallback("pricolorcustom", function(data, cb) restoreOnClose = true; OpenColorPicker(true) end)
RegisterNUICallback("seccolorcustom", function(data, cb) restoreOnClose = true; OpenColorPicker(false) end)

-- ============================================================
--  SECTION 17: OneSync
-- ============================================================

KnownPlayers = {}
function ReceivePlayers(newPlayers) KnownPlayers = newPlayers end
RegisterNetEvent("mello:receivePlayers", ReceivePlayers)
TriggerServerEvent("mello:ready")

-- ============================================================
--  SECTION 18: Time & Weather
-- ============================================================

RegisterNuiCallback("timeweather", function (data, cb)
    CloseMello(); TriggerEvent("weatherMenu:requestOpen"); cb("ok")
end)

-- ============================================================
--  SECTION 20: Miscellaneous
-- ============================================================

local autoparachute, blackout, mobileradio, dfps, dspeedo, nonpcstraffic, freezeradio
local radioname, explodevehicles, noclipmode, vibrator, showname1, showname2, cinecam, infiniteRocketBoost
local dropweapon = true
local prevCoordx, prevCoordy, prevCoordz = 0.0, 0.0, 0.0
local vibcount = 0
local fps, prevframes, curframes, prevtime, curtime = 0, 0, 0, 0, 0
local kmh = true
local mph = false

RegisterNUICallback("misc", function(data, cb)
    local action = data.action
    local newstate = data.newstate
    if action == "autopara" then autoparachute = newstate
    elseif action == "blackoutonoff" then blackout = newstate
    elseif action == "mblradio" then mobileradio = newstate
    elseif action == "drawfps" then dfps = newstate
    elseif action == "drawspeedo" then dspeedo = newstate
    elseif action == "drawspeedokmh" then mph = false; kmh = true
    elseif action == "drawspeedomph" then kmh = false; mph = true
    elseif action == "npcstraffic" then nonpcstraffic = newstate
    elseif action == "explodevehs" then explodevehicles = newstate
    elseif action == "noclip" then
        noclipmode = newstate
        if not noclipmode then
            Citizen.InvokeNative(0xD86D101FCFD00A4B, GetPlayerPed(-1), 2)
            Citizen.InvokeNative(0xD86D101FCFD00A4B, GetPlayerPed(-1), 3)
            SetEntityCollision(GetPlayerPed(-1), true, true); FreezeEntityPosition(GetPlayerPed(-1), false)
        end
    elseif action == "vib" then vibrator = newstate
    elseif action == "cinematic" then cinecam = newstate
    elseif action == "rocket" then infiniteRocketBoost = newstate end
    cb("ok")
end)

RegisterNUICallback("radio", function(data, cb)
    if data.action == "skip" then SkipRadioForward()
    elseif data.action == "unfreeze" then freezeradio = false
    else freezeradio = true; radioname = data.action end
    cb("ok")
end)

local hoursfreeze = GetClockHours()
local minutesfreeze = GetClockMinutes()
local secondsfreeze = GetClockSeconds()

RegisterNUICallback("weather", function(data, cb)
    local weather = data.action
    SetWeatherTypePersist(weather); SetWeatherTypeNowPersist(weather)
    SetWeatherTypeNow(weather); SetOverrideWeather(weather)
    cb("ok")
end)

RegisterNUICallback("time", function(data, cb)
    local hour
    local newstate = data.newstate
    if data.action == "4" or data.action == "6" or data.action == "12" or data.action == "18" or data.action == "0" then
        hour = tonumber(data.action); NetworkOverrideClockTime(hour, 0, 0)
    elseif data.action == "forwards" then
        hour = GetClockHours() == 23 and 0 or GetClockHours() + 1
        NetworkOverrideClockTime(hour, 0, 0)
    elseif data.action == "backwards" then
        hour = GetClockHours() == 0 and 23 or GetClockHours() - 1
        NetworkOverrideClockTime(hour, 0, 0)
    elseif data.action == "freeze" then
        freezecurrenttime = newstate
        hoursfreeze = GetClockHours(); minutesfreeze = GetClockMinutes(); secondsfreeze = GetClockSeconds()
    end
    cb("ok")
end)

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)
        if freezecurrenttime then NetworkOverrideClockTime(hoursfreeze, minutesfreeze, secondsfreeze) end
    end
end)

RegisterNUICallback("bogyguard", function(data, cb)
    local playerPed = GetPlayerPed(-1)
    local GroupHandle = GetPlayerGroup(PlayerId())
    SetGroupSeparationRange(GroupHandle, 999999.9)
    if data.action == "spawn" then
        local Ped = ClonePed(playerPed, GetEntityHeading(playerPed), 1, 1)
        AddBlipForEntity(Ped); SetPedAsGroupMember(Ped, GroupHandle); SetGroupFormation(GroupHandle, 2)
        SetEntityInvincible(Ped, false); SetPedCanBeTargetted(Ped, false)
        GiveWeaponToPed(Ped, GetHashKey("WEAPON_BAT"), 999999999, false, true); SetPedInfiniteAmmo(Ped, true)
        drawNotification("~g~Bodyguard Spawned")
    elseif data.action == "deleteall" then
        for i = 0, 6 do
            local ped = GetPedAsGroupMember(GroupHandle, i)
            RemoveBlip(GetBlipFromEntity(ped)); SetPedNeverLeavesGroup(ped, false); RemovePedFromGroup(ped)
            SetEntityAsMissionEntity(ped, 1, 1); DeleteEntity(ped)
        end
        drawNotification("~r~All Bodyguards Deleted")
    end
    cb("ok")
end)

RegisterNUICallback("bogyguarddelete", function(data, cb)
    local bguard = tonumber(data.action)
    local ped = GetPedAsGroupMember(GetPlayerGroup(PlayerId()), bguard - 1)
    RemoveBlip(GetBlipFromEntity(ped)); SetPedNeverLeavesGroup(ped, false); RemovePedFromGroup(ped)
    SetEntityAsMissionEntity(ped, 1, 1); DeleteEntity(ped)
    drawNotification("~g~Bodyguard " .. bguard .. " Deleted!")
    cb("ok")
end)

RegisterNUICallback("spectate", function(data, cb)
    local player = tonumber(data.action)
    if data.action == "stop" then
        NetworkSetInSpectatorMode(1, GetPlayerPed(-1)); NetworkSetInSpectatorMode(0, GetPlayerPed(-1))
        FreezeEntityPosition(GetPlayerPed(-1), false)
        SetEntityCoords(GetPlayerPed(-1), prevCoordx, prevCoordy, prevCoordz, false, false, false, true)
        prevCoordx = 0.0; prevCoordy = 0.0; prevCoordz = 0.0
    else
        if GetPlayerPed(player) ~= 0 and GetPlayerPed(-1) ~= GetPlayerPed(player) then
            if (prevCoordx == 0.0 and prevCoordy == 0.0 and prevCoordz == 0.0) then
                local pos = GetEntityCoords(GetPlayerPed(-1), true)
                prevCoordx = pos.x; prevCoordy = pos.y; prevCoordz = pos.z
            end
            ClearPlayerWantedLevel(PlayerId())
            SetEntityCoords(GetPlayerPed(-1), 9999.0, 9999.0, 9999.0, false, false, false, true)
            FreezeEntityPosition(GetPlayerPed(-1), true)
            RequestCollisionAtCoord(GetEntityCoords(GetPlayerPed(player), true))
            NetworkSetInSpectatorMode(1, GetPlayerPed(player))
        end
    end
    cb("ok")
end)

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)
        if autoparachute then GiveWeaponToPed(GetPlayerPed(-1), GetHashKey("gadget_parachute"), 1, false, false) end
    end
end)

Citizen.CreateThread(function()
    while true do Citizen.Wait(0); SetBlackout(blackout == true) end
end)

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)
        if not matchLockActive then SetCanAttackFriendly(GetPlayerPed(-1), true, false) end
        NetworkSetFriendlyFireOption(true)
    end
end)

Citizen.CreateThread(function()
    while true do Citizen.Wait(0); if GetPlayerPed(-1) then SetMobileRadioEnabledDuringGameplay(mobileradio) end end
end)

Citizen.CreateThread(function()
    while not NetworkIsPlayerActive(PlayerId()) or not NetworkIsSessionStarted() do
        Citizen.Wait(0); prevframes = GetFrameCount(); prevtime = GetGameTimer()
    end
    while true do
        curtime = GetGameTimer(); curframes = GetFrameCount()
        if((curtime - prevtime) > 1000) then fps = (curframes - prevframes) - 1; prevtime = curtime; prevframes = curframes end
        Citizen.Wait(0)
    end
end)

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)
        if dspeedo and IsPedInAnyVehicle(GetPlayerPed(-1), true) then
            local cleanspeed = GetEntitySpeed(GetVehiclePedIsIn(GetPlayerPed(-1), false))
            _DrawRect(0.205, 0.964, 0.07, 0.04, 0, 0, 0, 127, 0)
            if kmh then Draw("" .. math.ceil(cleanspeed * 3.6) .. " KMH", 255, 255, 255, 0.205, 0.95, 0.4, 0.4, 1, true)
            elseif mph then Draw("" .. math.ceil(cleanspeed * 2.236936) .. " MPH", 255, 255, 255, 0.205, 0.95, 0.4, 0.4, 1, true) end
        end
    end
end)

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)
        if nonpcstraffic then
            local pos = GetEntityCoords(GetPlayerPed(-1))
            SetPedDensityMultiplierThisFrame(0.0); SetScenarioPedDensityMultiplierThisFrame(0.0, 0.0)
            SetVehicleDensityMultiplierThisFrame(0.0); SetRandomVehicleDensityMultiplierThisFrame(0.0)
            SetParkedVehicleDensityMultiplierThisFrame(0.0); Citizen.InvokeNative(0x90B6DA738A9A25DA, 0.0)
            RemoveVehiclesFromGeneratorsInArea(pos.x-1000, pos.y-1000, pos.z-1000, pos.x+1000, pos.y+1000, pos.z+1000)
            SetGarbageTrucks(0); SetRandomBoats(0)
        end
    end
end)

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)
        if explodevehicles then
            NetworkExplodeVehicle(GetClosestVehicle(GetEntityCoords(GetPlayerPed(-1), true), 250.0, 0, 4), true, true, false)
        end
    end
end)

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)
        if noclipmode then
            SetEntityCollision(GetPlayerPed(-1), false, false); ClearPedTasksImmediately(GetPlayerPed(-1))
            StopAllScreenEffects(); Citizen.InvokeNative(0x0AFC4AF510774B47)
            if not IsControlPressed(1, 32) and not IsControlPressed(1, 33) and not IsControlPressed(1, 90) and not IsControlPressed(1, 89) then
                FreezeEntityPosition(GetPlayerPed(-1), true)
            end
            local coords = Citizen.InvokeNative(0x0A794A5A57F8DF91, PlayerPedId(), Citizen.ResultAsVector())
            if IsControlPressed(1, 32) then
                FreezeEntityPosition(GetPlayerPed(-1), false)
                ApplyForceToEntity(GetPlayerPed(-1), 1, coords.x * 3, coords.y * 3, 0.27, 0, 0, 0, 1, false, true, true, true, true)
            elseif IsControlPressed(1, 33) then
                FreezeEntityPosition(GetPlayerPed(-1), false)
                ApplyForceToEntity(GetPlayerPed(-1), 1, coords.x * -3, coords.y * -3, 0.27, 0, 0, 0, 1, false, true, true, true, true)
            end
            if IsControlPressed(1, 90) then FreezeEntityPosition(GetPlayerPed(-1), false); ApplyForceToEntity(GetPlayerPed(-1), 1, 0, 0, 5, 0, 0, 0, 1, false, true, true, true, true)
            elseif IsControlPressed(1, 89) then FreezeEntityPosition(GetPlayerPed(-1), false); ApplyForceToEntity(GetPlayerPed(-1), 1, 0, 0, -5, 0, 0, 0, 1, false, true, true, true, true) end
            SetEntityRotation(GetPlayerPed(-1), 0.0, 0.0, GetGameplayCamRot(0).z, 1, true)
        end
    end
end)

Citizen.CreateThread(function()
    while true do Citizen.Wait(0); SetCinematicButtonActive(not (cinecam == true)) end
end)

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)
        if freezeradio and (GetPlayerRadioStationName() ~= radioname) then
            SetRadioToStationName(radioname); SetVehRadioStation(GetVehiclePedIsIn(GetPlayerPed(-1), false), radioname)
        end
    end
end)

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)
        local pos = GetEntityCoords(GetPlayerPed(-1), true)
        local GroupHandle = GetPlayerGroup(PlayerId())
        for i = 0, 6 do
            local ped = GetPedAsGroupMember(GroupHandle, i)
            local PedPos = GetEntityCoords(ped, true)
            if (Vdist(pos.x, pos.y, pos.z, PedPos.x, PedPos.y, PedPos.z) >= 50) then
                SetEntityCoords(ped, pos.x, pos.y, pos.z, false, false, false, true); SetEntityVisible(ped, true, 0)
            end
        end
    end
end)

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)
        if vibrator then SetPadShake(0, 999999999, 255); vibcount = 1
        elseif vibcount == 1 then StopPadShake(0); vibcount = 0 end
    end
end)

function CustomDraw(text, x, y)
    SetTextFont(6); SetTextScale(0.36, 0.36); SetTextWrap(0.0, 1.0); SetTextCentre(false)
    SetTextDropshadow(0, 0, 0, 0, 0); SetTextEdge(1, 0, 0, 0, 205)
    SetTextEntry("STRING"); AddTextComponentString(text); DrawText(x, y)
end

function Draw(text, r, g, b, x, y, width, height, layer, center)
    SetTextColour(r, g, b, 127); SetTextFont(0); SetTextScale(width, height)
    SetTextWrap(0.0, 1.0); SetTextCentre(center)
    SetTextDropshadow(0, 0, 0, 0, 0); SetTextEdge(1, 0, 0, 0, 205)
    SetTextEntry("STRING"); AddTextComponentString(text)
    Citizen.InvokeNative(0x61BB1D9B3A95D802, layer); DrawText(x, y)
end

function _DrawRect(x, y, width, height, r, g, b, a, layer)
    Citizen.InvokeNative(0x61BB1D9B3A95D802, layer); DrawRect(x, y, width, height, r, g, b, a)
end

-- ============================================================
--  SECTION 21: Admin System NUI Callbacks
-- ============================================================

for _, cmd in ipairs(Config.Commands) do
    RegisterNUICallback(cmd.nuiName, function(data, cb)
        if cmd.closeMello then CloseMello() end
        ExecuteCommand(cmd.command)
        if cb then cb("ok") end
    end)
end

-- ============================================================
--  SECTION 22: Match Lock (god mode / menu / noclip off during a match)
-- ============================================================

local matchLock = Config.MatchLock or {}
local matchLockDisable = matchLock.Disable or {}
local matchLockSaved = {}
local matchLockExplode = false
local matchLockNotified = -10000

-- config key, global toggle, global "updated" flag read by the feature threads
local matchLockFlags = {
    { "godMode",        "featurePlayerInvincible" },
    { "invisible",      "featurePlayerInvisible",   "featurePlayerInvisibleUpdated" },
    { "superJump",      "featurePlayerSuperJump" },
    { "fastRun",        "featurePlayerFastRun",     "featurePlayerFastRunUpdated" },
    { "fastSwim",       "featurePlayerFastSwim",    "featurePlayerFastSwimUpdated" },
    { "noRagdoll",      "featureNoRagDoll" },
    { "nightVision",    "featureNightVision",       "featureNightVisionUpdated" },
    { "thermalVision",  "featureThermalVision",     "featureThermalVisionUpdated" },
    { "vehicleGodMode", "vehgodmode" },
    { "vehicleGodMode", "featureVehInvincible" },
    { "vehicleBoost",   "boostcar" },
    { "playerBlips",    "featurePlayerBlips" },
    { "playerNames",    "featurePlayerHeadDisplay" },
    { "infiniteAmmo",   "featurePlayerInfiniteAmmo" },
    { "noReload",       "featurePlayerNoReload" },
    { "infiniteStamina", "featurePlayerInfiniteStamina" },
    { "silent",         "featurePlayerNoNoise",     "featurePlayerNoNoiseUpdated" },
    { "noFallOff",      "featureNoFallOff",         "featureNoFallOffUpdated" },
    { "drunk",          "featurePlayerDrunk",       "featurePlayerDrunkUpdated" },
}
local matchLockRocket = false
local godLockSaved = nil

function MatchLockNotify()
    local message = matchLock.Message
    if not message or message == "" then return end
    local now = GetGameTimer()
    if now - matchLockNotified < 2500 then return end
    matchLockNotified = now
    drawNotification(message)
end

local function matchLockSet(flag, updated, value)
    if _G[flag] == value then return end
    _G[flag] = value
    if updated then _G[updated] = true end

    local ped = PlayerPedId()
    if flag == "featurePlayerInfiniteAmmo" then
        toggleInfiniteAmmo(value); SetPedInfiniteAmmo(ped, value)
    elseif flag == "featurePlayerNoReload" then
        SetPedInfiniteAmmoClip(ped, value)
    elseif flag == "featureVehInvincible" then
        local veh = GetVehiclePedIsIn(ped, false)
        if veh ~= 0 then SetEntityInvincible(veh, value) end
    end
end

-- god mode is only switched off inside a match (lobby keeps the player's god mode, like before)
local function godLockSet(active)
    if active == (matchLockGod == true) then return end
    if active then
        if not matchLockDisable.godMode then return end
        godLockSaved = featurePlayerInvincible
        featurePlayerInvincible = false
        matchLockGod = true
        matchLockGodReset = true
    else
        matchLockGod = false
        matchLockGodReset = false
        if godLockSaved ~= nil then
            featurePlayerInvincible = godLockSaved
            godLockSaved = nil
        end
    end
end

-- whole fights world (lobby + matches): menu, F3, noclip and every feature are off
local function matchLockStart()
    matchLockSaved = {}
    for _, entry in ipairs(matchLockFlags) do
        local key, flag, updated = entry[1], entry[2], entry[3]
        if key ~= "godMode" and matchLockDisable[key] and _G[flag] then
            matchLockSaved[flag] = { value = _G[flag], updated = updated }
            matchLockSet(flag, updated, false)
        end
    end

    if matchLockDisable.noclip and noclipmode then
        noclipmode = false
        Citizen.InvokeNative(0xD86D101FCFD00A4B, GetPlayerPed(-1), 2)
        Citizen.InvokeNative(0xD86D101FCFD00A4B, GetPlayerPed(-1), 3)
        SetEntityCollision(GetPlayerPed(-1), true, true); FreezeEntityPosition(GetPlayerPed(-1), false)
    end

    matchLockExplode = matchLockDisable.explodeVehicles == true and explodevehicles == true
    if matchLockExplode then explodevehicles = false end

    -- vehicles.lua has its own copies of the horn boost / vehicle god mode toggles
    matchLockVehBoost = matchLockDisable.vehicleBoost == true
    matchLockVehGod = matchLockDisable.vehicleGodMode == true
    if matchLockVehBoost then
        featurePowerMultiplier = 1
        featureTorqueMultiplier = 1
    end

    matchLockRocket = matchLockDisable.rocketBoost == true and infiniteRocketBoost == true
    if matchLockRocket then infiniteRocketBoost = false end

    if matchLockDisable.spectate and featureSpectate then
        NetworkSetInSpectatorMode(false, PlayerPedId())
        featureSpectate = false
    end

    matchLockActive = true
    if showtrainer then CloseMello() end
end

local function matchLockStop()
    matchLockActive = false
    godLockSet(false)
    if matchLockRocket then infiniteRocketBoost = true; matchLockRocket = false end
    matchLockVehBoost = false
    matchLockVehGod = false
    for flag, saved in pairs(matchLockSaved) do
        matchLockSet(flag, saved.updated, saved.value)
    end
    matchLockSaved = {}
    if matchLockExplode then explodevehicles = true; matchLockExplode = false end
end

local function matchLockCheck(list)
    for _, check in ipairs(list or {}) do
        if GetResourceState(check.resource) == "started" then
            local ok, result = pcall(function() return exports[check.resource][check.export]() end)
            if ok and result == true then return true end
        end
    end
    return false
end

if matchLock.Enabled then
    Citizen.CreateThread(function()
        while true do
            local inMatch = matchLockCheck(matchLock.Checks)
            local inWorld = inMatch or matchLockCheck(matchLock.WorldChecks)
            if inWorld and not matchLockActive then
                matchLockStart()
            elseif not inWorld and matchLockActive then
                matchLockStop()
            end
            if matchLockActive then godLockSet(inMatch) end
            Citizen.Wait(250)
        end
    end)
end

-- ============================================================
--  SECTION 23: Fights World Skins (no trainer skins in the fights world)
-- ============================================================

local fightSkins = Config.FightSkins or {}
local fightSkinBanned = nil

-- hashes compared as unsigned so client / server values always match
local function fightSkinHash(value)
    if type(value) == "string" then value = GetHashKey(value) end
    return math.tointeger(value % 4294967296)
end

-- every "playerskin <model>" in the trainer html is banned, so new skins are covered automatically
local function fightSkinList()
    if fightSkinBanned then return fightSkinBanned end
    fightSkinBanned = {}
    local allowed = {}
    for _, name in ipairs(fightSkins.Allowed or {}) do allowed[fightSkinHash(name)] = true end
    local html = LoadResourceFile(GetCurrentResourceName(), fightSkins.Html or "nui/trainer.html") or ""
    for name in html:gmatch('data%-action%s*=%s*"playerskin%s+([^"%s]+)%s*"') do
        local hash = fightSkinHash(name)
        if name ~= "input" and not allowed[hash] then fightSkinBanned[hash] = true end
    end
    return fightSkinBanned
end

local function fightSkinCheck()
    if not fightSkinList()[fightSkinHash(GetEntityModel(PlayerPedId()))] then return end
    local model = GetHashKey(fightSkins.DefaultModel or "mp_m_freemode_01")
    RequestModel(model)
    local timeout = GetGameTimer() + 5000
    while not HasModelLoaded(model) and GetGameTimer() < timeout do Citizen.Wait(50) end
    if not HasModelLoaded(model) then return end
    SetPlayerModel(PlayerId(), model)
    local ped = PlayerPedId()
    -- the default variation is random on freemode peds (blue shirt glitch), so dress him explicitly
    SetPedDefaultComponentVariation(ped)
    SetPedHeadBlendData(ped, 0, 0, 0, 0, 0, 0, 0.0, 0.0, 0.0, false)
    ClearAllPedProps(ped)
    for component, piece in pairs(fightSkins.Outfit or {}) do
        SetPedComponentVariation(ped, component, piece[1], piece[2] or 0, 0)
    end
    SetModelAsNoLongerNeeded(model)
    if fightSkins.Message and fightSkins.Message ~= "" then drawNotification(fightSkins.Message) end
end

-- the server checks every player in the fights world and asks us to swap
RegisterNetEvent("mellotrainer:fightSkinReset")
AddEventHandler("mellotrainer:fightSkinReset", function()
    if fightSkins.Enabled then fightSkinCheck() end
end)

if fightSkins.Enabled then
    Citizen.CreateThread(function()
        local wasInside, nextCheck = false, 0
        while true do
            Citizen.Wait(1000)
            -- right when he enters the fights world, then every Interval seconds
            if matchLockActive and (not wasInside or GetGameTimer() >= nextCheck) then
                fightSkinCheck()
                nextCheck = GetGameTimer() + (fightSkins.Interval or 10) * 1000
            end
            wasInside = matchLockActive == true
        end
    end)
end
