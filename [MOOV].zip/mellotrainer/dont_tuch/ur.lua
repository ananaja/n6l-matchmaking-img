-- ============================================================
--  ur.lua - Separated Code (Without License/Obfuscation)
--  Contains: Utilities, Variables, Notifications,
--  Settings/Blips/Radio, and Vehicle Features
-- ============================================================


-- ============================================================
--  Utility Functions (cl_utils.lua)
-- ============================================================

function _LoadAnimDict( dict )
    while ( not HasAnimDictLoaded( dict ) ) do
        RequestAnimDict( dict )
        Citizen.Wait( 5 )
    end
end

function _LoadClipSet( set )
    while ( not HasClipSetLoaded( set ) ) do
        RequestClipSet( set )
        Citizen.Wait( 5 )
    end
end

function _LoadModel( mdl )
    while ( not HasModelLoaded( mdl ) ) do
        RequestModel( mdl )
        Citizen.Wait( 5 )
    end
end

function drawNotification(text)
    SetNotificationTextEntry("STRING")
    AddTextComponentString(text)
    DrawNotification(false, false)
end

RegisterNetEvent("mello:notify", drawNotification)

function stringsplit(inputstr, sep)
    if sep == nil then
            sep = "%s"
    end
    local t={} ; i=1
    for str in string.gmatch(inputstr, "([^"..sep.."]+)") do
            t[i] = str
            i = i + 1
    end
    return t
end

function sortByValue(custTable)
  local Keys = {}
  for k,_ in pairs(custTable) do
    Keys[#Keys+1] = _
  end
  table.sort(Keys)
  local newObj = {}
  for k,v in ipairs(Keys) do
    for key,value in pairs(custTable) do
      if value == v then
        newObj[key] = value
        break
      end
    end
  end
  return newObj
end

function getTableLength(T)
    local count = 0
    for _ in pairs(T) do
        count = count + 1
    end
    return count
end

function GetToggleState(variableName)
  local value = _G[variableName]
  if(value)then
    return "ON"
  else
    return "OFF"
  end
end

function requestInput(exampleText, maxLength)
    DisplayOnscreenKeyboard(1, "FMMC_KEY_TIP8", "", exampleText, "", "", "", maxLength + 1)
    blockinput = true
    while UpdateOnscreenKeyboard() ~= 1 and UpdateOnscreenKeyboard() ~= 2 do
        Citizen.Wait( 0 )
    end
    local result = GetOnscreenKeyboardResult()
    UnblockMenuInput()
    if result ~= "" and result ~= exampleText then
        return result
    else
        return false
    end
end

function UnblockMenuInput()
    Citizen.CreateThread( function()
        Citizen.Wait( 150 )
        blockinput = false
    end )
end

function tableSet(mytable)
  local set = {}
  for _,l in ipairs(mytable) do set[l] = true end
  return set
end


-- ============================================================
--  Default Variables (cl_variables.lua)
-- ============================================================

maxPlayers = 256;

featurePlayerBlips = false;
featurePlayerBlipNames = true;
featurePlayerHeadDisplay = false;
featurePlayerNotifications = true;
featureDeathNotifications = true;
featureHideMap = false;
featureHideHud = false;
featureBigHud = false;
featureMapBlips = true;
featureAreaStreetNames = false;
featureRestoreAppearance = true;

featureCloseInstantly = false;
featureSpeedometer = false;
featureSpawnInsideCar = true;
featureSpawnCarInFront = true
featureDeleteLastVehicle = true;
featureNoFallOff = false;
featureNoDragOut = false;
featureNoHelmet = false;
featureVehCosDamage = false;
featureVehMechDamage = false;
featureVehInvincible = false;
featureVehicleTwoWheel = false

featureNightVision = false;
featureThermalVision = false;
featurePlayerInvincible = Config.GodModeOnStart;
featureKeepClean = false;
featureKeepWet = false;
featurePlayerNeverWanted = false;
featurePlayerIgnoredByPolice = false;
featurePlayerIgnoredByAll = false;
featurePlayerNoNoise = false;
featurePlayerFastSwim = false;
featurePlayerFastRun = false;
featurePlayerSuperJump = false;
featureNoRagDoll = false;
featurePlayerInvisible = false;
featurePlayerDrunk = false;
featurePlayerInfiniteStamina = true;
featurePlayerInfiniteParachutes = false;
featurePlayerInfiniteAmmo = false;
featurePlayerNoReload = false;

featurePlayerRadio = false;
featureRadioAlwaysOff = false;

featureBlackout = false;
featureWeatherWind = false;
featureWeatherFreeze = false;

featureShowVoiceChatSpeaker = true;
featureVoiceChat = true;
featureVPAllPlayers = true;
featureVPTooClose = false;
featureVPVeryClose = false;
featureVPClose = false;
featureVPNearby = false;
featureVPDistant = false;
featureVPFar = false;
featureVPVeryFar = false;
featureChannelDefault = true;
featureChannel1 = false;
featureChannel2 = false;
featureChannel3 = false;
featureChannel4 = false;
featureChannel5 = false;

Users = {}
playerWasDisconnected = true;

featureNoFallOffUpdated = true;
featureNoDragOutUpdated = true;
featureNeonLeft = nil;
featureNeonRight = nil;
featureNeonFront = nil;
featureNeonRear = nil;
featureTorqueMultiplier = 1;
featurePowerMultiplier = 1;
featureLowerForce = 0;
featureTurboMode = false;
featureCustomTires = false;
featureBulletproofWheels = false;
featureXeonLights = false;

featureNightVisionUpdated = true;
featureThermalVisionUpdated = true;
featurePlayerInvincibleUpdated = true;
featurePlayerNeverWantedUpdated = true;
featurePlayerIgnoredByPoliceUpdated = true;
featurePlayerIgnoredByAllUpdated = true;
featurePlayerNoNoiseUpdated = true;
featurePlayerFastSwimUpdated = true;
featurePlayerFastRunUpdated = true;
featurePlayerInvisibleUpdated = true;
featurePlayerDrunkUpdated = true;

featureSpectate = false;
featureDrawRoute = false;

open1 = nil; open2 = nil; open3 = nil; open4 = nil; open5 = nil;
open6 = nil; open7 = nil; open8 = nil; open9 = nil; open10 = nil;
open11 = nil; open12 = nil; open13 = nil; open14 = nil; open15 = nil;
open16 = nil; open17 = nil; open18 = nil; open19 = nil; open20 = nil;
open21 = nil; open22 = nil; open23 = nil; open24 = nil; open25 = nil;
open26 = nil; open27 = nil; open28 = nil; open29 = nil; open30 = nil;
open31 = nil; open32 = nil; open33 = nil; open34 = nil; open35 = nil;
ponsonbys1 = nil; ponsonbys2 = nil; ponsonbys3 = nil;
discount1 = nil; discount2 = nil; discount3 = nil; discount4 = nil; discount5 = nil;
binco1 = nil; binco2 = nil;
suburban1 = nil; suburban2 = nil; suburban3 = nil; suburban4 = nil;
lsc1 = nil; lsc2 = nil; lsc3 = nil; lsc4 = nil; lsc5 = nil; lsc6 = nil;
tattoo1 = nil; tattoo2 = nil; tattoo3 = nil; tattoo4 = nil; tattoo5 = nil; tattoo6 = nil;
ammo1 = nil; ammo2 = nil; ammo3 = nil; ammo4 = nil; ammo5 = nil;
ammo6 = nil; ammo7 = nil; ammo8 = nil; ammo9 = nil; ammo10 = nil; ammo11 = nil;
barber1 = nil; barber2 = nil; barber3 = nil; barber4 = nil; barber5 = nil; barber6 = nil; barber7 = nil;
store1 = nil; store2 = nil; store3 = nil; store4 = nil; store5 = nil; store6 = nil;
store7 = nil; store8 = nil; store9 = nil; store10 = nil; store11 = nil; store12 = nil;
policestation1 = nil; policestation2 = nil; policestation4 = nil; policestation5 = nil;
policestation6 = nil; policestation7 = nil; policestation8 = nil; policestation9 = nil;
policestation10 = nil; policestation11 = nil;
bank1 = nil; bank2 = nil; bank3 = nil; bank4 = nil; bank5 = nil; bank6 = nil; bank7 = nil;
cablecar1 = nil; cablecar2 = nil;
carwash1 = nil; carwash2 = nil;
airport1 = nil; airport2 = nil; airport3 = nil;
stripclub = nil; helipad = nil; boat1 = nil; rebel = nil;
theater1 = nil; theater2 = nil; theater3 = nil;
hospital1 = nil; hospital2 = nil; hospital3 = nil;
bar1 = nil; bar2 = nil; comedy = nil; drugs = nil;
marijuana1 = nil; marijuana2 = nil;
altruist = nil; sub = nil; masks = nil; fairground = nil;
golf = nil; tennis = nil; darts = nil; playboy = nil; fib = nil;


-- ============================================================
--  Notification Settings (cl_settings_notifications.lua)
-- ============================================================

RegisterNUICallback("notifications", function(data, cb)
    local action = data.action
    local state = data.newstate
    local text,text2
    if(state) then text = "~g~ON" text2 = "~r~OFF"
    else text = "~r~OFF" text2 = "~g~ON" end
    if(action=="players")then
        featurePlayerNotifications = state
        drawNotification("Player Notifications: "..text)
    elseif(action=="death")then
        featureDeathNotifications = state
        drawNotification("Death Notifications: "..text)
    end
    if(cb)then cb("ok") end
end)


-- ============================================================
--  Vehicle Features (vehicles.lua)
-- ============================================================

local showextras
local frontleft, frontright, rearleft, rearright, hood, trunk

RegisterNUICallback("openclosedoors", function(data, cb)
    local playerPed = GetPlayerPed(-1)
    local playerVeh = GetVehiclePedIsIn(playerPed, false)
    local action = data.action
    local doorInt = tonumber(action)
    if not IsPedInAnyVehicle(playerPed, true) then drawNotification("~r~Not in a vehicle!"); return end
    if doorInt and doorInt >= 0 and doorInt <= 5 then
        if GetVehicleDoorAngleRatio(playerVeh, doorInt) > 0.0 then
            SetVehicleDoorShut(playerVeh, doorInt, false)
        else
            SetVehicleDoorOpen(playerVeh, doorInt, false)
        end
    end
end)

RegisterNUICallback("extra", function(data, cb)
    local playerPed = GetPlayerPed(-1)
    local playerVeh = GetVehiclePedIsIn(playerPed, false)
    local action = data.action
    if action == "show" then
        showextras = data.newstate; drawNotification("~g~Showing Extras States!"); drawNotification("~y~Disappears In 10 Seconds!")
    else
        local extra = tonumber(action)
        if IsPedInAnyVehicle(playerPed, true) then
            if (DoesExtraExist(playerVeh, extra) == 1) then
                if (IsVehicleExtraTurnedOn(playerVeh, extra) == 1) then SetVehicleExtra(playerVeh, extra, true); drawNotification("~r~Extra " .. action .. " Disabled!")
                else SetVehicleExtra(playerVeh, extra, false); drawNotification("~g~Extra " .. action .. " Enabled!") end
            else drawNotification("~r~Extra " .. action .. " Not Existing!") end
        else drawNotification("~r~Not in a vehicle!") end
    end
end)

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)
        local playerVeh = GetVehiclePedIsIn(GetPlayerPed(-1))
        if (vehgodmode == false) then
            if IsPedInAnyVehicle(GetPlayerPed(-1), true) then
                SetVehicleCanBeVisiblyDamaged(playerVeh, true); SetVehicleTyresCanBurst(playerVeh, true)
                SetEntityInvincible(playerVeh, false)
                SetEntityProofs(playerVeh, false, false, false, false, false, false, false, false)
                SetVehicleWheelsCanBreak(playerVeh, true)
            end
        elseif (vehgodmode == true) then
            if IsPedInAnyVehicle(GetPlayerPed(-1), true) then
                SetVehicleCanBeVisiblyDamaged(playerVeh, false); SetVehicleTyresCanBurst(playerVeh, false)
                SetEntityInvincible(playerVeh, true)
                SetEntityProofs(playerVeh, true, true, true, true, true, true, true, true)
                SetVehicleWheelsCanBreak(playerVeh, false)
            end
        end
    end
end)

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)
        if (showextras == true) then Citizen.Wait(10000); showextras = false end
    end
end)

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)
        local playerVeh = GetVehiclePedIsIn(GetPlayerPed(-1), false)
        if (boostcar == true) and not matchLockActive then
            if IsPedInAnyVehicle(GetPlayerPed(-1), true) then
                if IsControlPressed(1, 71) and IsControlPressed(1, 86) then
                    SetVehicleBoostActive(playerVeh, 1, 0)
                    SetVehicleForwardSpeed(playerVeh, 75.0)
                elseif IsControlPressed(1, 72) and IsControlPressed(1, 86) then
                    SetVehicleBoostActive(playerVeh, 1, 0)
                    SetVehicleForwardSpeed(playerVeh, -75.0)
                end
                SetVehicleBoostActive(playerVeh, 0, 0)
            end
        end
    end
end)


-- ============================================================
--  Settings, Blips & Radio (cl_settings.lua)
-- ============================================================

local playerdb = {}
for i=0, maxPlayers, 1 do playerdb[i] = {} end

RegisterNUICallback("settingtoggle", function(data, cb)
    local action = data.action
    local newstate = data.newstate
    local text = newstate and "~g~ON" or "~r~OFF"
    local text2 = newstate and "~r~OFF" or "~g~ON"

    if(action == "hud")then featureHideHud = newstate; DisplayHud(not featureHideHud); drawNotification("Hud Display: "..text2)
    elseif(action == "radar")then featureHideMap = newstate; DisplayRadar(not featureHideMap); drawNotification("Radar Display: "..text2)
    elseif(action == "enlarge")then featureBigHud = newstate; SetRadarBigmapEnabled(featureBigHud, false); drawNotification("Large Map: "..text)
    elseif(action == "blips")then featurePlayerBlips = newstate; drawNotification("Player Blips: "..text)
    elseif(action == "blipnames")then featurePlayerBlipNames = newstate; drawNotification("Player Blip Names: "..text)
    elseif(action == "text")then featurePlayerHeadDisplay = newstate; drawNotification("Overhead Player Names: "..text)
    elseif(action == "streets")then featureAreaStreetNames = newstate; drawNotification("Street Names: "..text2)
    elseif(action=="radiooff")then featureRadioAlwaysOff = newstate; drawNotification("Radio Always Off: "..text)
    elseif(action=="mobileradio")then featurePlayerRadio = newstate; SetMobileRadioEnabledDuringGameplay(featurePlayerRadio); SetUserRadioControlEnabled(not featureRadioAlwaysOff); drawNotification("Player Radio: "..text)
    elseif(action=="skipradio")then SkipRadioForward() end
end)

function toggleRadio(playerPed)
    if(IsPedInAnyVehicle(playerPed, false))then SetVehicleRadioEnabled(GetVehiclePedIsUsing(playerPed), not featureRadioAlwaysOff) end
    SetUserRadioControlEnabled(not featureRadioAlwaysOff)
end

Citizen.CreateThread(function()
    while true do
        Wait(0)
        if(featureAreaStreetNames) then HideHudComponentThisFrame(7); HideHudComponentThisFrame(9) end
        if IsControlJustPressed(0, 20) and not IsPauseMenuActive() and not blockinput then
            featureBigHud = not featureBigHud; SetRadarBigmapEnabled( featureBigHud, false)
        end
    end
end)

RegisterNetEvent('mellotrainer:playerEnteredVehicle')
AddEventHandler('mellotrainer:playerEnteredVehicle', function(veh)
    toggleRadio(GetPlayerPed(-1)); UpdateVehicleFeatureVariables(veh)
end)

Citizen.CreateThread(function()
    local radioToggle = false
    while true do
        Wait(100)
        local playerPed = GetPlayerPed(-1)
        if(featureRadioAlwaysOff)then
            if(featurePlayerRadio)then SetMobileRadioEnabledDuringGameplay(false); featurePlayerRadio = false end
            if(not radioToggle)then toggleRadio(playerPed) end
            radioToggle = true
        else
            if(radioToggle)then toggleRadio(playerPed); radioToggle = false end
        end
    end
end)

local playersDB = {}
for i=0, maxPlayers, 1 do playersDB[i] = {} end

function clearPlayerHead(id)
    if(playersDB[id].headId ~= nil and IsMpGamerTagActive(playersDB[id].headId))then RemoveMpGamerTag(playersDB[id].headId) end
end

function createPlayerHead(id,ped)
    if(featurePlayerHeadDisplay)then
        local headId = CreateMpGamerTag(ped, GetPlayerName(id), false, false, "", false )
        local wantedLvl = GetPlayerWantedLevel(id)
        if wantedLvl > 0 then SetMpGamerTagWantedLevel(headId, wantedLvl); SetMpGamerTagVisibility(headId, 7, true)
        else SetMpGamerTagWantedLevel(headId, 0); SetMpGamerTagVisibility(headId, 7, false) end
        SetMpGamerTagVisibility(headId, 9, NetworkIsPlayerTalking(id))
        playersDB[id].headId = headId; playersDB[id].wantedLvl = wantedLvl
    else
        if(playersDB[id].headId ~= nil and IsMpGamerTagActive(playersDB[id].headId))then RemoveMpGamerTag(playersDB[id].headId) end
        playersDB[id].headId = nil; playersDB[id].wantedLvl = nil
    end
end

function clearPlayerBlip(id)
    if(playersDB[id].blip ~= nil)then RemoveBlip(playersDB[id].blip) end
end

function getVehicleSpriteId(veh)
    local vehClass = GetVehicleClass(veh)
    local sprite = 1
    if(vehClass == 8 or vehClass == 13)then sprite = 226
    elseif(vehClass == 14)then sprite = 427
    elseif(vehClass == 15)then sprite = 422
    elseif(vehClass == 16)then sprite = 423
    elseif(vehClass == 19)then sprite = 421
    else sprite = 225 end
    local vehModel = GetEntityModel(veh)
    if(vehModel == GetHashKey("besra") or vehModel == GetHashKey("hydra") or vehModel == GetHashKey("lazer"))then sprite = 424
    elseif(vehModel == GetHashKey("insurgent") or vehModel == GetHashKey("insurgent2") or vehModel == GetHashKey("limo2"))then sprite = 426
    elseif(vehModel == GetHashKey("rhino"))then sprite = 421 end
    return sprite
end

function createPlayerBlip(id,ped,blip)
    if(featurePlayerBlips)then
        if(not DoesBlipExist(blip))then
            blip = AddBlipForEntity(ped); SetBlipSprite(blip, 1)
            Citizen.InvokeNative( 0x5FBCA48327B914DF, blip, true)
        end
        local veh = GetVehiclePedIsIn(ped, false)
        local blipSprite = GetBlipSprite(blip)
        if not GetEntityHealth(ped) then
            if blipSprite ~= 274 then SetBlipSprite(blip,274); Citizen.InvokeNative( 0x5FBCA48327B914DF, blip, false) end
        elseif IsPedInAnyVehicle(ped, false) then
            local sprite = getVehicleSpriteId(veh)
            if blipSprite ~= sprite then SetBlipSprite(blip, sprite); Citizen.InvokeNative(0x5FBCA48327B914DF, blip, false) end
            local passengers = GetVehicleNumberOfPassengers(veh)
            if passengers then
                if not IsVehicleSeatFree(veh, -1) then passengers = passengers + 1 end
                ShowNumberOnBlip(blip,passengers)
            else HideNumberOnBlip(blip) end
        else
            HideNumberOnBlip(blip)
            if blipSprite ~= 1 then SetBlipSprite(blip, 1); Citizen.InvokeNative(0x5FBCA48327B914DF, blip, true) end
        end
        SetBlipRotation(blip, math.ceil(GetEntityHeading(veh)))
        if(featurePlayerBlipNames)then SetBlipNameToPlayerName(blip, id)
        else BeginTextCommandSetBlipName("STRING"); AddTextComponentString("Player"); EndTextCommandSetBlipName(blip) end
        SetBlipScale(blip, 0.85)
        if IsPauseMenuActive() then SetBlipAlpha(blip, 255)
        else
            local x1, y1 = table.unpack(GetEntityCoords(GetPlayerPed(-1), true))
            local x2, y2 = table.unpack(GetEntityCoords(GetPlayerPed(id), true))
            local distance = ( math.floor( math.abs( math.sqrt( ( x1 - x2 ) * ( x1 - x2 ) + ( y1 - y2 ) * ( y1 - y2 ) ) ) / -1 ) ) + 900
            if distance < 0 then distance = 0 elseif distance > 255 then distance = 255 end
            SetBlipAlpha(blip, distance)
        end
        playersDB[id].ped = ped; playersDB[id].blip = blip
    else clearPlayerBlip(id) end
end

RegisterNetEvent( 'mellotrainer:playerLeft' )
AddEventHandler( 'mellotrainer:playerLeft', function( person )
    clearPlayerBlip(person.source); clearPlayerHead(person.source)
    playersDB[person.source] = "skip"
    Wait(30000); playersDB[person.source] = {}
end )

Citizen.CreateThread(function()
    while true do
        Wait(1)
        for id = 0, maxPlayers do
            if NetworkIsPlayerActive(id) and GetPlayerPed(id) ~= GetPlayerPed(-1) and playersDB[id] ~= "skip" then
                local ped = GetPlayerPed(id)
                createPlayerHead(id,ped); createPlayerBlip(id,ped,GetBlipFromEntity(ped))
            elseif(playersDB[id] and playersDB[id].ped ~= nil)then
                clearPlayerHead(id); clearPlayerBlip(id); playersDB[id] = {}
            end
        end
    end
end)
