CreateThread(function()
    RegisterFontFile('A9eelsh')
    local fontId = RegisterFontId('A9eelsh')

    print(('[A9eelsh Font] Registered font ID: %s'):format(fontId))
end)
