fx_version 'cerulean'
game 'gta5'

files {
    'stream/A9eelsh.gfx'
}

client_script 'client.lua'
